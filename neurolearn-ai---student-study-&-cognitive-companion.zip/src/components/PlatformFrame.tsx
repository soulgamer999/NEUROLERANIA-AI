import React from 'react';
import { DeviceViewport } from '../types';
import { Smartphone, Tablet, Monitor, Wifi, Battery, Signal } from 'lucide-react';

interface PlatformFrameProps {
  viewport: DeviceViewport;
  onChangeViewport: (v: DeviceViewport) => void;
  children: React.ReactNode;
}

export const PlatformFrame: React.FC<PlatformFrameProps> = ({
  viewport,
  onChangeViewport,
  children
}) => {
  if (viewport === 'responsive') {
    return <div className="min-h-screen">{children}</div>;
  }

  return (
    <div className="min-h-screen bg-slate-950 p-2 sm:p-6 flex flex-col items-center justify-center">
      {/* Device Switcher Header */}
      <div className="mb-4 flex items-center space-x-3 bg-slate-900 border border-slate-800 p-2 rounded-xl text-xs text-slate-300">
        <span className="font-semibold text-slate-400">Device Viewport Simulator:</span>
        <button
          onClick={() => onChangeViewport('mobile')}
          className={`px-3 py-1 rounded-lg flex items-center space-x-1 ${viewport === 'mobile' ? 'bg-indigo-600 text-white font-bold' : 'hover:bg-slate-800'}`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>Mobile (Android/iOS)</span>
        </button>
        <button
          onClick={() => onChangeViewport('tablet')}
          className={`px-3 py-1 rounded-lg flex items-center space-x-1 ${viewport === 'tablet' ? 'bg-indigo-600 text-white font-bold' : 'hover:bg-slate-800'}`}
        >
          <Tablet className="w-3.5 h-3.5" />
          <span>Tablet</span>
        </button>
        <button
          onClick={() => onChangeViewport('responsive')}
          className="px-3 py-1 rounded-lg hover:bg-slate-800 flex items-center space-x-1"
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>Full Width</span>
        </button>
      </div>

      {/* Frame Container */}
      <div className={`transition-all duration-300 relative bg-slate-900 rounded-[38px] p-3 border-4 border-slate-800 shadow-2xl ${
        viewport === 'mobile' ? 'w-[380px] max-w-full' : 'w-[800px] max-w-full'
      }`}>
        {/* Mobile Status Bar */}
        {viewport === 'mobile' && (
          <div className="flex items-center justify-between px-6 py-1.5 text-slate-400 text-[10px] font-mono">
            <span>09:41</span>
            <div className="w-20 h-3.5 bg-black rounded-full mx-auto" />
            <div className="flex items-center space-x-1">
              <Signal className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <Battery className="w-3.5 h-3.5" />
            </div>
          </div>
        )}

        {/* Screen Content Container */}
        <div className="bg-white dark:bg-slate-900 rounded-[28px] overflow-hidden max-h-[80vh] overflow-y-auto scrollbar-thin">
          {children}
        </div>
      </div>
    </div>
  );
};
