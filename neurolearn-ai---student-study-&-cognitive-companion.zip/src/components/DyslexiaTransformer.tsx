import React, { useState } from 'react';
import { 
  BookOpen, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  FileText, 
  Network, 
  Lightbulb, 
  HelpCircle, 
  CheckCircle2, 
  RotateCcw, 
  Loader2, 
  Layers, 
  Copy, 
  Check,
  Type,
  Share2
} from 'lucide-react';
import { TransformedContent, UserPreferences, Flashcard, QuizQuestion } from '../types';
import { formatBionicText } from '../utils/bionic';
import { speakText, stopSpeech, soundSynth } from '../utils/audio';

interface DyslexiaTransformerProps {
  prefs: UserPreferences;
  onSaveFlashcards?: (cards: Flashcard[]) => void;
}

const SAMPLE_TEXT = `Photosynthesis is the process by which green plants, algae, and certain bacteria convert light energy into chemical energy. During photosynthesis, light energy is captured and used to convert water, carbon dioxide, and minerals into oxygen and energy-rich organic compounds such as glucose. Photosynthesis takes place in chloroplasts, which contain chlorophyll. Chlorophyll absorbs solar radiation, triggering light-dependent reactions in the thylakoid membranes where water molecules are split into hydrogen and oxygen. The Calvin cycle then takes over in the stroma to produce sugar molecules.`;

export const DyslexiaTransformer: React.FC<DyslexiaTransformerProps> = ({ prefs, onSaveFlashcards }) => {
  const [inputText, setInputText] = useState('');
  const [grade, setGrade] = useState('High School');
  const [subject, setSubject] = useState('Science');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<TransformedContent | null>(null);
  const [activeTab, setActiveTab] = useState<'bionic' | 'summary' | 'mindmap' | 'mnemonics' | 'flashcards' | 'quiz'>('bionic');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [flippedCards, setFlippedCards] = useState<Record<number, boolean>>({});
  const [selectedQuizAnswers, setSelectedQuizAnswers] = useState<Record<number, number>>({});
  const [copied, setCopied] = useState(false);

  const handleTransform = async () => {
    const content = inputText.trim() || SAMPLE_TEXT;
    setLoading(true);
    try {
      const res = await fetch('/api/ai/transform-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: content,
          targetGrade: grade,
          subject: subject
        })
      });

      if (!res.ok) {
        throw new Error(`HTTP Error ${res.status}`);
      }

      const responseData = await res.json();
      if (responseData.result) {
        setData(responseData.result);
        setActiveTab('bionic');
      } else {
        throw new Error("Transformation payload invalid.");
      }
    } catch (e) {
      console.warn("Using offline fallback text transformer engine:", e);
      const fallbackData: TransformedContent = {
        dyslexiaFriendlyText: content,
        simplifiedSummary: [
          "Key Concept: Focus on core definitions and step-by-step mechanisms.",
          "Memory Anchor: Use visual mind maps and short micro-sprints.",
          "Active Testing: Practice self-quizzing after reading each paragraph."
        ],
        visualMindMap: [
          { id: "1", label: subject || "Core Topic", description: "Main concept overview", parentId: null },
          { id: "2", label: "Fundamental Principle", description: "Core rule and mechanics", parentId: "1" },
          { id: "3", label: "Practical Application", description: "Real-world exam example", parentId: "1" }
        ],
        mnemonics: [
          `Visual Anchor: Connect ${subject || 'this topic'} with a memorable physical object!`,
          `Syllable Chunking: Break multi-syllable terms into distinct phonetic parts.`
        ],
        flashcards: [
          { id: "fc-1", question: `What is the core idea of this passage?`, answer: content.slice(0, 120) + '...', hint: "Check the first sentence", memoryTag: subject || "Study Note" }
        ],
        quiz: [
          { id: "q-1", question: `Which method best aids memory retention when studying complex text?`, options: ["Spaced active recall with visual mind maps", "Reading without breaks for 5 hours", "Cramming right before sleep", "Skipping definitions"], correctIndex: 0, explanation: "Spaced recall and visual chunking strengthen memory pathways!" }
        ],
        studyTip: "Read aloud using Bionic font highlighting to engage both visual and auditory memory centers."
      };
      setData(fallbackData);
      setActiveTab('bionic');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleAudio = (textToRead: string) => {
    if (isPlayingAudio) {
      stopSpeech();
      setIsPlayingAudio(false);
    } else {
      setIsPlayingAudio(true);
      speakText(textToRead, prefs.speechSpeed, () => {
        setIsPlayingAudio(false);
      });
    }
  };

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const bionicWords = data ? formatBionicText(data.dyslexiaFriendlyText) : [];

  return (
    <div role="region" aria-label="Adaptive Text Transformer & Dyslexia Studio" className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 md:p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-indigo-100 dark:bg-indigo-950/80 rounded-xl text-indigo-600 dark:text-indigo-400">
            <BookOpen className="w-6 h-6" aria-hidden="true" />
          </div>
          <div>
            <h2 className="text-lg md:text-xl font-bold text-slate-900 dark:text-white">
              Adaptive Text Transformer & Dyslexia Studio
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Pasting textbook paragraphs converts them into Bionic reading, mind maps, mnemonics, and flashcards.
            </p>
          </div>
        </div>

        <button
          onClick={() => setInputText(SAMPLE_TEXT)}
          aria-label="Load Biology Sample Text"
          className="text-xs text-indigo-600 dark:text-indigo-400 font-medium hover:underline flex items-center space-x-1"
        >
          <span>Load Biology Sample</span>
        </button>
      </div>

      {/* Input Form */}
      <div className="space-y-3 mb-6">
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          aria-label="Textbook passage or reading material to transform"
          placeholder="Paste textbook paragraph, study guide notes, or difficult reading material here..."
          rows={4}
          className="w-full text-xs md:text-sm p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all font-sans"
        />

        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <select
              value={grade}
              onChange={(e) => setGrade(e.target.value)}
              className="text-xs p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
            >
              <option value="Elementary">Elementary School</option>
              <option value="Middle School">Middle School</option>
              <option value="High School">High School</option>
              <option value="College">College Level</option>
            </select>

            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="text-xs p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium"
            >
              <option value="Science">Science / Biology</option>
              <option value="History">History / Social Studies</option>
              <option value="Literature">Literature / English</option>
              <option value="Mathematics">Math / Formulas</option>
              <option value="General">General Homework</option>
            </select>
          </div>

          <button
            onClick={handleTransform}
            disabled={loading}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-md shadow-indigo-500/20 transition-all flex items-center space-x-2 disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Creating Dyslexia & Memory Pack...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Adapt For My Brain</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Results View */}
      {data && (
        <div className="mt-6 border-t border-slate-200 dark:border-slate-800 pt-6 animate-in fade-in duration-300">
          {/* Navigation Tabs */}
          <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3 mb-6">
            <button
              onClick={() => setActiveTab('bionic')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1.5 transition-all ${
                activeTab === 'bionic'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              <Type className="w-3.5 h-3.5" />
              <span>Bionic Reading</span>
            </button>

            <button
              onClick={() => setActiveTab('summary')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1.5 transition-all ${
                activeTab === 'summary'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>3-Line Summary</span>
            </button>

            <button
              onClick={() => setActiveTab('mindmap')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1.5 transition-all ${
                activeTab === 'mindmap'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              <Network className="w-3.5 h-3.5" />
              <span>Concept Tree</span>
            </button>

            <button
              onClick={() => setActiveTab('mnemonics')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1.5 transition-all ${
                activeTab === 'mnemonics'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              <Lightbulb className="w-3.5 h-3.5" />
              <span>Memory Mnemonics</span>
            </button>

            <button
              onClick={() => setActiveTab('flashcards')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1.5 transition-all ${
                activeTab === 'flashcards'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Flashcards ({data.flashcards.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('quiz')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1.5 transition-all ${
                activeTab === 'quiz'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Practice Quiz</span>
            </button>
          </div>

          {/* TAB 1: BIONIC & DYSLEXIA TEXT */}
          {activeTab === 'bionic' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Multi-Sensory Text Reader
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleToggleAudio(data.dyslexiaFriendlyText.replace(/[*#_]/g, ''))}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1.5 transition-all ${
                      isPlayingAudio ? 'bg-amber-500 text-white animate-pulse' : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {isPlayingAudio ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    <span>{isPlayingAudio ? 'Pause Voice' : 'Read Aloud'}</span>
                  </button>

                  <button
                    onClick={() => handleCopyText(data.dyslexiaFriendlyText)}
                    className="p-1.5 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div 
                className={`p-5 rounded-xl border bg-slate-50/70 dark:bg-slate-800/50 leading-relaxed transition-all ${
                  prefs.dyslexicFont ? 'font-dyslexic tracking-wide leading-loose text-base' : 'text-sm md:text-base'
                }`}
              >
                {prefs.bionicHighlight ? (
                  <p className="text-slate-800 dark:text-slate-200">
                    {bionicWords.map((wordObj, idx) => (
                      <React.Fragment key={idx}>
                        <span className="font-bold text-slate-950 dark:text-white">{wordObj.boldPart}</span>
                        <span>{wordObj.regularPart}</span>
                      </React.Fragment>
                    ))}
                  </p>
                ) : (
                  <p className="text-slate-800 dark:text-slate-200 whitespace-pre-wrap">
                    {data.dyslexiaFriendlyText}
                  </p>
                )}
              </div>

              {data.studyTip && (
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200 flex items-start space-x-2">
                  <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Psychological Memory Tip: </span>
                    {data.studyTip}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: 3-LINE SUMMARY */}
          {activeTab === 'summary' && (
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Essential Takeaways
              </h3>
              <div className="space-y-2">
                {data.simplifiedSummary.map((bullet, idx) => (
                  <div key={idx} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-start space-x-3">
                    <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                      {idx + 1}
                    </div>
                    <p className="text-xs md:text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-medium">
                      {bullet}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: CONCEPT TREE / MIND MAP */}
          {activeTab === 'mindmap' && (
            <div className="space-y-4">
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Visual Spatial Tree
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {data.visualMindMap.map((node) => (
                  <div
                    key={node.id}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-gradient-to-br from-indigo-50/50 to-teal-50/50 dark:from-slate-800/80 dark:to-slate-800/30"
                  >
                    <div className="flex items-center space-x-2 mb-1">
                      <Network className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                      <h4 className="font-bold text-xs md:text-sm text-slate-900 dark:text-white">
                        {node.label}
                      </h4>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400 pl-6">
                      {node.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: MNEMONICS */}
          {activeTab === 'mnemonics' && (
            <div className="space-y-3">
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Memory Hooks & Rhymes
              </h3>
              <div className="grid grid-cols-1 gap-3">
                {data.mnemonics.map((item, idx) => (
                  <div key={idx} className="p-4 rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/50 dark:bg-amber-950/20 flex items-start space-x-3">
                    <Lightbulb className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                    <p className="text-xs md:text-sm text-amber-950 dark:text-amber-200 font-medium leading-relaxed">
                      {item}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: FLASHCARDS */}
          {activeTab === 'flashcards' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Memory Flip Deck
                </h3>
                {onSaveFlashcards && (
                  <button
                    onClick={() => onSaveFlashcards(data.flashcards)}
                    className="text-xs text-indigo-600 dark:text-indigo-400 font-medium hover:underline"
                  >
                    Save to My Saved Decks
                  </button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {data.flashcards.map((card, idx) => {
                  const isFlipped = !!flippedCards[idx];
                  return (
                    <div
                      key={idx}
                      onClick={() => setFlippedCards(prev => ({ ...prev, [idx]: !prev[idx] }))}
                      className="cursor-pointer h-44 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800 p-4 flex flex-col justify-between hover:border-indigo-500 transition-all shadow-xs relative"
                    >
                      <div className="flex items-center justify-between text-[10px] text-slate-400 font-medium">
                        <span>Card #{idx + 1}</span>
                        <span className="uppercase tracking-wider">{card.memoryTag || 'Key Concept'}</span>
                      </div>

                      <div className="text-center my-auto">
                        {!isFlipped ? (
                          <p className="text-xs md:text-sm font-semibold text-slate-900 dark:text-white">
                            {card.question}
                          </p>
                        ) : (
                          <p className="text-xs md:text-sm text-indigo-700 dark:text-indigo-300 font-medium animate-in fade-in">
                            {card.answer}
                          </p>
                        )}
                      </div>

                      <div className="text-[10px] text-slate-400 text-center font-medium">
                        {isFlipped ? 'Click to show Question' : 'Click to Flip Answer'}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 6: QUIZ */}
          {activeTab === 'quiz' && (
            <div className="space-y-6">
              <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Practice Quiz
              </h3>

              <div className="space-y-6">
                {data.quiz.map((q, qIdx) => {
                  const answeredIdx = selectedQuizAnswers[qIdx];
                  const hasAnswered = answeredIdx !== undefined;

                  return (
                    <div key={qIdx} className="p-4 md:p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
                      <p className="text-xs md:text-sm font-bold text-slate-900 dark:text-white mb-3">
                        Q{qIdx + 1}. {q.question}
                      </p>

                      <div className="space-y-2 mb-3">
                        {q.options.map((option, optIdx) => {
                          let btnStyle = "border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:border-indigo-400";
                          if (hasAnswered) {
                            if (optIdx === q.correctIndex) {
                              btnStyle = "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-900 dark:text-emerald-200 font-bold";
                            } else if (optIdx === answeredIdx) {
                              btnStyle = "border-rose-500 bg-rose-50 dark:bg-rose-950/60 text-rose-900 dark:text-rose-200";
                            }
                          }

                          return (
                            <button
                              key={optIdx}
                              disabled={hasAnswered}
                              onClick={() => {
                                setSelectedQuizAnswers(prev => ({ ...prev, [qIdx]: optIdx }));
                                soundSynth.playChime(optIdx === q.correctIndex);
                              }}
                              className={`w-full text-left text-xs p-3 rounded-lg border transition-all ${btnStyle}`}
                            >
                              {option}
                            </button>
                          );
                        })}
                      </div>

                      {hasAnswered && (
                        <div className="p-3 rounded-lg bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-100 dark:border-indigo-900 text-xs text-indigo-900 dark:text-indigo-200 animate-in fade-in">
                          <span className="font-bold">Explanation: </span>
                          {q.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
