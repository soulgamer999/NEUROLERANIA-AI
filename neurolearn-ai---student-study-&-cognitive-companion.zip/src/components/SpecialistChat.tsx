import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Brain, 
  Sparkles, 
  User, 
  Bot, 
  HelpCircle, 
  Loader2, 
  RefreshCw,
  Heart
} from 'lucide-react';
import { ChatMessage, Persona, UserPreferences, AIEmotionTone } from '../types';
import { speakText, stopSpeech } from '../utils/audio';

interface SpecialistChatProps {
  prefs: UserPreferences;
}

const PERSONAS = [
  {
    id: 'dr_mind' as Persona,
    name: 'Dr. Mind',
    role: 'Educational Psychologist',
    desc: 'Empathetic guidance for study stress, frustration, & dyslexia confidence.',
    icon: Brain,
    color: 'from-amber-500 to-rose-500'
  },
  {
    id: 'socratic' as Persona,
    name: 'Socrates',
    role: 'Socratic Tutor',
    desc: 'Teaches by asking friendly questions so concept clicks in your head.',
    icon: HelpCircle,
    color: 'from-indigo-600 to-blue-500'
  },
  {
    id: 'dyslexia_coach' as Persona,
    name: 'Phonics & Dyslexia Coach',
    role: 'Reading & Memory Specialist',
    desc: 'Short sentences, visual stories, & phonetic breakdowns.',
    icon: Sparkles,
    color: 'from-emerald-500 to-teal-600'
  },
  {
    id: 'adhd_coach' as Persona,
    name: 'Focus Coach',
    role: 'ADHD & Executive Function',
    desc: 'Break big homework into 5-minute easy micro-challenges.',
    icon: Heart,
    color: 'from-purple-600 to-indigo-600'
  }
];

const EMOTION_TONES: { id: AIEmotionTone; label: string; icon: string; desc: string }[] = [
  { id: 'encouragement', label: 'Encouraging', icon: '🌟', desc: 'Warm, uplifting & confidence building' },
  { id: 'empathy', label: 'Gentle Empathy', icon: '❤️', desc: 'Validating stress, compassionate listening' },
  { id: 'curiosity', label: 'Curious & Awe', icon: '🔍', desc: 'Inquisitive, fascinating wonder & "what-ifs"' },
  { id: 'socratic', label: 'Socratic Probing', icon: '💡', desc: 'Guides with thought-provoking questions' },
  { id: 'calm_zen', label: 'Calm & Zen', icon: '🧘', desc: 'Low anxiety, slow pace, relaxing focus' },
  { id: 'energetic_hype', label: 'Energetic Hype', icon: '⚡', desc: 'High energy esports coach excitement' },
  { id: 'analytical_direct', label: 'Analytical & Direct', icon: '📊', desc: 'Concise, logical, no-fluff steps' },
  { id: 'constructive_challenge', label: 'Constructive Challenge', icon: '🎯', desc: 'Pushes limits & challenges logic' }
];

const QUICK_PROMPTS = [
  "I feel super overwhelmed by my study material.",
  "I read a paragraph 3 times and still don't remember it.",
  "Can you teach me Photosynthesis with a fun story?",
  "I get nervous before exams. How can I calm my brain?"
];

export const SpecialistChat: React.FC<SpecialistChatProps> = ({ prefs }) => {
  const [persona, setPersona] = useState<Persona>('dr_mind');
  const [emotionTone, setEmotionTone] = useState<AIEmotionTone>(prefs.aiEmotionTone || 'encouragement');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      text: "Hello! I'm Dr. Mind, your AI Educational Psychologist & Study Specialist. I can adapt my emotional delivery tone (Encouraging, Gentle Empathy, Curious, Socratic, Zen Calm, Energetic Hype, Analytical, or Constructive Challenge). How are your studies feeling today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      persona: 'dr_mind'
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [playingMsgId, setPlayingMsgId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const currentPersonaInfo = PERSONAS.find(p => p.id === persona) || PERSONAS[0];
  const currentToneInfo = EMOTION_TONES.find(t => t.id === emotionTone) || EMOTION_TONES[0];

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || input).trim();
    if (!query || loading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setLoading(true);

    try {
      const history = messages.slice(-6).map(m => ({
        role: m.role,
        text: m.text
      }));

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history,
          persona,
          emotionTone,
          learningProfile: { style: prefs.dyslexicFont ? 'Dyslexia' : 'Standard' }
        })
      });

      if (!res.ok) {
        throw new Error(`HTTP Error ${res.status}`);
      }

      const data = await res.json();
      if (data.reply) {
        const botMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          text: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          persona
        };
        setMessages(prev => [...prev, botMsg]);
      } else {
        throw new Error("No reply content returned.");
      }
    } catch (e) {
      console.warn("Using offline specialist response fallback:", e);
      const fallbackMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        text: `I understand you are asking about: "${query}". As your AI Educational Specialist, here is a quick 3-step action plan:\n\n1. **Take a 30-Second Deep Breath**: Inhale for 4 seconds, exhale for 4 seconds.\n2. **Break it Down**: Divide "${query}" into two tiny 10-minute micro-sprints.\n3. **Use Visual Anchors**: Sketch a quick diagram or mind map of the core idea.\n\nHow does this feel for your study routine right now?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        persona
      };
      setMessages(prev => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  const toggleMic = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    if (isRecording) {
      setIsRecording(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => setIsRecording(true);
    recognition.onend = () => setIsRecording(false);
    recognition.onerror = () => setIsRecording(false);

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput(prev => (prev ? prev + ' ' + transcript : transcript));
    };

    recognition.start();
  };

  const handleSpeechOutput = (msgId: string, text: string) => {
    if (playingMsgId === msgId) {
      stopSpeech();
      setPlayingMsgId(null);
    } else {
      setPlayingMsgId(msgId);
      speakText(text, prefs.speechSpeed, () => {
        setPlayingMsgId(null);
      });
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 md:p-6 shadow-sm flex flex-col h-[650px]">
      {/* Header & Persona Selector */}
      <div className="border-b border-slate-200 dark:border-slate-800 pb-4 mb-4">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
          <div className="flex items-center space-x-2">
            <div className={`p-2 rounded-xl bg-gradient-to-r ${currentPersonaInfo.color} text-white`}>
              <currentPersonaInfo.icon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                {currentPersonaInfo.name} ({currentPersonaInfo.role})
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {currentPersonaInfo.desc}
              </p>
            </div>
          </div>
        </div>

        {/* Persona Switcher Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          {PERSONAS.map((p) => {
            const active = persona === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setPersona(p.id)}
                className={`p-2 rounded-xl border text-left transition-all ${
                  active
                    ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-950 dark:text-indigo-200 font-semibold shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <div className="text-xs font-bold truncate">{p.name}</div>
                <div className="text-[10px] text-slate-400 truncate">{p.role}</div>
              </button>
            );
          })}
        </div>

        {/* AI Emotional Delivery Mode Bar */}
        <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1">
              <span>🎭</span> Active AI Emotion Delivery Mode:
            </span>
            <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1 bg-indigo-50 dark:bg-indigo-950/80 px-2 py-0.5 rounded-full border border-indigo-200 dark:border-indigo-800">
              <span>{currentToneInfo.icon}</span>
              <span>{currentToneInfo.label}</span>
            </span>
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {EMOTION_TONES.map((t) => {
              const active = emotionTone === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setEmotionTone(t.id)}
                  title={t.desc}
                  className={`px-2.5 py-1 rounded-xl text-xs font-bold whitespace-nowrap flex items-center space-x-1.5 transition-all shrink-0 ${
                    active
                      ? 'bg-indigo-600 text-white shadow-xs scale-105'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <span>{t.icon}</span>
                  <span>{t.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-1">
        {messages.map((m) => {
          const isUser = m.role === 'user';
          return (
            <div
              key={m.id}
              className={`flex items-start space-x-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className={`w-8 h-8 rounded-xl bg-gradient-to-r ${currentPersonaInfo.color} text-white flex items-center justify-center shrink-0 mt-1 shadow-xs`}>
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-3.5 text-xs md:text-sm leading-relaxed ${
                isUser
                  ? 'bg-indigo-600 text-white rounded-tr-none'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200/60 dark:border-slate-700/60 rounded-tl-none'
              }`}>
                <div className="whitespace-pre-wrap">{m.text}</div>

                <div className="flex items-center justify-between mt-2 pt-1 border-t border-black/5 dark:border-white/5 text-[10px] opacity-75">
                  <span>{m.timestamp}</span>
                  {!isUser && (
                    <button
                      onClick={() => handleSpeechOutput(m.id, m.text)}
                      className="hover:opacity-100 p-0.5"
                      title="Listen to message"
                    >
                      {playingMsgId === m.id ? (
                        <VolumeX className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                      ) : (
                        <Volume2 className="w-3.5 h-3.5" />
                      )}
                    </button>
                  )}
                </div>
              </div>

              {isUser && (
                <div className="w-8 h-8 rounded-xl bg-slate-700 text-white flex items-center justify-center shrink-0 mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {loading && (
          <div className="flex items-center space-x-2 text-xs text-slate-400 p-2">
            <Loader2 className="w-4 h-4 animate-spin text-indigo-500" />
            <span>{currentPersonaInfo.name} is thinking...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Suggestions */}
      {messages.length <= 3 && (
        <div className="py-2 overflow-x-auto flex space-x-2 scrollbar-none border-t border-slate-100 dark:border-slate-800">
          {QUICK_PROMPTS.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(qp)}
              className="px-2.5 py-1 rounded-full text-[11px] bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 hover:text-indigo-600 text-slate-600 dark:text-slate-300 whitespace-nowrap transition-colors"
            >
              {qp}
            </button>
          ))}
        </div>
      )}

      {/* Input Bar */}
      <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center space-x-2">
        <button
          onClick={toggleMic}
          className={`p-2.5 rounded-xl border transition-all ${
            isRecording
              ? 'bg-rose-500 text-white border-rose-500 animate-pulse'
              : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
          title="Speak your question"
        >
          {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>

        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder={`Ask ${currentPersonaInfo.name} anything about your studies...`}
          className="flex-1 text-xs md:text-sm p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />

        <button
          onClick={() => handleSend()}
          disabled={!input.trim() || loading}
          className="p-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl disabled:opacity-50 transition-all shadow-xs"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
