import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { motion, AnimatePresence } from 'motion/react';
import { Trophy, Award, Sparkles, Star, CheckCircle, Zap, ShieldCheck } from 'lucide-react';
import { AchievementBadge } from '../types';
import { soundSynth } from '../utils/audio';

const INITIAL_BADGES: AchievementBadge[] = [
  {
    id: 'streak_3',
    title: 'Consistent Scholar',
    description: 'Maintained a 3-day study streak with daily focus check-ins.',
    icon: '🏆',
    category: 'streak',
    unlocked: true,
    unlockedAt: 'Aug 6, 2026',
    progress: 3,
    maxProgress: 3,
  },
  {
    id: 'focus_45',
    title: 'Deep Focus Master',
    description: 'Completed over 45 minutes of sustained focus session time.',
    icon: '⚡',
    category: 'focus',
    unlocked: true,
    unlockedAt: 'Aug 7, 2026',
    progress: 45,
    maxProgress: 45,
  },
  {
    id: 'math_pioneer',
    title: 'Math Pathfinder',
    description: 'Visualized a complex equation step-by-step in Dyscalculia mode.',
    icon: '🧮',
    category: 'subject',
    unlocked: true,
    unlockedAt: 'Aug 8, 2026',
    progress: 1,
    maxProgress: 1,
  },
  {
    id: 'scribe_master',
    title: 'Scribe Pioneer',
    description: 'Dictated thoughts into structured sentences with Voice Scribe.',
    icon: '✍️',
    category: 'subject',
    unlocked: true,
    unlockedAt: 'Aug 8, 2026',
    progress: 1,
    maxProgress: 1,
  },
  {
    id: 'mindfulness_zen',
    title: 'Mindfulness Champion',
    description: 'Logged a daily reflection and grounding exercise in Stress Relief.',
    icon: '🧘',
    category: 'mindset',
    unlocked: false,
    progress: 0,
    maxProgress: 1,
  },
  {
    id: 'robo_explorer',
    title: 'Robo-Class Voyager',
    description: 'Completed an interactive lesson with the AI Robot Teacher.',
    icon: '🤖',
    category: 'subject',
    unlocked: true,
    unlockedAt: 'Aug 8, 2026',
    progress: 1,
    maxProgress: 1,
  },
];

export const MilestonesSystem: React.FC = () => {
  const [badges, setBadges] = useState<AchievementBadge[]>(INITIAL_BADGES);
  const [celebratingBadge, setCelebratingBadge] = useState<AchievementBadge | null>(null);

  const triggerCelebration = (badge: AchievementBadge) => {
    setCelebratingBadge(badge);

    // Confetti burst
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#10b981', '#6366f1', '#f59e0b', '#ec4899'],
    });

    // Triumphant sound chord
    soundSynth.playTone(523.25, 'triangle', 0.2); // C5
    setTimeout(() => soundSynth.playTone(659.25, 'triangle', 0.2), 150); // E5
    setTimeout(() => soundSynth.playTone(783.99, 'triangle', 0.4), 300); // G5
  };

  const handleUnlockBadge = (badgeId: string) => {
    setBadges((prev) =>
      prev.map((b) => {
        if (b.id === badgeId && !b.unlocked) {
          const updated = { ...b, unlocked: true, unlockedAt: 'Just Now', progress: b.maxProgress };
          triggerCelebration(updated);
          return updated;
        }
        return b;
      })
    );
  };

  const unlockedCount = badges.filter((b) => b.unlocked).length;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-amber-100 dark:bg-amber-950/80 rounded-xl text-amber-600 dark:text-amber-400">
            <Trophy className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Learning Milestones & Achievement Badges</span>
              <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Celebrate neurodiverse cognitive growth and consistent study streaks
            </p>
          </div>
        </div>

        {/* Level & XP Badge */}
        <div className="flex items-center space-x-2 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 px-3.5 py-1.5 rounded-xl">
          <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
          <div>
            <p className="text-xs font-black text-amber-900 dark:text-amber-200">
              Level 3 Scholar ({unlockedCount}/{badges.length} Unlocked)
            </p>
            <p className="text-[10px] text-amber-700 dark:text-amber-300">
              350 / 500 XP to Level 4
            </p>
          </div>
        </div>
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {badges.map((badge) => (
          <motion.div
            key={badge.id}
            whileHover={{ scale: 1.02 }}
            className={`p-4 rounded-xl border transition-all flex items-start space-x-3 relative overflow-hidden ${
              badge.unlocked
                ? 'bg-gradient-to-br from-amber-50/60 to-orange-50/30 dark:from-amber-950/30 dark:to-slate-900 border-amber-200 dark:border-amber-800/60 shadow-xs'
                : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-75'
            }`}
          >
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl shrink-0 shadow-xs ${
              badge.unlocked ? 'bg-amber-100 dark:bg-amber-900/60' : 'bg-slate-200 dark:bg-slate-700 grayscale'
            }`}>
              {badge.icon}
            </div>

            <div className="space-y-1 flex-1">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-extrabold text-slate-900 dark:text-white">
                  {badge.title}
                </h3>
                {badge.unlocked ? (
                  <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                ) : (
                  <button
                    onClick={() => handleUnlockBadge(badge.id)}
                    className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500 hover:bg-amber-600 text-white shadow-xs"
                  >
                    Unlock
                  </button>
                )}
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-snug">
                {badge.description}
              </p>

              {badge.unlocked ? (
                <p className="text-[10px] font-bold text-amber-700 dark:text-amber-400 pt-0.5">
                  Unlocked {badge.unlockedAt}
                </p>
              ) : (
                <div className="pt-1">
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-amber-500 h-full rounded-full"
                      style={{ width: `${(badge.progress / badge.maxProgress) * 100}%` }}
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Progress: {badge.progress} / {badge.maxProgress}
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Celebratory Modal Pop-up */}
      <AnimatePresence>
        {celebratingBadge && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs"
          >
            <motion.div
              initial={{ scale: 0.8, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 20 }}
              className="bg-white dark:bg-slate-900 border-2 border-amber-400 rounded-2xl p-6 max-w-sm w-full text-center shadow-2xl space-y-4"
            >
              <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-tr from-amber-400 to-orange-500 flex items-center justify-center text-4xl shadow-lg animate-bounce">
                {celebratingBadge.icon}
              </div>

              <div>
                <span className="text-[10px] font-extrabold uppercase tracking-widest text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-950 px-2.5 py-1 rounded-full">
                  Achievement Unlocked!
                </span>
                <h3 className="text-lg font-black text-slate-900 dark:text-white mt-2">
                  {celebratingBadge.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                  {celebratingBadge.description}
                </p>
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-800 text-xs font-bold text-amber-900 dark:text-amber-200">
                🎉 +100 XP added to your NeuroLearn Profile!
              </div>

              <button
                onClick={() => setCelebratingBadge(null)}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs shadow-md transition-all"
              >
                Continue Learning
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
