import React, { useState, useEffect } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Clock, 
  Wind, 
  CheckCircle, 
  Zap,
  Coffee
} from 'lucide-react';
import { soundSynth } from '../utils/audio';

import { SessionRecapData } from '../types';

interface FocusTimerProps {
  activeNoise: 'brown' | 'binaural' | 'rain' | 'off';
  onChangeNoise: (type: 'brown' | 'binaural' | 'rain' | 'off') => void;
  onSessionComplete?: (recap: SessionRecapData) => void;
}

export const FocusTimer: React.FC<FocusTimerProps> = ({ activeNoise, onChangeNoise, onSessionComplete }) => {
  const [selectedMinutes, setSelectedMinutes] = useState(15); // ADHD friendly 15 min default
  const [timeLeft, setTimeLeft] = useState(15 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState<'sprint' | 'break' | 'breathing'>('sprint');
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale' | 'Rest'>('Inhale');
  const [completedSprints, setCompletedSprints] = useState(0);

  const triggerRecapModal = () => {
    if (onSessionComplete) {
      onSessionComplete({
        sessionTimeMinutes: selectedMinutes,
        mentalBatteryRemaining: 84,
        conceptsMastered: [
          'Subitizing Dot Groupings',
          'Bionic Typography Speed',
          'Active Recall Spacing'
        ],
        suggestedNextTopic: 'Multi-Step Equation Visualizer & Step Reframing',
        xpEarned: 75
      });
    }
  };

  useEffect(() => {
    let timer: any = null;
    if (isRunning && timeLeft > 0) {
      timer = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (isRunning && timeLeft === 0) {
      setIsRunning(false);
      soundSynth.playChime(true);
      if (mode === 'sprint') {
        setCompletedSprints(prev => prev + 1);
        triggerRecapModal();
        setMode('break');
        setTimeLeft(5 * 60);
      } else {
        setMode('sprint');
        setTimeLeft(selectedMinutes * 60);
      }
    }
    return () => clearInterval(timer);
  }, [isRunning, timeLeft, mode, selectedMinutes]);


  // Breathing exercise cycle
  useEffect(() => {
    let breathTimer: any = null;
    if (mode === 'breathing') {
      const phases: ('Inhale' | 'Hold' | 'Exhale' | 'Rest')[] = ['Inhale', 'Hold', 'Exhale', 'Rest'];
      let step = 0;
      breathTimer = setInterval(() => {
        step = (step + 1) % 4;
        setBreathPhase(phases[step]);
      }, 4000); // 4-4-4-4 box breathing
    }
    return () => clearInterval(breathTimer);
  }, [mode]);

  const handleSetDuration = (mins: number) => {
    setSelectedMinutes(mins);
    setTimeLeft(mins * 60);
    setIsRunning(false);
    setMode('sprint');
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(selectedMinutes * 60);
  };

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const progressPercent = ((selectedMinutes * 60 - timeLeft) / (selectedMinutes * 60)) * 100;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 md:p-6 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-amber-100 dark:bg-amber-950/80 rounded-xl text-amber-600 dark:text-amber-400">
            <Zap className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg md:text-xl font-bold text-slate-900 dark:text-white">
              ADHD Micro-Sprint & Focus Wave
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Low-friction 10-15 min study blocks paired with soothing audio to beat procrastination.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setMode(mode === 'breathing' ? 'sprint' : 'breathing')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              mode === 'breathing'
                ? 'bg-teal-600 text-white'
                : 'bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800'
            }`}
          >
            <Wind className="w-3.5 h-3.5" />
            <span>60s Anxiety Reset</span>
          </button>
        </div>
      </div>

      {mode !== 'breathing' ? (
        <div className="flex flex-col items-center justify-center py-4 space-y-6">
          {/* Preset Buttons */}
          <div className="flex flex-wrap justify-center gap-2">
            {[10, 15, 25, 45].map((m) => (
              <button
                key={m}
                onClick={() => handleSetDuration(m)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedMinutes === m && mode === 'sprint'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
                }`}
              >
                {m}m Micro-Sprint
              </button>
            ))}
          </div>

          {/* Circle Clock Visual */}
          <div className="relative w-48 h-48 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="96"
                cy="96"
                r="88"
                className="stroke-slate-200 dark:stroke-slate-800"
                strokeWidth="10"
                fill="transparent"
              />
              <circle
                cx="96"
                cy="96"
                r="88"
                className="stroke-indigo-600 dark:stroke-indigo-400 transition-all duration-1000"
                strokeWidth="10"
                strokeDasharray={2 * Math.PI * 88}
                strokeDashoffset={2 * Math.PI * 88 * (1 - progressPercent / 100)}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>

            <div className="absolute flex flex-col items-center">
              <span className="text-4xl font-extrabold text-slate-900 dark:text-white font-mono tracking-wider">
                {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
              </span>
              <span className="text-[11px] font-semibold uppercase tracking-widest text-slate-400 mt-1">
                {mode === 'sprint' ? 'Hyper-Focus' : 'Brain Rest'}
              </span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setIsRunning(!isRunning)}
              className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-teal-600 hover:from-indigo-700 hover:to-teal-700 text-white font-bold rounded-2xl shadow-md transition-all flex items-center space-x-2 active:scale-95 text-sm"
            >
              {isRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
              <span>{isRunning ? 'Pause Sprint' : 'Start Focus Sprint'}</span>
            </button>

            <button
              onClick={handleReset}
              className="p-3 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800"
              title="Reset Timer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

          {/* Sound Controls */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 max-w-md w-full">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center space-x-1.5">
                <Volume2 className="w-4 h-4 text-amber-500" />
                <span>Focus Sound generator:</span>
              </span>
              <span className="text-[10px] uppercase font-bold text-slate-400">
                {activeNoise}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              {[
                { id: 'off', label: 'Mute' },
                { id: 'brown', label: 'Brown Noise' },
                { id: 'binaural', label: 'Alpha 40Hz' },
                { id: 'rain', label: 'Soft Rain' }
              ].map((s) => (
                <button
                  key={s.id}
                  onClick={() => onChangeNoise(s.id as any)}
                  className={`p-2 rounded-lg text-xs font-medium text-center border transition-all ${
                    activeNoise === s.id
                      ? 'bg-amber-500 text-white border-amber-500 font-bold shadow-xs'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-slate-500 font-medium">
            <span className="flex items-center space-x-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-500" />
              <span>Completed Micro-Sprints Today: <strong className="text-slate-900 dark:text-white font-bold">{completedSprints}</strong></span>
            </span>

            <button
              onClick={triggerRecapModal}
              className="px-3 py-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-200 font-bold border border-emerald-300 dark:border-emerald-800 transition-all flex items-center space-x-1"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
              <span>Finish & View Session Recap</span>
            </button>
          </div>

        </div>
      ) : (
        /* Box Breathing Exercise */
        <div className="py-8 flex flex-col items-center justify-center text-center space-y-6">
          <div className="w-48 h-48 rounded-full border-4 border-teal-400/30 flex items-center justify-center relative animate-pulse bg-teal-500/10">
            <div className="text-center">
              <Wind className="w-8 h-8 text-teal-500 mx-auto mb-2 animate-bounce" />
              <span className="text-2xl font-extrabold text-teal-600 dark:text-teal-300 block">
                {breathPhase}
              </span>
              <span className="text-xs text-slate-400">Box Breathing (4-4-4-4)</span>
            </div>
          </div>

          <p className="text-xs max-w-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            Slow down your heart rate and release study panic. Follow the circle rhythm: Inhale deeply for 4s, hold for 4s, release for 4s.
          </p>

          <button
            onClick={() => setMode('sprint')}
            className="px-5 py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium text-xs rounded-xl shadow-xs"
          >
            Return to Study Sprint
          </button>
        </div>
      )}
    </div>
  );
};
