import React, { useState, useEffect } from 'react';
import { Flame, Trophy, CalendarCheck, Zap, Award } from 'lucide-react';
import confetti from 'canvas-confetti';

interface FocusStreakData {
  streak: number;
  lastCompletedDate: string; // YYYY-MM-DD
  completedToday: boolean;
  history: string[]; // List of YYYY-MM-DD completed
  milestonesReached: number[];
}

export const FocusStreakCounter: React.FC = () => {
  const getTodayString = () => new Date().toISOString().split('T')[0];

  const [streakData, setStreakData] = useState<FocusStreakData>(() => {
    const saved = localStorage.getItem('neurolearn_focus_streak');
    const today = getTodayString();
    if (saved) {
      try {
        const parsed: FocusStreakData = JSON.parse(saved);
        // Check if last completed date was yesterday, today, or earlier
        if (parsed.lastCompletedDate) {
          const last = new Date(parsed.lastCompletedDate);
          const now = new Date(today);
          const diffDays = Math.floor((now.getTime() - last.getTime()) / (1000 * 3600 * 24));

          if (diffDays === 0) {
            parsed.completedToday = true;
          } else if (diffDays === 1) {
            parsed.completedToday = false;
          } else if (diffDays > 1) {
            // Missed more than a day, streak resets to 0 (unless completed today)
            parsed.streak = 0;
            parsed.completedToday = false;
          }
        }
        return parsed;
      } catch (e) {
        console.error("Error parsing streak data:", e);
      }
    }
    return {
      streak: 3, // Default encouraging starter streak
      lastCompletedDate: '',
      completedToday: false,
      history: [],
      milestonesReached: []
    };
  });

  const [showMilestoneAlert, setShowMilestoneAlert] = useState<number | null>(null);

  useEffect(() => {
    localStorage.setItem('neurolearn_focus_streak', JSON.stringify(streakData));
  }, [streakData]);

  const triggerConfetti = (particleCount = 70) => {
    confetti({
      particleCount,
      spread: 60,
      origin: { y: 0.7 },
      colors: ['#10b981', '#f59e0b', '#6366f1', '#ec4899']
    });
  };

  const handleCompleteDailySession = () => {
    const today = getTodayString();
    if (streakData.completedToday) {
      // Allow extra high five confetti
      triggerConfetti(40);
      return;
    }

    const newStreak = streakData.streak + 1;
    const newMilestones = [...streakData.milestonesReached];
    const milestones = [1, 3, 5, 7, 10, 14, 21, 30];

    let hitMilestone = false;
    if (milestones.includes(newStreak) && !newMilestones.includes(newStreak)) {
      newMilestones.push(newStreak);
      hitMilestone = true;
      setShowMilestoneAlert(newStreak);
      setTimeout(() => setShowMilestoneAlert(null), 5000);
    }

    setStreakData(prev => ({
      ...prev,
      streak: newStreak,
      lastCompletedDate: today,
      completedToday: true,
      history: [...prev.history, today],
      milestonesReached: newMilestones
    }));

    // Trigger confetti burst!
    triggerConfetti(hitMilestone ? 120 : 65);
  };

  // Next milestone calculation
  const milestones = [1, 3, 5, 7, 10, 14, 21, 30, 50, 100];
  const nextMilestone = milestones.find(m => m > streakData.streak) || (streakData.streak + 5);
  const progressPercent = Math.min(100, Math.round((streakData.streak / nextMilestone) * 100));

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
      {/* Background Subtle Gradient Glow */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 dark:bg-amber-500/20 rounded-full blur-2xl pointer-events-none" />

      {/* Header with Flame Icon */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-500 flex items-center justify-center text-white shadow-md shadow-amber-500/20">
            <Flame className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-100">
              Focus Streak
            </h3>
            <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
              Consistent Study Sessions
            </p>
          </div>
        </div>

        <div className="flex items-baseline space-x-1 bg-amber-50 dark:bg-amber-950/50 px-2.5 py-1 rounded-xl border border-amber-200/60 dark:border-amber-900/60">
          <span className="text-xl font-black text-amber-600 dark:text-amber-400">
            {streakData.streak}
          </span>
          <span className="text-[10px] font-bold text-amber-700 dark:text-amber-300 uppercase">
            Days
          </span>
        </div>
      </div>

      {/* Milestone Confetti Alert Banner */}
      {showMilestoneAlert !== null && (
        <div className="mb-3 p-2.5 bg-gradient-to-r from-amber-500 via-rose-500 to-indigo-500 text-white rounded-xl shadow-md text-center animate-bounce">
          <p className="text-xs font-black flex items-center justify-center gap-1.5">
            <Trophy className="w-4 h-4 text-yellow-300" />
            <span>🎉 MILESTONE UNLOCKED: {showMilestoneAlert}-DAY STREAK! 🎉</span>
          </p>
        </div>
      )}

      {/* Progress to Next Milestone */}
      <div className="mb-4 space-y-1.5">
        <div className="flex justify-between items-center text-[11px] font-semibold">
          <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1">
            <Award className="w-3.5 h-3.5 text-indigo-500" />
            Next Milestone
          </span>
          <span className="text-indigo-600 dark:text-indigo-400 font-bold">
            {streakData.streak} / {nextMilestone} Days
          </span>
        </div>
        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden p-0.5 border border-slate-200/50 dark:border-slate-800">
          <div
            className="bg-gradient-to-r from-amber-500 to-indigo-600 h-full rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Daily Sprint Completion Button */}
      <button
        onClick={handleCompleteDailySession}
        className={`w-full py-2.5 px-3 rounded-xl text-xs font-extrabold flex items-center justify-center space-x-2 transition-all ${
          streakData.completedToday
            ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 hover:bg-emerald-100'
            : 'bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white shadow-md shadow-amber-500/20 active:scale-[0.98]'
        }`}
      >
        {streakData.completedToday ? (
          <>
            <CalendarCheck className="w-4 h-4 text-emerald-500" />
            <span>Daily Focus Done Today! (Click for Confetti)</span>
          </>
        ) : (
          <>
            <Zap className="w-4 h-4 text-amber-200 fill-amber-200" />
            <span>Complete Today's Focus Session</span>
          </>
        )}
      </button>
    </div>
  );
};
