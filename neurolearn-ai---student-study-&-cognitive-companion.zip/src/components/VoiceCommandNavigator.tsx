import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Volume2, Sparkles, Navigation, AlertCircle } from 'lucide-react';
import { soundSynth } from '../utils/audio';

interface VoiceCommandNavigatorProps {
  onNavigate: (tabKey: string) => void;
  activeTab: string;
}

export const VoiceCommandNavigator: React.FC<VoiceCommandNavigatorProps> = ({ onNavigate, activeTab }) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState<string>('');
  const [feedbackMsg, setFeedbackMsg] = useState<string>('');
  const [recognition, setRecognition] = useState<any>(null);

  useEffect(() => {
    // Check SpeechRecognition browser compatibility
    const SpeechRecognitionAPI = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognitionAPI) {
      const recog = new SpeechRecognitionAPI();
      recog.continuous = false;
      recog.interimResults = true;
      recog.lang = 'en-US';

      recog.onresult = (event: any) => {
        const currentTranscript = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join('');
        setTranscript(currentTranscript);

        // Evaluate command on final result
        if (event.results[0].isFinal) {
          handleVoiceCommand(currentTranscript);
        }
      };

      recog.onerror = (err: any) => {
        console.warn('Speech recognition error:', err);
        setIsListening(false);
        setFeedbackMsg('Mic listening paused or not supported in iframe.');
      };

      recog.onend = () => {
        setIsListening(false);
      };

      setRecognition(recog);
    }
  }, []);

  const handleVoiceCommand = (speechText: string) => {
    const text = speechText.toLowerCase().trim();
    soundSynth.playTone(520, 'sine', 0.15);

    if (text.includes('math') || text.includes('dyscalculia') || text.includes('calculator')) {
      onNavigate('dyscalculia');
      setFeedbackMsg('Opened Dyscalculia Step-by-Step Math Visualizer');
    } else if (text.includes('scribe') || text.includes('dysgraphia') || text.includes('writing') || text.includes('dictat')) {
      onNavigate('dysgraphia');
      setFeedbackMsg('Opened Dysgraphia Voice Scribe & Dictation');
    } else if (text.includes('robot') || text.includes('teacher') || text.includes('presentation') || text.includes('slide')) {
      onNavigate('robo_teacher');
      setFeedbackMsg('Opened AI Robot Teacher Presentation Classroom');
    } else if (text.includes('stress') || text.includes('calm') || text.includes('journal') || text.includes('anxiety') || text.includes('relief')) {
      onNavigate('stress_relief');
      setFeedbackMsg('Opened Stress Relief & Journaling Center');
    } else if (text.includes('caption') || text.includes('auditory') || text.includes('apd')) {
      onNavigate('apd');
      setFeedbackMsg('Opened APD Closed Captions Reader');
    } else if (text.includes('analytics') || text.includes('dashboard') || text.includes('trend') || text.includes('performance')) {
      onNavigate('analytics');
      setFeedbackMsg('Opened Weekly Cognitive Analytics Dashboard');
    } else if (text.includes('tutor') || text.includes('chat') || text.includes('ai')) {
      onNavigate('chat');
      setFeedbackMsg('Opened Psychological AI Tutors');
    } else if (text.includes('timer') || text.includes('focus wave') || text.includes('pomodoro')) {
      onNavigate('focustimer');
      setFeedbackMsg('Opened Focus Wave Pomodoro Timer');
    } else if (text.includes('condition') || text.includes('hub') || text.includes('profile')) {
      onNavigate('condition_hub');
      setFeedbackMsg('Opened Neurodiverse Condition Profiles Hub');
    } else if (text.includes('dyslexia') || text.includes('bionic') || text.includes('reading')) {
      onNavigate('transformer');
      setFeedbackMsg('Opened Dyslexia Adaptive Text Transformer');
    } else if (text.includes('plan') || text.includes('path') || text.includes('study')) {
      onNavigate('plan');
      setFeedbackMsg('Opened Study Path Generator');
    } else {
      setFeedbackMsg(`Command not recognized ("${speechText}"). Try "Show me Dyscalculia" or "Open Stress Relief".`);
    }
  };

  const toggleListening = () => {
    if (!recognition) {
      setFeedbackMsg('Speech recognition unavailable. You can click any menu item directly.');
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      setTranscript('');
      setFeedbackMsg('Listening for command... (e.g., "Show me Dyscalculia" or "Open Stress Relief")');
      try {
        recognition.start();
        setIsListening(true);
        soundSynth.playTone(600, 'sine', 0.1);
      } catch (e) {
        console.warn(e);
      }
    }
  };

  return (
    <div className="bg-gradient-to-r from-emerald-900/90 via-slate-900 to-indigo-950 border border-emerald-800/80 rounded-2xl p-4 shadow-md text-white mb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Left identity */}
        <div className="flex items-center space-x-3">
          <button
            onClick={toggleListening}
            aria-label={isListening ? 'Stop Voice Navigation' : 'Start Voice Navigation Assistant'}
            className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all ${
              isListening
                ? 'bg-rose-600 text-white animate-pulse ring-4 ring-rose-400/40 shadow-lg'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md'
            }`}
          >
            {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-300 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                Hands-Free Voice Command Navigator
              </span>
              {isListening && (
                <span className="px-2 py-0.5 rounded-full bg-rose-500/30 text-rose-300 text-[10px] font-extrabold animate-pulse">
                  Listening...
                </span>
              )}
            </div>
            <p className="text-xs text-slate-300">
              {transcript ? `"${transcript}"` : 'Click mic and speak (e.g., "Show me Dyscalculia", "Open Stress Relief", "Analytics")'}
            </p>
          </div>
        </div>

        {/* Quick Voice Shortcut Tags */}
        <div className="flex flex-wrap items-center gap-1.5 text-[10px]">
          <span className="text-slate-400 font-bold mr-1">Try saying:</span>
          <button
            onClick={() => handleVoiceCommand('show me dyscalculia')}
            className="px-2 py-1 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700"
          >
            "Dyscalculia"
          </button>
          <button
            onClick={() => handleVoiceCommand('show me stress relief')}
            className="px-2 py-1 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700"
          >
            "Stress Relief"
          </button>
          <button
            onClick={() => handleVoiceCommand('show me robo teacher')}
            className="px-2 py-1 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700"
          >
            "Robo Teacher"
          </button>
          <button
            onClick={() => handleVoiceCommand('show me analytics')}
            className="px-2 py-1 rounded-md bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700"
          >
            "Analytics"
          </button>
        </div>
      </div>

      {/* Feedback Toast Banner */}
      {feedbackMsg && (
        <motion.div
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-emerald-200"
        >
          <span className="flex items-center gap-1.5 font-bold">
            <Navigation className="w-3.5 h-3.5 text-emerald-400" />
            {feedbackMsg}
          </span>
          <button
            onClick={() => setFeedbackMsg('')}
            className="text-[10px] text-slate-400 hover:text-white"
          >
            Dismiss
          </button>
        </motion.div>
      )}
    </div>
  );
};
