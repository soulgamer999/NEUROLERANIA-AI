import React from 'react';
import { 
  BookOpen, 
  Calculator, 
  PenTool, 
  Captions, 
  MousePointer, 
  Eye, 
  Sparkles, 
  Check, 
  Sliders,
  Accessibility,
  Type,
  Volume2
} from 'lucide-react';
import { LearningCondition, UserPreferences } from '../types';

interface NeuroConditionSelectorProps {
  prefs: UserPreferences;
  onChangePrefs: (updated: Partial<UserPreferences>) => void;
  className?: string;
}

export const CONDITION_PROFILES: {
  id: LearningCondition;
  title: string;
  shortDesc: string;
  icon: React.ReactNode;
  badgeColor: string;
  borderActive: string;
  accentBg: string;
  strategies: string[];
}[] = [
  {
    id: 'dyslexia',
    title: 'Dyslexia Support',
    shortDesc: 'Reading, word recognition, Bionic text formatting & audio narration.',
    icon: <BookOpen className="w-4 h-4 text-emerald-500" />,
    badgeColor: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300',
    borderActive: 'border-emerald-500 ring-2 ring-emerald-500/20',
    accentBg: 'bg-emerald-500',
    strategies: ['Bionic Font Bolding', 'Phonetic Syllable Chunking', 'Synchronized Speech Engine']
  },
  {
    id: 'dyscalculia',
    title: 'Dyscalculia Math Hub',
    shortDesc: 'Trouble with numbers, math concepts, counting & telling time.',
    icon: <Calculator className="w-4 h-4 text-amber-500" />,
    badgeColor: 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300',
    borderActive: 'border-amber-500 ring-2 ring-amber-500/20',
    accentBg: 'bg-amber-500',
    strategies: ['Visual Dot Counters', 'Step-by-Step Word Problem Translator', 'Fraction & Clock Gauges']
  },
  {
    id: 'dysgraphia',
    title: 'Dysgraphia Voice Scribe',
    shortDesc: 'Physical writing strain, spelling & turning raw thoughts to sentences.',
    icon: <PenTool className="w-4 h-4 text-purple-500" />,
    badgeColor: 'bg-purple-100 text-purple-800 dark:bg-purple-950/80 dark:text-purple-300',
    borderActive: 'border-purple-500 ring-2 ring-purple-500/20',
    accentBg: 'bg-purple-500',
    strategies: ['Voice-to-Sentence Scribe', 'Thought Polishing Engine', 'Spelling & Etymology Hooks']
  },
  {
    id: 'apd',
    title: 'Auditory Processing (APD)',
    shortDesc: 'Trouble making sense of spoken instructions & audio clutter.',
    icon: <Captions className="w-4 h-4 text-sky-500" />,
    badgeColor: 'bg-sky-100 text-sky-800 dark:bg-sky-950/80 dark:text-sky-300',
    borderActive: 'border-sky-500 ring-2 ring-sky-500/20',
    accentBg: 'bg-sky-500',
    strategies: ['Synchronized Visual Captions', 'Slow Speech Rate (0.75x)', 'High-Contrast Text Outlines']
  },
  {
    id: 'dyspraxia',
    title: 'Dyspraxia (DCD) Motor Mode',
    shortDesc: 'Challenges with physical coordination & fine motor movements.',
    icon: <MousePointer className="w-4 h-4 text-rose-500" />,
    badgeColor: 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300',
    borderActive: 'border-rose-500 ring-2 ring-rose-500/20',
    accentBg: 'bg-rose-500',
    strategies: ['Giant 52px Touch Targets', 'Zero Drag & Drop Dependency', 'Single-Key Shortcuts']
  },
  {
    id: 'nvld',
    title: 'Nonverbal Learning (NVLD)',
    shortDesc: 'Spatial awareness, visual-motor tasks & reading social cues.',
    icon: <Eye className="w-4 h-4 text-indigo-500" />,
    badgeColor: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/80 dark:text-indigo-300',
    borderActive: 'border-indigo-500 ring-2 ring-indigo-500/20',
    accentBg: 'bg-indigo-500',
    strategies: ['Step-by-Step Narrative Explanations', 'Explicit Written Labels', 'Social Cue Decoders']
  }
];

export const NeuroConditionSelector: React.FC<NeuroConditionSelectorProps> = ({
  prefs,
  onChangePrefs,
  className = ''
}) => {
  return (
    <div className={`bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm ${className}`}>
      
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-2">
          <Sparkles className="w-5 h-5 text-indigo-500" />
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white uppercase tracking-wider">
            Neurodiverse Learning Conditions Hub
          </h3>
        </div>
        <span className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950 px-2.5 py-1 rounded-full border border-indigo-200 dark:border-indigo-800">
          6 Inclusive Brain Study Engines
        </span>
      </div>

      {/* Grid of 6 Conditions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {CONDITION_PROFILES.map((profile) => {
          const isSelected = prefs.activeCondition === profile.id;
          return (
            <button
              key={profile.id}
              onClick={() => {
                const updates: Partial<UserPreferences> = {
                  activeCondition: profile.id
                };
                if (profile.id === 'dyspraxia') {
                  updates.largeTouchTargets = true;
                }
                if (profile.id === 'dyscalculia') {
                  updates.mathVisualizerEnabled = true;
                }
                if (profile.id === 'apd') {
                  updates.audioClosedCaptions = true;
                  updates.speechSpeed = 0.75;
                }
                if (profile.id === 'nvld') {
                  updates.explicitTextLabels = true;
                }
                if (profile.id === 'dysgraphia') {
                  updates.voiceTypingAssistant = true;
                }
                onChangePrefs(updates);
              }}
              className={`p-3.5 rounded-xl text-left border transition-all flex flex-col justify-between ${
                isSelected
                  ? `${profile.borderActive} bg-slate-50 dark:bg-slate-800/90 shadow-md`
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center space-x-2">
                    <div className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800">
                      {profile.icon}
                    </div>
                    <span className="text-xs font-black text-slate-900 dark:text-white">
                      {profile.title}
                    </span>
                  </div>
                  {isSelected && (
                    <span className={`w-5 h-5 rounded-full ${profile.accentBg} text-white flex items-center justify-center shrink-0`}>
                      <Check className="w-3.5 h-3.5" />
                    </span>
                  )}
                </div>

                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium leading-snug mb-2">
                  {profile.shortDesc}
                </p>
              </div>

              <div className="flex flex-wrap gap-1 pt-1 border-t border-slate-100 dark:border-slate-800">
                {profile.strategies.map((strat, idx) => (
                  <span key={idx} className="text-[9px] font-semibold text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
                    ✓ {strat}
                  </span>
                ))}
              </div>
            </button>
          );
        })}
      </div>

      {/* Accessibility & Screen Reader Optimization Quick Bar */}
      <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
        <div className="flex items-center space-x-2 mb-3">
          <Accessibility className="w-4 h-4 text-emerald-500" />
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            Screen Reader & Motor Assist Quick Controls
          </h4>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {/* Screen Reader Mode Toggle */}
          <button
            onClick={() => onChangePrefs({ screenReaderOptimization: !prefs.screenReaderOptimization })}
            aria-pressed={prefs.screenReaderOptimization}
            aria-label="Toggle Screen Reader Optimization Mode. Adds descriptive ARIA landmarks and simplified navigation paths."
            className={`p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
              prefs.screenReaderOptimization
                ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold shadow-xs'
                : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <div>
              <p className="text-xs font-bold flex items-center gap-1.5">
                <Accessibility className="w-3.5 h-3.5 text-emerald-500" />
                <span>Screen Reader Mode</span>
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Descriptive ARIA & simplified paths
              </p>
            </div>
            <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-extrabold ${
              prefs.screenReaderOptimization ? 'bg-emerald-600 text-white' : 'bg-slate-300 text-slate-600'
            }`}>
              {prefs.screenReaderOptimization ? '✓' : ''}
            </span>
          </button>

          {/* Large Touch Targets */}
          <button
            onClick={() => onChangePrefs({ largeTouchTargets: !prefs.largeTouchTargets })}
            aria-pressed={prefs.largeTouchTargets}
            aria-label="Toggle Large Touch Targets for Motor Coordination Assistance"
            className={`p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
              prefs.largeTouchTargets
                ? 'bg-rose-50 dark:bg-rose-950/60 border-rose-500 text-rose-900 dark:text-rose-200 font-bold shadow-xs'
                : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <div>
              <p className="text-xs font-bold flex items-center gap-1.5">
                <MousePointer className="w-3.5 h-3.5 text-rose-500" />
                <span>Large Touch Targets</span>
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                52px buttons for motor assist
              </p>
            </div>
            <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-extrabold ${
              prefs.largeTouchTargets ? 'bg-rose-600 text-white' : 'bg-slate-300 text-slate-600'
            }`}>
              {prefs.largeTouchTargets ? '✓' : ''}
            </span>
          </button>

          {/* Explicit Text Labels */}
          <button
            onClick={() => onChangePrefs({ explicitTextLabels: !prefs.explicitTextLabels })}
            aria-pressed={prefs.explicitTextLabels}
            aria-label="Toggle Explicit Text Labels for all icon controls"
            className={`p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
              prefs.explicitTextLabels
                ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500 text-indigo-900 dark:text-indigo-200 font-bold shadow-xs'
                : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <div>
              <p className="text-xs font-bold flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-indigo-500" />
                <span>Explicit Text Labels</span>
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Full names for every control
              </p>
            </div>
            <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-extrabold ${
              prefs.explicitTextLabels ? 'bg-indigo-600 text-white' : 'bg-slate-300 text-slate-600'
            }`}>
              {prefs.explicitTextLabels ? '✓' : ''}
            </span>
          </button>

          {/* Dyslexic Font */}
          <button
            onClick={() => onChangePrefs({ dyslexicFont: !prefs.dyslexicFont })}
            aria-pressed={prefs.dyslexicFont}
            aria-label="Toggle Dyslexia-friendly Lexie Font spacing"
            className={`p-3 rounded-xl border text-left transition-all flex items-center justify-between ${
              prefs.dyslexicFont
                ? 'bg-amber-50 dark:bg-amber-950/60 border-amber-500 text-amber-900 dark:text-amber-200 font-bold shadow-xs'
                : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            <div>
              <p className="text-xs font-bold flex items-center gap-1.5">
                <Type className="w-3.5 h-3.5 text-amber-500" />
                <span>Lexie Dyslexia Font</span>
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400">
                Heavy bottom weighted text
              </p>
            </div>
            <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-extrabold ${
              prefs.dyslexicFont ? 'bg-amber-600 text-white' : 'bg-slate-300 text-slate-600'
            }`}>
              {prefs.dyslexicFont ? '✓' : ''}
            </span>
          </button>
        </div>
      </div>

    </div>
  );
};
