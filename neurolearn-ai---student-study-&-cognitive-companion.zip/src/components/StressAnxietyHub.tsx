import React, { useState, useEffect } from 'react';
import { 
  HeartHandshake, 
  Wind, 
  ShieldAlert, 
  Sparkles, 
  Play, 
  Square, 
  RotateCcw, 
  Check, 
  Brain, 
  Smile, 
  Moon, 
  Zap, 
  Volume2, 
  Info,
  ChevronRight,
  PenTool,
  BookOpen,
  Send,
  Frown,
  Meh,
  CheckCircle2,
  Heart
} from 'lucide-react';
import { soundSynth } from '../utils/audio';
import { DailyJournalEntry } from '../types';

const INITIAL_JOURNAL_ENTRIES: DailyJournalEntry[] = [
  {
    id: 'entry_1',
    date: 'Today, 09:30 AM',
    timestamp: new Date().toISOString(),
    text: 'Felt a bit anxious before starting the math practice session, but the visual dots helped me understand multiplication.',
    moodScore: 68,
    detectedEmotion: 'anxious',
    primaryTrigger: 'Math Formulas & Speed Pressure',
    suggestedGrounding: 'Box Breathing 4-4-4-4 & 5-4-3-2-1 Sensory Grounding',
    cognitiveReframing: 'Replace "I am bad at math" with "My brain processes numbers visually with dots."'
  }
];


export const StressAnxietyHub: React.FC = () => {
  // Breathing Timer state
  const [breathingTechnique, setBreathingTechnique] = useState<'box' | '478'>('box');
  const [isBreathingActive, setIsBreathingActive] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold' | 'Exhale' | 'Rest'>('Inhale');
  const [breathCountdown, setBreathCountdown] = useState(4);
  const [breathCyclesCompleted, setBreathCyclesCompleted] = useState(0);

  // Grounding Tool state
  const [groundingStep, setGroundingStep] = useState(0);
  const groundingPrompts = [
    { title: "5 Things You Can SEE", icon: "👁️", desc: "Look around your room. Name 5 distinct objects out loud or in your mind." },
    { title: "4 Things You Can TOUCH", icon: "🖐️", desc: "Touch your desk, paper, clothing, or hair. Feel the texture." },
    { title: "3 Things You Can HEAR", icon: "👂", desc: "Listen closely. Is it wind, a clock, your breathing, or distant hums?" },
    { title: "2 Things You Can SMELL", icon: "👃", desc: "Notice scents around you or imagine fresh lemon or lavender." },
    { title: "1 Positive Self-Statement", icon: "💚", desc: "Say: 'I am doing my best, and my brain is learning step by step.'" }
  ];

  // Panic Reset State
  const [isPanicTimerActive, setIsPanicTimerActive] = useState(false);
  const [panicSecondsLeft, setPanicSecondsLeft] = useState(120);

  // Daily Journaling State
  const [journalEntries, setJournalEntries] = useState<DailyJournalEntry[]>(INITIAL_JOURNAL_ENTRIES);
  const [newJournalText, setNewJournalText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [activeReframingEntry, setActiveReframingEntry] = useState<DailyJournalEntry | null>(INITIAL_JOURNAL_ENTRIES[0]);

  const handleAddJournalEntry = () => {
    if (!newJournalText.trim()) return;

    setIsAnalyzing(true);
    soundSynth.playTone(580, 'sine', 0.15);

    setTimeout(() => {
      const textLower = newJournalText.toLowerCase();
      let emotion: DailyJournalEntry['detectedEmotion'] = 'calm';
      let score = 75;
      let trigger = 'General Study Reflection';
      let grounding = '5-4-3-2-1 Sensory Grounding';
      let reframing = 'Acknowledge progress made today, no matter how small.';

      if (textLower.includes('fail') || textLower.includes('anxious') || textLower.includes('scared') || textLower.includes('worry')) {
        emotion = 'anxious';
        score = 35;
        trigger = 'Performance Anxiety & Fear of Failure';
        grounding = '4-7-8 Relaxing Breath & Muscle Relaxation';
        reframing = 'Ask: "What is the worst case scenario, and what evidence do I have against it?"';
      } else if (textLower.includes('overwhelmed') || textLower.includes('too much') || textLower.includes('hard') || textLower.includes('stuck')) {
        emotion = 'overwhelmed';
        score = 42;
        trigger = 'Executive Function & Cognitive Overload';
        grounding = 'Box Breathing 4-4-4-4 & 20-Min Task Micro-chunking';
        reframing = 'Deconstruct big tasks into single 5-minute actionable steps.';
      } else if (textLower.includes('frustrated') || textLower.includes('hate') || textLower.includes('annoyed')) {
        emotion = 'frustrated';
        score = 50;
        trigger = 'Learning Friction & Impatience';
        grounding = 'Cold Water Splash & Physical Shake-off';
        reframing = 'Friction is proof that my brain is creating new neural pathways.';
      } else if (textLower.includes('good') || textLower.includes('focused') || textLower.includes('proud') || textLower.includes('understand')) {
        emotion = 'focused';
        score = 90;
        trigger = 'Flow State & Concept Mastery';
        grounding = 'Gratitude & Dopamine Reward Anchor';
        reframing = 'Celebrate momentum! Record what study environment worked best.';
      }

      const newEntry: DailyJournalEntry = {
        id: `entry_${Date.now()}`,
        date: 'Just Now',
        timestamp: new Date().toISOString(),
        text: newJournalText,
        moodScore: score,
        detectedEmotion: emotion,
        primaryTrigger: trigger,
        suggestedGrounding: grounding,
        cognitiveReframing: reframing
      };

      setJournalEntries([newEntry, ...journalEntries]);
      setActiveReframingEntry(newEntry);
      setNewJournalText('');
      setIsAnalyzing(false);
      soundSynth.playTone(720, 'sine', 0.2);
    }, 600);
  };


  // Breathing Loop Timer Effect
  useEffect(() => {
    let timer: any;
    if (isBreathingActive) {
      timer = setInterval(() => {
        setBreathCountdown((prev) => {
          if (prev > 1) return prev - 1;

          // Phase transition logic
          if (breathingTechnique === 'box') {
            if (breathPhase === 'Inhale') { setBreathPhase('Hold'); return 4; }
            if (breathPhase === 'Hold') { setBreathPhase('Exhale'); return 4; }
            if (breathPhase === 'Exhale') { setBreathPhase('Rest'); return 4; }
            if (breathPhase === 'Rest') {
              setBreathPhase('Inhale');
              setBreathCyclesCompleted((c) => c + 1);
              return 4;
            }
          } else {
            // 4-7-8 Technique
            if (breathPhase === 'Inhale') { setBreathPhase('Hold'); return 7; }
            if (breathPhase === 'Hold') { setBreathPhase('Exhale'); return 8; }
            if (breathPhase === 'Exhale') {
              setBreathPhase('Inhale');
              setBreathCyclesCompleted((c) => c + 1);
              return 4;
            }
          }
          return 4;
        });
      }, 1000);
    } else {
      setBreathPhase('Inhale');
      setBreathCountdown(breathingTechnique === 'box' ? 4 : 4);
    }

    return () => clearInterval(timer);
  }, [isBreathingActive, breathPhase, breathingTechnique]);

  // Emergency Panic Timer Effect
  useEffect(() => {
    let timer: any;
    if (isPanicTimerActive && panicSecondsLeft > 0) {
      timer = setInterval(() => {
        setPanicSecondsLeft((s) => s - 1);
      }, 1000);
    } else if (panicSecondsLeft === 0) {
      setIsPanicTimerActive(false);
    }
    return () => clearInterval(timer);
  }, [isPanicTimerActive, panicSecondsLeft]);

  return (
    <div role="region" aria-label="Academic Stress and Anxiety Relief Center" className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-600 via-indigo-600 to-amber-500 rounded-2xl p-6 text-white shadow-md">
        <div className="flex items-center space-x-3 mb-2">
          <div className="p-3 bg-white/10 rounded-xl backdrop-blur-md">
            <HeartHandshake className="w-6 h-6 text-amber-200" aria-hidden="true" />
          </div>
          <div>
            <h2 className="text-xl font-bold">Academic Stress & Anxiety Relief Center</h2>
            <p className="text-xs text-indigo-100">
              Actionable, evidence-based psychological tools to reduce cortisol, halt panic, and restore mental focus.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Interactive Breathing Circle & 2-Minute Panic Reset */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Breathing Circle Component */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm flex flex-col items-center text-center">
            <div className="w-full flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Wind className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  Interactive Calming Breathing Ring
                </h3>
              </div>
              <div className="flex bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-[11px] font-semibold">
                <button
                  onClick={() => { setBreathingTechnique('box'); setIsBreathingActive(false); }}
                  className={`px-2.5 py-1 rounded-md ${breathingTechnique === 'box' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-400'}`}
                >
                  Box (4-4-4-4)
                </button>
                <button
                  onClick={() => { setBreathingTechnique('478'); setIsBreathingActive(false); }}
                  className={`px-2.5 py-1 rounded-md ${breathingTechnique === '478' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-400'}`}
                >
                  Calm Wave (4-7-8)
                </button>
              </div>
            </div>

            {/* Visual Expanding Breathing Circle */}
            <div className="relative my-8 flex items-center justify-center">
              {/* Animated Ring */}
              <div className={`w-48 h-48 rounded-full border-4 border-teal-500/30 flex items-center justify-center transition-all duration-1000 ${
                isBreathingActive && breathPhase === 'Inhale' 
                  ? 'scale-125 bg-teal-500/20 border-teal-500' 
                  : isBreathingActive && breathPhase === 'Exhale'
                  ? 'scale-90 bg-teal-500/5 border-teal-300'
                  : 'scale-100 bg-slate-50 dark:bg-slate-800'
              }`}>
                <div className="flex flex-col items-center justify-center">
                  <span className="text-2xl font-black text-teal-600 dark:text-teal-400">
                    {isBreathingActive ? breathCountdown : 'START'}
                  </span>
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mt-1">
                    {isBreathingActive ? breathPhase : 'Click Play'}
                  </span>
                </div>
              </div>
            </div>

            {/* Breathing Controls */}
            <div className="flex items-center space-x-3 mb-2">
              <button
                onClick={() => setIsBreathingActive(!isBreathingActive)}
                className={`px-6 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-2 shadow-md transition-all ${
                  isBreathingActive
                    ? 'bg-rose-600 hover:bg-rose-700 text-white'
                    : 'bg-teal-600 hover:bg-teal-700 text-white'
                }`}
              >
                {isBreathingActive ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isBreathingActive ? 'Pause Exercise' : 'Begin Breathing Session'}</span>
              </button>

              <button
                onClick={() => {
                  setIsBreathingActive(false);
                  setBreathCyclesCompleted(0);
                  setBreathCountdown(4);
                }}
                className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400">
              Completed Cycles: <strong className="text-teal-600 dark:text-teal-400">{breathCyclesCompleted}</strong> • 
              {breathingTechnique === 'box' ? ' Resets heart rate during study blocks' : ' Stimulates parasympathetic nervous system'}
            </p>
          </div>

          {/* Emergency 2-Minute Panic Reset */}
          <div className="bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center space-x-2 mb-3">
              <ShieldAlert className="w-5 h-5 text-rose-600 dark:text-rose-400" />
              <h3 className="text-sm font-bold text-rose-950 dark:text-rose-200 uppercase tracking-wider">
                Emergency 2-Minute Exam Panic Reset
              </h3>
            </div>

            <p className="text-xs text-rose-900 dark:text-rose-300 leading-relaxed mb-4">
              Experiencing sudden exam panic, rapid heartbeat, or mind blanking? Press the button below to start a guided 120-second calming sequence.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-xl border border-rose-200/60 dark:border-rose-900/40">
              <div>
                <span className="text-[10px] font-bold uppercase text-slate-400">Reset Timer</span>
                <p className="text-xl font-mono font-black text-rose-600 dark:text-rose-400">
                  {Math.floor(panicSecondsLeft / 60)}:{String(panicSecondsLeft % 60).padStart(2, '0')}
                </p>
              </div>

              <button
                onClick={() => {
                  setIsPanicTimerActive(!isPanicTimerActive);
                  if (panicSecondsLeft === 0) setPanicSecondsLeft(120);
                }}
                className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-2 transition-all ${
                  isPanicTimerActive
                    ? 'bg-slate-800 text-white'
                    : 'bg-rose-600 hover:bg-rose-700 text-white shadow-md'
                }`}
              >
                <Zap className="w-4 h-4" />
                <span>{isPanicTimerActive ? 'Pause Reset' : 'Trigger Panic Reset (120s)'}</span>
              </button>
            </div>

            {isPanicTimerActive && (
              <div className="mt-3 p-3 rounded-lg bg-rose-100 dark:bg-rose-950 text-xs text-rose-900 dark:text-rose-200 animate-pulse">
                💡 <strong>Robo-Psychologist Reminder:</strong> Place one hand on your chest and one on your stomach. Slow down your exhale. A mind blank is just temporary adrenaline—your stored knowledge is still safe in your memory banks.
              </div>
            )}
          </div>

        </div>

        {/* RIGHT COLUMN: 5-4-3-2-1 Grounding & Psychological Guidance Cards */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* 5-4-3-2-1 Sensory Grounding Tool */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center space-x-2 mb-4">
              <Brain className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                5-4-3-2-1 Sensory Grounding Technique
              </h3>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-base">{groundingPrompts[groundingStep].icon}</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
                  Step {groundingStep + 1} of 5
                </span>
              </div>

              <h4 className="font-bold text-sm text-slate-900 dark:text-white mb-1">
                {groundingPrompts[groundingStep].title}
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                {groundingPrompts[groundingStep].desc}
              </p>

              <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-700">
                <button
                  onClick={() => setGroundingStep((s) => Math.max(0, s - 1))}
                  disabled={groundingStep === 0}
                  className="text-xs font-semibold text-slate-500 disabled:opacity-30"
                >
                  Previous Step
                </button>

                <button
                  onClick={() => setGroundingStep((s) => (s + 1) % 5)}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg flex items-center space-x-1"
                >
                  <span>Next Step</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Expert Psychological Guidance Toolkit */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Psychologist's Actionable Stress Advice</span>
            </h3>

            <div className="space-y-3">
              <div className="p-3.5 rounded-xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900">
                <h4 className="font-bold text-xs text-indigo-900 dark:text-indigo-300 mb-1">
                  1. Reframing Exam Fear & Adrenaline
                </h4>
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                  Notice your pounding heart? Tell yourself: <em>"My body is giving me extra energy and alertness to focus."</em> Reinterpreting anxiety as excitement lowers cognitive distress.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-100 dark:border-teal-900">
                <h4 className="font-bold text-xs text-teal-900 dark:text-teal-300 mb-1">
                  2. The 20-Minute Micro-Chunking Rule
                </h4>
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                  When facing a huge syllabus, pledge to study for ONLY 20 minutes. Lowering the initial commitment bypasses executive function paralysis and procrastination.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-900">
                <h4 className="font-bold text-xs text-amber-900 dark:text-amber-300 mb-1">
                  3. Sleep & Memory Consolidation
                </h4>
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                  All-nighters sabotage memory! During REM sleep, the hippocampus transfers short-term study notes into permanent long-term memory banks. Prioritize 7-8 hours.
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* DAILY REFLECTION & SENTIMENT ANALYSIS JOURNAL MODULE */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-rose-100 dark:bg-rose-950/80 rounded-xl text-rose-600 dark:text-rose-400">
              <PenTool className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                <span>Daily Reflection & Real-Time Sentiment Journal</span>
                <Sparkles className="w-4 h-4 text-rose-500 animate-pulse" />
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Log your study emotions to receive instant psychological grounding & cognitive reframing
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950 px-3 py-1 rounded-full border border-rose-200 dark:border-rose-900">
            Cognitive Reframing Active
          </span>
        </div>

        {/* Input Text Area */}
        <div className="space-y-3">
          <textarea
            value={newJournalText}
            onChange={(e) => setNewJournalText(e.target.value)}
            rows={3}
            placeholder="How are you feeling about your studies today? (e.g., 'Feeling overwhelmed with chemistry equations and worried I will forget everything during tomorrow\'s quiz...')"
            className="w-full text-xs md:text-sm p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-rose-500 font-sans"
          />

          <div className="flex items-center justify-between">
            <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5 text-indigo-500" />
              Private entry analyzed by AI Psychological Model
            </p>

            <button
              onClick={handleAddJournalEntry}
              disabled={isAnalyzing || !newJournalText.trim()}
              className="px-4 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-md flex items-center space-x-2 transition-all"
            >
              {isAnalyzing ? (
                <span>Analyzing Mood & Triggers...</span>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Analyze & Log Entry</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Active Entry Sentiment & Grounding Output Box */}
        {activeReframingEntry && (
          <div className="p-4 rounded-xl bg-gradient-to-r from-rose-950/80 via-slate-900 to-indigo-950 border border-rose-800/80 text-white space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-rose-800/50 text-xs">
              <span className="font-bold text-rose-300 flex items-center gap-1.5">
                <Brain className="w-4 h-4 text-rose-400" />
                Latest Sentiment Diagnosis:
                <strong className="text-amber-300 capitalize"> {activeReframingEntry.detectedEmotion}</strong>
              </span>
              <span className="text-[10px] bg-rose-900/60 text-rose-200 px-2 py-0.5 rounded font-bold">
                Mood Resilience Score: {activeReframingEntry.moodScore}/100
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-rose-400 block mb-1">
                  💡 Recommended Grounding Exercise:
                </span>
                <p className="text-slate-200 font-medium">
                  {activeReframingEntry.suggestedGrounding}
                </p>
              </div>

              <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800">
                <span className="text-[10px] uppercase font-bold text-emerald-400 block mb-1">
                  🧘 Cognitive Reframing Technique:
                </span>
                <p className="text-slate-200 font-medium">
                  "{activeReframingEntry.cognitiveReframing}"
                </p>
              </div>
            </div>
          </div>
        )}

        {/* History Log List */}
        {journalEntries.length > 0 && (
          <div className="pt-2">
            <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 uppercase tracking-wider">
              Past Reflections ({journalEntries.length})
            </h4>
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {journalEntries.map((entry) => (
                <div
                  key={entry.id}
                  onClick={() => setActiveReframingEntry(entry)}
                  className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                    activeReframingEntry?.id === entry.id
                      ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800'
                      : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {entry.date}
                    </span>
                    <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400 bg-rose-100 dark:bg-rose-950 px-2 py-0.5 rounded">
                      Emotion: {entry.detectedEmotion}
                    </span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 line-clamp-2">
                    "{entry.text}"
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

    </div>
  );
};

