import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  Volume2, 
  VolumeX, 
  X, 
  Play, 
  Pause, 
  RotateCcw, 
  ShieldCheck, 
  Maximize2, 
  ChevronRight,
  Heart,
  Feather,
  Info
} from 'lucide-react';
import { PostureStretch } from '../types';
import { soundSynth } from '../utils/audio';

const DYSPRAXIA_STRETCHES: PostureStretch[] = [
  {
    id: 'stretch_1',
    title: 'Proprioceptive Feet & Spine Grounding',
    targetArea: 'spatial',
    durationSeconds: 20,
    instructions: 'Place both feet firmly flat on the floor. Press down slightly through your heels and sit tall against the back of your chair.',
    dyspraxiaBenefit: 'Resets spatial orientation and deep pressure sensors to improve body positioning awareness.',
    iconName: '⚓'
  },
  {
    id: 'stretch_2',
    title: 'Shoulder Roll & Chest Release',
    targetArea: 'shoulders',
    durationSeconds: 20,
    instructions: 'Lift both shoulders up toward your ears, roll them back smoothly 5 times, and let them drop completely relaxed.',
    dyspraxiaBenefit: 'Releases upper neck and trapezius tension caused by motor concentration while reading or typing.',
    iconName: '🙆'
  },
  {
    id: 'stretch_3',
    title: 'Wrist Circle & Loose Finger Fan',
    targetArea: 'wrists',
    durationSeconds: 20,
    instructions: 'Extend hands forward. Open fingers wide like stars for 3 seconds, then make soft loose fists and rotate wrists outward.',
    dyspraxiaBenefit: 'Prevents fine-motor fatigue and cramping in hand muscles from pencil grip or keyboard use.',
    iconName: '👐'
  },
  {
    id: 'stretch_4',
    title: 'Gentle Neck Release & Jaw Softening',
    targetArea: 'neck',
    durationSeconds: 20,
    instructions: 'Softly tilt your right ear toward your right shoulder for 10s. Unclench your teeth and let your jaw loosen. Repeat on the left.',
    dyspraxiaBenefit: 'Eases cranial pressure and improves blood flow to visual processing centers.',
    iconName: '🧘'
  },
  {
    id: 'stretch_5',
    title: 'Elbow & Desk Distance Check',
    targetArea: 'spine',
    durationSeconds: 15,
    instructions: 'Check that your elbows rest naturally at a 90-degree angle. Ensure your monitor top is roughly at eye level.',
    dyspraxiaBenefit: 'Reduces postural slouching and prevents muscle strain during prolonged sitting.',
    iconName: '📐'
  }
];

interface PostureAwarenessReminderProps {
  enabled?: boolean;
  intervalMinutes?: number;
  onToggleEnabled?: () => void;
}

export const PostureAwarenessReminder: React.FC<PostureAwarenessReminderProps> = ({
  enabled = true,
  intervalMinutes = 20,
  onToggleEnabled
}) => {
  const [secondsUntilNext, setSecondsUntilNext] = useState(intervalMinutes * 60);
  const [isReminderModalOpen, setIsReminderModalOpen] = useState(false);
  const [activeStretchIndex, setActiveStretchIndex] = useState(0);
  
  // Stretch countdown state
  const [isStretchTimerRunning, setIsStretchTimerRunning] = useState(false);
  const [stretchSecondsLeft, setStretchSecondsLeft] = useState(DYSPRAXIA_STRETCHES[0].durationSeconds);

  // Interval timer tracking next posture reminder
  useEffect(() => {
    if (!enabled) return;

    const timer = setInterval(() => {
      setSecondsUntilNext((prev) => {
        if (prev <= 1) {
          triggerReminderPopup();
          return intervalMinutes * 60;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [enabled, intervalMinutes]);

  const triggerReminderPopup = () => {
    soundSynth.playTone(520, 'sine', 0.25);
    setIsReminderModalOpen(true);
    setActiveStretchIndex(0);
    setStretchSecondsLeft(DYSPRAXIA_STRETCHES[0].durationSeconds);
    setIsStretchTimerRunning(false);
  };

  // Stretch active countdown
  useEffect(() => {
    let timer: any = null;
    if (isStretchTimerRunning && stretchSecondsLeft > 0) {
      timer = setInterval(() => {
        setStretchSecondsLeft((prev) => prev - 1);
      }, 1000);
    } else if (isStretchTimerRunning && stretchSecondsLeft === 0) {
      soundSynth.playChime(true);
      setIsStretchTimerRunning(false);
    }
    return () => clearInterval(timer);
  }, [isStretchTimerRunning, stretchSecondsLeft]);

  const handleSelectStretch = (idx: number) => {
    setActiveStretchIndex(idx);
    setStretchSecondsLeft(DYSPRAXIA_STRETCHES[idx].durationSeconds);
    setIsStretchTimerRunning(false);
    soundSynth.playTone(600, 'sine', 0.1);
  };

  const handleStartStretch = () => {
    setIsStretchTimerRunning(true);
    soundSynth.playTone(700, 'sine', 0.15);
  };

  const currentStretch = DYSPRAXIA_STRETCHES[activeStretchIndex];
  const minutesLeft = Math.floor(secondsUntilNext / 60);

  return (
    <>
      {/* Floating Widget Trigger Badge */}
      <div className="fixed bottom-20 right-5 z-40">
        <button
          onClick={() => {
            if (!isReminderModalOpen) {
              triggerReminderPopup();
            }
          }}
          className={`px-3 py-2 rounded-full border-2 shadow-lg transition-all flex items-center space-x-2 text-xs font-bold ${
            enabled
              ? 'bg-emerald-900/90 hover:bg-emerald-800 text-emerald-100 border-emerald-500/80 backdrop-blur-md'
              : 'bg-slate-800/80 text-slate-400 border-slate-700 opacity-60 hover:opacity-100'
          }`}
          title="Posture & Dyspraxia Ergonomic Comfort Reminder"
        >
          <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
          <span className="hidden sm:inline">Posture Check</span>
          <span className="text-[10px] bg-emerald-950 px-1.5 py-0.5 rounded font-mono text-emerald-300">
            {enabled ? `${minutesLeft}m` : 'OFF'}
          </span>
        </button>
      </div>

      {/* POPUP / MODAL DIALOG */}
      <AnimatePresence>
        {isReminderModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 15 }}
              className="bg-white dark:bg-slate-900 border-2 border-emerald-500 rounded-2xl p-5 max-w-lg w-full shadow-2xl space-y-4 font-sans"
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
                <div className="flex items-center space-x-3">
                  <div className="p-2.5 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 rounded-xl">
                    <Activity className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                      <span>Posture & Physical Comfort Check</span>
                      <Sparkles className="w-4 h-4 text-amber-400" />
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Dyspraxia-tailored stretch break & ergonomic alignment
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setIsReminderModalOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Stretch Selection Tabs */}
              <div className="flex space-x-1 overflow-x-auto pb-1 scrollbar-none">
                {DYSPRAXIA_STRETCHES.map((stretch, idx) => (
                  <button
                    key={stretch.id}
                    onClick={() => handleSelectStretch(idx)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center space-x-1 shrink-0 ${
                      activeStretchIndex === idx
                        ? 'bg-emerald-600 text-white shadow-md'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    <span>{stretch.iconName}</span>
                    <span>{stretch.title.split('&')[0]}</span>
                  </button>
                ))}
              </div>

              {/* Active Stretch Display Card */}
              <div className="p-4 rounded-xl bg-gradient-to-tr from-slate-900 via-emerald-950 to-slate-900 text-white border border-emerald-800/80 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-400 bg-emerald-950 px-2.5 py-1 rounded-full border border-emerald-800">
                    Target: {currentStretch.targetArea}
                  </span>
                  <span className="text-xs font-mono font-bold text-amber-300">
                    ⏱️ {stretchSecondsLeft}s Left
                  </span>
                </div>

                <div>
                  <h4 className="text-base font-bold text-white flex items-center gap-2">
                    <span>{currentStretch.iconName}</span>
                    <span>{currentStretch.title}</span>
                  </h4>
                  <p className="text-xs text-slate-200 leading-relaxed mt-1.5">
                    "{currentStretch.instructions}"
                  </p>
                </div>

                {/* Dyspraxia Benefit Callout */}
                <div className="p-2.5 rounded-lg bg-emerald-950/80 border border-emerald-800 text-[11px] text-emerald-200 flex items-start space-x-2">
                  <Feather className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-emerald-300 block font-bold">Dyspraxia Comfort Insight:</strong>
                    <span>{currentStretch.dyspraxiaBenefit}</span>
                  </div>
                </div>

                {/* Interactive Stretch Controls */}
                <div className="flex items-center space-x-2 pt-1">
                  {!isStretchTimerRunning ? (
                    <button
                      onClick={handleStartStretch}
                      className="flex-1 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs shadow-md flex items-center justify-center space-x-1.5 transition-all"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      <span>Start {currentStretch.durationSeconds}s Stretch Guide</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => setIsStretchTimerRunning(false)}
                      className="flex-1 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs shadow-md flex items-center justify-center space-x-1.5 transition-all"
                    >
                      <Pause className="w-4 h-4 fill-current" />
                      <span>Pause Stretch</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setStretchSecondsLeft(currentStretch.durationSeconds);
                      setIsStretchTimerRunning(false);
                    }}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
                    title="Reset Stretch Timer"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-emerald-500" />
                  Next automatic check in {intervalMinutes}m
                </span>

                <button
                  onClick={() => {
                    setIsReminderModalOpen(false);
                    soundSynth.playTone(600, 'sine', 0.15);
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center space-x-1 transition-all"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Finished & Return to Study</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
