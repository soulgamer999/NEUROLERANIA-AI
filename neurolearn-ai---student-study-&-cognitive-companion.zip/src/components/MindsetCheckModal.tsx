import React, { useState } from 'react';
import { HeartHandshake, Sparkles, Check, AlertCircle, Loader2, Brain, ArrowRight, X } from 'lucide-react';
import { MindsetDiagnosis } from '../types';

interface MindsetCheckModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyDiagnosis: (diagnosis: MindsetDiagnosis) => void;
}

const COMMON_STRUGGLES = [
  { id: 'dyslexia_words', label: 'Letters dance or words blur when reading', category: 'Dyslexia' },
  { id: 'dyslexia_slow', label: 'Takes double the time to read long passages', category: 'Dyslexia' },
  { id: 'adhd_focus', label: 'Mind drifts off after 5-10 minutes', category: 'ADHD' },
  { id: 'adhd_overwhelm', label: 'Big study tasks feel completely paralyzing', category: 'ADHD' },
  { id: 'memory_blank', label: 'Forget what I studied right during exams', category: 'Memory' },
  { id: 'exam_anxiety', label: 'Heart races & panic during quizzes', category: 'Psychological' },
  { id: 'math_fear', label: 'Numbers & formulas look like random symbols', category: 'Dyscalculia' }
];

export const MindsetCheckModal: React.FC<MindsetCheckModalProps> = ({
  isOpen,
  onClose,
  onApplyDiagnosis
}) => {
  const [selectedStruggles, setSelectedStruggles] = useState<string[]>([]);
  const [grade, setGrade] = useState('High School');
  const [goal, setGoal] = useState('');
  const [loading, setLoading] = useState(false);
  const [diagnosis, setDiagnosis] = useState<MindsetDiagnosis | null>(null);

  if (!isOpen) return null;

  const toggleStruggle = (label: string) => {
    setSelectedStruggles(prev => 
      prev.includes(label) ? prev.filter(s => s !== label) : [...prev, label]
    );
  };

  const handleAnalyze = async () => {
    if (selectedStruggles.length === 0) {
      alert("Please select at least one study challenge or mindset state.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/ai/mindset-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          struggles: selectedStruggles,
          goal: goal || "Improve confidence and make study effortless",
          currentGrade: grade
        })
      });

      if (!res.ok) {
        throw new Error(`HTTP Error ${res.status}`);
      }

      const data = await res.json();
      if (data.diagnosis) {
        setDiagnosis(data.diagnosis);
      } else {
        throw new Error("Invalid diagnosis payload");
      }
    } catch (e) {
      console.warn("Using offline fallback diagnosis payload:", e);
      const fallbackDiagnosis: MindsetDiagnosis = {
        learningArchetype: "Multi-Sensory Visual Explorer",
        psychologicalInsight: "Your brain processes complex concepts best through visual structure, interactive micro-sprints, and hands-on flashcards rather than continuous passive text reading.",
        topStrategies: [
          "Bionic Font Reading Adaptation",
          "15-Minute Hyper-Focused Study Blocks",
          "5-4-3-2-1 Sensory Grounding for Stress"
        ],
        recommendedFontMode: "dyslexic",
        encouragementQuote: "You are not failing—your brain simply processes information uniquely! Embrace your visual strengths."
      };
      setDiagnosis(fallbackDiagnosis);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
        >
          <X className="w-5 h-5" />
        </button>

        {!diagnosis ? (
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-3 bg-amber-100 dark:bg-amber-950/80 rounded-xl text-amber-600 dark:text-amber-400">
                <HeartHandshake className="w-6 h-6" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                  Student Psychological Mind Check-In
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Tell our AI Special Education Psychologist how your mind feels during studies.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                  1. What obstacles do you face when studying?
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {COMMON_STRUGGLES.map((item) => {
                    const active = selectedStruggles.includes(item.label);
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => toggleStruggle(item.label)}
                        className={`p-3 rounded-xl border text-left text-xs transition-all flex items-start space-x-2.5 ${
                          active
                            ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-950 dark:text-indigo-200 font-medium shadow-xs'
                            : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <div className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center shrink-0 ${active ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-300 dark:border-slate-600'}`}>
                          {active && <Check className="w-3 h-3" />}
                        </div>
                        <div>
                          <span>{item.label}</span>
                          <span className="block text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                            {item.category}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Grade / Academic Level
                  </label>
                  <select
                    value={grade}
                    onChange={(e) => setGrade(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="Elementary School">Elementary School</option>
                    <option value="Middle School">Middle School</option>
                    <option value="High School">High School</option>
                    <option value="College / University">College / University</option>
                    <option value="Self Learner">Self Learner</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Current Study Goal (Optional)
                  </label>
                  <input
                    type="text"
                    value={goal}
                    onChange={(e) => setGoal(e.target.value)}
                    placeholder="e.g. Master History exam without stress"
                    className="w-full text-xs p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="pt-3">
                <button
                  onClick={handleAnalyze}
                  disabled={loading}
                  className="w-full py-3 px-4 bg-gradient-to-r from-indigo-600 via-indigo-700 to-teal-600 hover:from-indigo-700 hover:to-teal-700 text-white font-medium text-sm rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Analyzing Your Cognitive Style...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Diagnose & Adapt My Study Experience</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div>
            <div className="text-center py-2 mb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 text-xs font-semibold mb-2">
                <Brain className="w-3.5 h-3.5" />
                <span>Cognitive Profile Discovered</span>
              </div>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                {diagnosis.learningArchetype}
              </h2>
            </div>

            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60 text-xs text-indigo-900 dark:text-indigo-200 leading-relaxed">
                <p className="font-semibold mb-1 text-indigo-700 dark:text-indigo-300">
                  Psychologist's Perspective:
                </p>
                {diagnosis.psychologicalInsight}
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                  Recommended Cognitive Strategies:
                </h4>
                <ul className="space-y-1.5">
                  {diagnosis.topStrategies.map((strat, i) => (
                    <li key={i} className="flex items-center space-x-2 text-xs text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-800 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700">
                      <div className="w-5 h-5 rounded-full bg-teal-500 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                        {i + 1}
                      </div>
                      <span>{strat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200 dark:border-amber-900 text-center text-xs italic text-amber-800 dark:text-amber-300">
                "{diagnosis.encouragementQuote}"
              </div>

              <div className="flex space-x-3 pt-2">
                <button
                  onClick={() => setDiagnosis(null)}
                  className="flex-1 py-2.5 text-xs font-medium border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                >
                  Re-test
                </button>
                <button
                  onClick={() => {
                    onApplyDiagnosis(diagnosis);
                    onClose();
                  }}
                  className="flex-1 py-2.5 text-xs font-medium bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs flex items-center justify-center space-x-1.5"
                >
                  <span>Apply Recommendations</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
