import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  Minimize2, 
  X, 
  Heart, 
  Hand, 
  Coffee, 
  Clock, 
  MessageSquare, 
  Settings, 
  RefreshCw, 
  ShieldCheck, 
  Smile, 
  Zap,
  Quote,
  CheckCircle2,
  ChevronDown,
  Compass
} from 'lucide-react';
import { StudyBuddyMode, StudyBuddyPartner, StudyBuddyQuote } from '../types';
import { soundSynth } from '../utils/audio';

const STUDY_PARTNERS: StudyBuddyPartner[] = [
  {
    id: 'alex',
    name: 'Alex',
    subject: 'Organic Chemistry & Bio',
    avatarBg: 'bg-emerald-500',
    avatarIcon: '🧪',
    statusMessages: [
      'Organizing color-coded mind maps for reactions...',
      'Taking a quiet sip of water and stretching...',
      'Deep in focus reviewing carbon structures...',
      'Just completed 15 minutes of solid practice!',
      'Highlighting key textbook definitions silently...'
    ]
  },
  {
    id: 'maya',
    name: 'Maya',
    subject: 'Calculus & Physics',
    avatarBg: 'bg-indigo-500',
    avatarIcon: '📐',
    statusMessages: [
      'Working through practice derivatives step-by-step...',
      'Quietly double-checking equation calculations...',
      'Pencil scratching on notepad, deep in flow state...',
      'Taking a deep breath before the next problem set...',
      'Mastered 3 complex physics formulas!'
    ]
  },
  {
    id: 'leo',
    name: 'Leo',
    subject: 'World History & Lit',
    avatarBg: 'bg-amber-500',
    avatarIcon: '📚',
    statusMessages: [
      'Reading Chapter 7 with a yellow highlighter...',
      'Outlining main historical essay themes...',
      'Quietly sipping herbal tea while skimming notes...',
      'Making flashcards for tomorrow\'s review...',
      'Nodding along to focused study music...'
    ]
  },
  {
    id: 'sam',
    name: 'Sam',
    subject: 'Algorithms & Coding',
    avatarBg: 'bg-teal-500',
    avatarIcon: '💻',
    statusMessages: [
      'Debugging code logic in a distraction-free window...',
      'Tracing recursive tree traversal algorithms...',
      'Taking a quick 20-second eye rest (20-20-20 rule)...',
      'Refactoring function syntax cleanly...',
      'Typing steadily, keeping the momentum going!'
    ]
  }
];

const MOTIVATIONAL_QUOTES: (StudyBuddyQuote & { emotionTag?: string })[] = [
  {
    id: 'q1',
    quote: 'You do not need to finish everything right now — just focus on this single minute.',
    category: 'adhd_focus',
    emotionTag: 'calm_zen',
    author: 'ADHD Executive Focus Insight'
  },
  {
    id: 'q2',
    quote: 'Learning friction is proof that your brain is actively building new neural pathways!',
    category: 'resilience',
    emotionTag: 'curiosity',
    author: 'Neuroplasticity Research'
  },
  {
    id: 'q3',
    quote: 'Progress is not always linear. Be proud of yourself for showing up and starting.',
    category: 'praise',
    emotionTag: 'encouragement',
    author: 'Mindset Coaching'
  },
  {
    id: 'q4',
    quote: 'Take a soft, slow breath. Release your shoulders and unclench your jaw.',
    category: 'anxiety_calm',
    emotionTag: 'empathy',
    author: 'Somatic Grounding'
  },
  {
    id: 'q5',
    quote: 'BOOM! What if we break this problem into 3 super fast 5-minute micro-sprints?!',
    category: 'adhd_focus',
    emotionTag: 'energetic_hype',
    author: 'High-Energy Focus Coach'
  },
  {
    id: 'q6',
    quote: 'Why do you think this formula works? What breaks if we change the constant?',
    category: 'resilience',
    emotionTag: 'socratic',
    author: 'Socratic Method'
  },
  {
    id: 'q7',
    quote: 'Strip away the noise: Identify inputs, process transformations, and expected outputs.',
    category: 'adhd_focus',
    emotionTag: 'analytical_direct',
    author: 'Analytical Logic'
  },
  {
    id: 'q8',
    quote: 'Don\'t stop at the easy answer! Can you explain this concept to a 10-year-old?',
    category: 'praise',
    emotionTag: 'constructive_challenge',
    author: 'Challenge Mindset'
  }
];

interface AIStudyBuddyOverlayProps {
  isVisible?: boolean;
  onToggleVisible?: () => void;
}

export const AIStudyBuddyOverlay: React.FC<AIStudyBuddyOverlayProps> = ({
  isVisible = true,
  onToggleVisible
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [activeMode, setActiveMode] = useState<StudyBuddyMode>('body_doubling');
  const [selectedPartner, setSelectedPartner] = useState<StudyBuddyPartner>(STUDY_PARTNERS[0]);
  const [currentStatusIndex, setCurrentStatusIndex] = useState(0);
  const [coWorkingMinutes, setCoWorkingMinutes] = useState(12);
  const [partnerReaction, setPartnerReaction] = useState<string | null>(null);
  
  // Quotes state
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);
  const [autoRotateQuotes, setAutoRotateQuotes] = useState(true);
  
  // Settings & Sound
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [position, setPosition] = useState<'right' | 'left'>('right');

  // Co-working timer & status rotator
  useEffect(() => {
    const timer = setInterval(() => {
      setCoWorkingMinutes(prev => prev + 1);
      setCurrentStatusIndex(prev => (prev + 1) % selectedPartner.statusMessages.length);
    }, 25000); // rotates status every 25s

    return () => clearInterval(timer);
  }, [selectedPartner]);

  // Quote auto-rotator
  useEffect(() => {
    if (!autoRotateQuotes) return;

    const quoteTimer = setInterval(() => {
      setCurrentQuoteIndex(prev => (prev + 1) % MOTIVATIONAL_QUOTES.length);
    }, 45000); // rotates quotes every 45s

    return () => clearInterval(quoteTimer);
  }, [autoRotateQuotes]);

  const handleHighFive = () => {
    if (soundEnabled) soundSynth.playChime(true);
    setPartnerReaction(`${selectedPartner.name} high-fives back! ✋✨ "We're crushing this session together!"`);
    setTimeout(() => setPartnerReaction(null), 4000);
  };

  const handleWaterBreak = () => {
    if (soundEnabled) soundSynth.playTone(600, 'sine', 0.2);
    setPartnerReaction(`${selectedPartner.name} nods in agreement: ☕ "Hydration check! Great time for a quick 30-second stretch."`);
    setTimeout(() => setPartnerReaction(null), 4000);
  };

  const handleNextQuote = () => {
    if (soundEnabled) soundSynth.playTone(750, 'sine', 0.1);
    setCurrentQuoteIndex((prevIndex) => (prevIndex + 1) % MOTIVATIONAL_QUOTES.length);
  };

  if (!isVisible) {
    return (
      <button
        onClick={onToggleVisible}
        className={`fixed bottom-5 ${position === 'right' ? 'right-5' : 'left-5'} z-40 px-3.5 py-2 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-xl flex items-center space-x-2 transition-all`}
        title="Open AI Study Buddy & Body Doubler"
      >
        <Users className="w-4 h-4 text-emerald-300" />
        <span>Study Buddy</span>
      </button>
    );
  }

  const activeQuote = MOTIVATIONAL_QUOTES[currentQuoteIndex];

  return (
    <div className={`fixed bottom-4 ${position === 'right' ? 'right-4 sm:right-6' : 'left-4 sm:left-6'} z-50 max-w-sm w-full font-sans`}>
      <AnimatePresence mode="wait">
        {!isExpanded ? (
          /* MINIMIZED PILL VIEW */
          <motion.div
            key="minimized"
            initial={{ scale: 0.9, opacity: 0, y: 10 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 10 }}
            onClick={() => setIsExpanded(true)}
            className="cursor-pointer bg-slate-900/95 dark:bg-slate-900/95 border-2 border-indigo-500/80 hover:border-indigo-400 backdrop-blur-md rounded-2xl p-3 shadow-2xl text-white flex items-center justify-between transition-all group"
          >
            <div className="flex items-center space-x-3 overflow-hidden">
              <div className="relative shrink-0">
                <div className={`w-10 h-10 rounded-xl ${selectedPartner.avatarBg} flex items-center justify-center text-lg shadow-md`}>
                  {selectedPartner.avatarIcon}
                </div>
                <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-900 rounded-full animate-pulse" />
              </div>

              <div className="min-w-0">
                <div className="flex items-center space-x-1.5">
                  <span className="text-xs font-black text-white truncate">
                    {selectedPartner.name} ({selectedPartner.subject})
                  </span>
                  <span className="text-[9px] font-bold bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/30 shrink-0">
                    Body Doubler
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 truncate group-hover:text-amber-300 transition-colors">
                  {activeMode === 'body_doubling' 
                    ? selectedPartner.statusMessages[currentStatusIndex] 
                    : `💬 "${activeQuote.quote}"`}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-1 ml-2 shrink-0">
              <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">
                {coWorkingMinutes}m
              </span>
              <div className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300">
                <Maximize2 className="w-3.5 h-3.5" />
              </div>
            </div>
          </motion.div>
        ) : (
          /* EXPANDED COMPANION CARD */
          <motion.div
            key="expanded"
            initial={{ scale: 0.9, opacity: 0, y: 15 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 15 }}
            className="bg-white dark:bg-slate-900 border-2 border-indigo-500 rounded-2xl shadow-2xl overflow-hidden flex flex-col space-y-0"
          >
            {/* Header Banner */}
            <div className="bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 p-3.5 text-white flex items-center justify-between border-b border-indigo-800">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-indigo-600/80 rounded-xl text-emerald-300 shadow-md">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-black tracking-wide text-white flex items-center gap-1.5">
                    <span>AI Study Buddy & Body Doubler</span>
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  </h3>
                  <p className="text-[10px] text-indigo-200">
                    Non-intrusive co-working partner & psychological encouragement
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-1">
                <button
                  onClick={() => setIsExpanded(false)}
                  className="p-1 rounded-lg hover:bg-indigo-800/60 text-slate-300 hover:text-white transition-colors"
                  title="Minimize Buddy Window"
                >
                  <Minimize2 className="w-4 h-4" />
                </button>
                {onToggleVisible && (
                  <button
                    onClick={onToggleVisible}
                    className="p-1 rounded-lg hover:bg-rose-900/60 text-slate-300 hover:text-rose-300 transition-colors"
                    title="Hide Study Buddy"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Mode Switcher Tabs */}
            <div className="flex items-center border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 p-1">
              <button
                onClick={() => setActiveMode('body_doubling')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center space-x-1 ${
                  activeMode === 'body_doubling'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Body Doubler</span>
              </button>

              <button
                onClick={() => setActiveMode('affirmations')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center space-x-1 ${
                  activeMode === 'affirmations'
                    ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Quote className="w-3.5 h-3.5" />
                <span>Quotes</span>
              </button>

              <button
                onClick={() => setActiveMode('zen_observer')}
                className={`flex-1 py-1.5 px-2 rounded-lg text-[11px] font-bold transition-all flex items-center justify-center space-x-1 ${
                  activeMode === 'zen_observer'
                    ? 'bg-white dark:bg-slate-900 text-teal-600 dark:text-teal-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Compass className="w-3.5 h-3.5" />
                <span>Zen Observer</span>
              </button>
            </div>

            {/* TAB CONTENT CONTAINER */}
            <div className="p-4 space-y-3.5">
              {/* MODE 1: BODY DOUBLING PARTNER */}
              {activeMode === 'body_doubling' && (
                <div className="space-y-3">
                  {/* Select Partner Selector */}
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] uppercase font-extrabold text-slate-500 dark:text-slate-400">
                      Select Co-Working Partner:
                    </span>
                    <div className="flex items-center space-x-1">
                      {STUDY_PARTNERS.map((partner) => (
                        <button
                          key={partner.id}
                          onClick={() => {
                            setSelectedPartner(partner);
                            setCurrentStatusIndex(0);
                            if (soundEnabled) soundSynth.playTone(650, 'sine', 0.1);
                          }}
                          className={`w-7 h-7 rounded-lg text-xs flex items-center justify-center transition-all ${
                            selectedPartner.id === partner.id
                              ? `${partner.avatarBg} text-white ring-2 ring-indigo-400 scale-110 shadow-sm`
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 opacity-60 hover:opacity-100'
                          }`}
                          title={`${partner.name} - ${partner.subject}`}
                        >
                          {partner.avatarIcon}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Active Partner Card */}
                  <div className="p-3.5 rounded-xl bg-gradient-to-tr from-slate-900 to-indigo-950 text-white border border-indigo-800 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2.5">
                        <div className={`w-9 h-9 rounded-xl ${selectedPartner.avatarBg} flex items-center justify-center text-base shadow-md`}>
                          {selectedPartner.avatarIcon}
                        </div>
                        <div>
                          <div className="flex items-center space-x-1.5">
                            <h4 className="text-xs font-extrabold text-white">
                              {selectedPartner.name}
                            </h4>
                            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                          </div>
                          <p className="text-[10px] text-indigo-200">
                            Studying {selectedPartner.subject}
                          </p>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                          {coWorkingMinutes}m Co-Working
                        </span>
                      </div>
                    </div>

                    {/* Live Partner Status */}
                    <div className="p-2.5 rounded-lg bg-slate-900/90 border border-slate-800 text-xs text-slate-200 flex items-start space-x-2">
                      <Sparkles className="w-4 h-4 text-amber-300 shrink-0 mt-0.5 animate-pulse" />
                      <p className="italic text-[11px] leading-relaxed">
                        "{selectedPartner.statusMessages[currentStatusIndex]}"
                      </p>
                    </div>

                    {/* Interactive Reaction Alert */}
                    {partnerReaction && (
                      <motion.div
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-2 rounded-lg bg-emerald-950/90 border border-emerald-500/80 text-[11px] text-emerald-200 font-bold"
                      >
                        {partnerReaction}
                      </motion.div>
                    )}

                    {/* Interactive Action Buttons */}
                    <div className="flex items-center space-x-2 pt-1">
                      <button
                        onClick={handleHighFive}
                        className="flex-1 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[11px] shadow-sm flex items-center justify-center space-x-1 transition-all"
                      >
                        <Hand className="w-3.5 h-3.5 text-amber-300" />
                        <span>High-Five ✋</span>
                      </button>

                      <button
                        onClick={handleWaterBreak}
                        className="flex-1 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-indigo-200 font-bold text-[11px] border border-slate-700 flex items-center justify-center space-x-1 transition-all"
                      >
                        <Coffee className="w-3.5 h-3.5 text-amber-400" />
                        <span>Stretch & Water ☕</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* MODE 2: NON-INTRUSIVE MOTIVATIONAL QUOTES */}
              {activeMode === 'affirmations' && (
                <div className="space-y-3">
                  <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-slate-900 dark:text-slate-100 space-y-2">
                    <div className="flex items-center justify-between text-[10px] font-bold text-amber-700 dark:text-amber-300 uppercase tracking-wider">
                      <span className="flex items-center gap-1">
                        <Quote className="w-3.5 h-3.5" />
                        {activeQuote.category.replace('_', ' ')}
                      </span>
                      <span>Quote {currentQuoteIndex + 1}/{MOTIVATIONAL_QUOTES.length}</span>
                    </div>

                    <p className="text-xs sm:text-sm font-semibold leading-relaxed text-slate-800 dark:text-slate-200 italic">
                      "{activeQuote.quote}"
                    </p>

                    <p className="text-[10px] text-slate-500 dark:text-slate-400 text-right font-medium">
                      — {activeQuote.author}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <button
                      onClick={() => setAutoRotateQuotes(!autoRotateQuotes)}
                      className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all flex items-center space-x-1 ${
                        autoRotateQuotes 
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-300' 
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200'
                      }`}
                    >
                      <RefreshCw className={`w-3 h-3 ${autoRotateQuotes ? 'animate-spin' : ''}`} />
                      <span>{autoRotateQuotes ? 'Auto-Rotate ON' : 'Auto-Rotate OFF'}</span>
                    </button>

                    <button
                      onClick={handleNextQuote}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs shadow-sm flex items-center space-x-1 transition-all"
                    >
                      <span>Next Quote</span>
                      <Sparkles className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              {/* MODE 3: ZEN OBSERVER */}
              {activeMode === 'zen_observer' && (
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-center space-y-3">
                  <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
                    <div className="absolute inset-0 rounded-full bg-teal-500/20 animate-ping" />
                    <div className="w-12 h-12 rounded-full bg-teal-500/40 flex items-center justify-center text-teal-300 font-bold border border-teal-400/80 shadow-lg">
                      <Compass className="w-6 h-6 animate-spin" style={{ animationDuration: '12s' }} />
                    </div>
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-white">
                      Zen Focus Mode Active
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-1">
                      No text popups or distractions. Your study buddy is quietly observing and holding space for your focus.
                    </p>
                  </div>
                </div>
              )}

              {/* Bottom Quick Settings */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[10px] text-slate-500 dark:text-slate-400">
                <button
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  className="hover:text-slate-800 dark:hover:text-slate-200 flex items-center space-x-1"
                >
                  {soundEnabled ? <Volume2 className="w-3 h-3 text-indigo-500" /> : <VolumeX className="w-3 h-3" />}
                  <span>Chimes: {soundEnabled ? 'ON' : 'OFF'}</span>
                </button>

                <button
                  onClick={() => setPosition(position === 'right' ? 'left' : 'right')}
                  className="hover:text-slate-800 dark:hover:text-slate-200"
                >
                  Position: <strong className="capitalize">{position}</strong>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
