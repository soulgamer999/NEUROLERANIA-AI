import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Play, 
  Pause, 
  ChevronRight, 
  ChevronLeft, 
  Volume2, 
  VolumeX, 
  Loader2, 
  BookOpen, 
  CheckCircle2, 
  HelpCircle, 
  Lightbulb,
  Maximize2,
  GraduationCap,
  RotateCcw,
  MessageSquare,
  Sliders,
  Battery,
  Zap,
  Smile,
  ShieldCheck,
  Activity,
  Flame,
  Brain
} from 'lucide-react';
import { TeacherPresentation, UserPreferences } from '../types';
import { AnimatedRobotCharacter, RobotPose } from './AnimatedRobotCharacter';

export type TeacherEmotionTone = 'encouraging' | 'serious' | 'playful' | 'direct';

export interface TeacherEmotionOption {
  id: TeacherEmotionTone;
  label: string;
  icon: string;
  badgeBg: string;
  badgeText: string;
  borderColor: string;
  description: string;
  speechStyle: string;
}

const TEACHER_EMOTION_OPTIONS: TeacherEmotionOption[] = [
  {
    id: 'encouraging',
    label: 'Encouraging',
    icon: '🌟',
    badgeBg: 'bg-emerald-500/15 dark:bg-emerald-500/20',
    badgeText: 'text-emerald-700 dark:text-emerald-300',
    borderColor: 'border-emerald-500',
    description: 'Warm, supportive & uplifting praise that celebrates effort and builds confidence.',
    speechStyle: 'Warm praise, celebratory milestones & gentle reassurance'
  },
  {
    id: 'serious',
    label: 'Serious',
    icon: '🎓',
    badgeBg: 'bg-blue-500/15 dark:bg-blue-500/20',
    badgeText: 'text-blue-700 dark:text-blue-300',
    borderColor: 'border-blue-500',
    description: 'Formal academic rigor with precise definitions and structured analytical depth.',
    speechStyle: 'Formal academic definitions, logical rigor & precise structure'
  },
  {
    id: 'playful',
    label: 'Playful',
    icon: '🎨',
    badgeBg: 'bg-purple-500/15 dark:bg-purple-500/20',
    badgeText: 'text-purple-700 dark:text-purple-300',
    borderColor: 'border-purple-500',
    description: 'Fun analogies, humor, jokes, gamified micro-challenges & high-energy excitement!',
    speechStyle: 'Humorous analogies, energetic jokes & gamified metaphors'
  },
  {
    id: 'direct',
    label: 'Direct',
    icon: '⚡',
    badgeBg: 'bg-amber-500/15 dark:bg-amber-500/20',
    badgeText: 'text-amber-700 dark:text-amber-300',
    borderColor: 'border-amber-500',
    description: 'Razor-sharp, concise, no-fluff steps for high-efficiency learning.',
    speechStyle: 'Bullet-proof, razor-sharp, zero-fluff conciseness'
  }
];

interface RobotTeacherPresentationProps {
  prefs: UserPreferences;
  emotion?: TeacherEmotionTone;
}

export const RobotTeacherPresentation: React.FC<RobotTeacherPresentationProps> = ({ prefs, emotion }) => {
  const [topicInput, setTopicInput] = useState('Cell Biology & Energy');
  const [loading, setLoading] = useState(false);
  const [presentation, setPresentation] = useState<TeacherPresentation | null>(null);
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [selectedQuizOption, setSelectedQuizOption] = useState<number | null>(null);
  const [showQuizResult, setShowQuizResult] = useState(false);
  const [robotPose, setRobotPose] = useState<RobotPose>('idle');

  // AI Persona & Mental Battery Interactive States
  const [emotionTone, setEmotionTone] = useState<TeacherEmotionTone>(emotion || 'encouraging');
  const [mentalBattery, setMentalBattery] = useState<number>(85);

  useEffect(() => {
    if (emotion) {
      setEmotionTone(emotion);
    }
  }, [emotion]);

  const getBatteryModeInfo = (battery: number) => {
    if (battery <= 40) {
      return {
        status: 'Low Focus (Fatigue Protection)',
        badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
        icon: '🪫',
        strategy: 'Supportive & High-Energy Boost',
        description: 'Micro-chunked steps, gentle encouraging feedback, extra high-energy praise, and simple bite-sized concepts to prevent cognitive fatigue.'
      };
    } else if (battery >= 80) {
      return {
        status: 'High Focus (Deep Engagement)',
        badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
        icon: '⚡',
        strategy: 'Concise & High-Efficiency Guidance',
        description: 'Razor-sharp, high-density explanations, advanced conceptual insights, and fast-paced guidance for maximum throughput.'
      };
    } else {
      return {
        status: 'Balanced Focus',
        badgeBg: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
        icon: '🔋',
        strategy: 'Standard Guided Learning',
        description: 'Clear visual step-by-step breakdowns with steady pacing and interactive checkpoints.'
      };
    }
  };

  const selectedToneOption = TEACHER_EMOTION_OPTIONS.find(o => o.id === emotionTone) || TEACHER_EMOTION_OPTIONS[0];
  const batteryMode = getBatteryModeInfo(mentalBattery);

  // Helper for generating tone-specific and battery-specific fallback dialogue
  const getFallbackDialogue = (topic: string, slideNum: number, tone: TeacherEmotionTone, battery: number) => {
    let intro = "";
    if (tone === 'serious') {
      intro = `Analyzing ${topic} with academic precision for Slide ${slideNum}.`;
    } else if (tone === 'playful') {
      intro = `Woohoo! Welcome to Slide ${slideNum} of our super fun ${topic} adventure!`;
    } else if (tone === 'direct') {
      intro = `Slide ${slideNum} core concept breakdown for ${topic}.`;
    } else {
      intro = `Hello my brilliant student! Welcome to Slide ${slideNum} on ${topic}. You are going to do amazing!`;
    }

    let batteryNote = "";
    if (battery <= 40) {
      batteryNote = " I see your mental battery is low right now, so I've simplified this into tiny, easy steps with extra encouragement to keep you going without fatigue!";
    } else if (battery >= 80) {
      batteryNote = " Your mental battery is charged high! Let's examine advanced, high-density insights straight to the point.";
    } else {
      batteryNote = " Let's learn together at a clear, steady pace.";
    }

    return `${intro}${batteryNote}`;
  };

  // Default sample presentation for instant loads
  const defaultPresentation: TeacherPresentation = {
    topic: "Cell Biology & Energy Production",
    subtitle: "Understanding Mitochondria & Cellular Respiration",
    estimatedTimeMins: 5,
    slides: [
      {
        slideNumber: 1,
        title: "Welcome to Cell Biology! Meet the Powerhouse",
        robotTeacherDialogue: "Hello my brilliant student! I'm Robo-Teacher! Today we're exploring Cell Biology. Don't worry if it sounds complex—we'll break it into super simple visual chunks!",
        bulletPoints: [
          "Every living thing is made of tiny building blocks called Cells.",
          "Inside each cell, organelle 'mini-factories' carry out specialized jobs.",
          "The Mitochondria is the 'Power Plant' that converts food into energy (ATP)."
        ],
        visualDiagramHint: "⚡ Cell Diagram: Cytoplasm ➔ Mitochondria Outer Membrane ➔ ATP Energy Release",
        keyTakeaway: "Cells need energy to live, and Mitochondria generate that energy!"
      },
      {
        slideNumber: 2,
        title: "How ATP Energy is Made (The 3-Step Process)",
        robotTeacherDialogue: "Think of ATP as the currency or batteries of your body. When you run or think, your cells spend ATP batteries!",
        bulletPoints: [
          "Step 1: Glucose (Sugar from food) enters the cell cytoplasm.",
          "Step 2: Glycolysis breaks sugar into smaller pyruvate molecules.",
          "Step 3: Mitochondria use Oxygen to produce 36 ATP energy packages!"
        ],
        visualDiagramHint: "🍎 Food Sugar + 🫁 Oxygen ➔ ⚡ 36 ATP Energy + 💨 Carbon Dioxide",
        keyTakeaway: "Glucose + Oxygen = Energy (ATP) + Carbon Dioxide waste."
      },
      {
        slideNumber: 3,
        title: "Memory Trick: The Battery Mnemonic",
        robotTeacherDialogue: "Struggling to remember Mitochondria? Use my Robo-Mnemonic trick!",
        bulletPoints: [
          "MIGHTY-chondria = MIGHTY Energy Power Station!",
          "ATP = Always Turbo Powered!",
          "Respiration = Cell Breathing in Oxygen to burn Fuel."
        ],
        visualDiagramHint: "🔋 MIGHTY-Chondria Battery Charger Analogy",
        keyTakeaway: "Use vivid associations (Mighty = Powerhouse) to lock concepts in memory!"
      },
      {
        slideNumber: 4,
        title: "Real World Connection & Exam Trick",
        robotTeacherDialogue: "Why do muscle cells have 1,000s of mitochondria while skin cells have fewer? Because muscles move constantly and need tons of battery power!",
        bulletPoints: [
          "Exam Tip: If a test asks which cells have the MOST mitochondria, pick active cells (Muscle, Heart, Brain).",
          "Deep breath check: When you breathe hard during exercise, you are supplying Oxygen to your Mitochondria!"
        ],
        visualDiagramHint: "🏃 Muscle Cell = High Mitochondria Density | 🖐️ Skin Cell = Lower Density",
        keyTakeaway: "More active tissues require significantly higher mitochondrial density."
      }
    ],
    classroomQuiz: {
      question: "Which organelle is known as the 'Powerhouse of the Cell' because it creates ATP energy?",
      options: [
        "Ribosome",
        "Mitochondria",
        "Nucleus",
        "Golgi Body"
      ],
      correctIndex: 1,
      teacherFeedback: "Spot on! Mitochondria generates ATP energy for cellular functions!"
    },
    stressReliefTip: "Take a deep breath! You don't need to memorize every single word at once—focus on the core picture first."
  };

  useEffect(() => {
    // Set default presentation on mount
    setPresentation(defaultPresentation);
  }, []);

  const handleFetchPresentation = async (topicToFetch?: string) => {
    const query = topicToFetch || topicInput;
    if (!query.trim()) return;

    setLoading(true);
    setCurrentSlideIndex(0);
    setSelectedQuizOption(null);
    setShowQuizResult(false);
    stopSpeech();

    try {
      const res = await fetch('/api/ai/teacher-presentation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: query,
          gradeLevel: "Student",
          learningStyle: "Visual",
          emotionTone,
          mentalBattery
        })
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data = await res.json();
      if (data.presentation && data.presentation.slides?.length > 0) {
        setPresentation(data.presentation);
        speakText(data.presentation.slides[0].robotTeacherDialogue);
      } else {
        throw new Error("Invalid presentation format returned.");
      }
    } catch (e) {
      console.warn("Using offline fallback presentation engine due to network/API state:", e);
      const fallbackPres: TeacherPresentation = {
        topic: query,
        subtitle: `Mastering ${query} (${selectedToneOption.label} Mode | ${mentalBattery}% Battery)`,
        estimatedTimeMins: 5,
        slides: [
          {
            slideNumber: 1,
            title: `Introduction to ${query}`,
            robotTeacherDialogue: getFallbackDialogue(query, 1, emotionTone, mentalBattery),
            bulletPoints: [
              `Core concept of ${query} explained under ${selectedToneOption.label} persona guidance.`,
              `Mental Battery Adaptive Focus: ${batteryMode.strategy}.`,
              `How this topic connects directly to real-world examples.`
            ],
            visualDiagramHint: `📊 Visual Diagram: Core Overview of ${query}`,
            keyTakeaway: `Focus on the main definition before diving into complex details.`,
            emotion: emotionTone === 'playful' ? 'excitement' : emotionTone === 'serious' ? 'thinking' : emotionTone === 'direct' ? 'pointing' : 'empathy'
          },
          {
            slideNumber: 2,
            title: `Step-by-Step Mechanics of ${query}`,
            robotTeacherDialogue: getFallbackDialogue(query, 2, emotionTone, mentalBattery),
            bulletPoints: [
              `Step 1: Identify the main inputs and rules.`,
              `Step 2: Observe how components interact together.`,
              `Step 3: Track the outcome or final equation.`
            ],
            visualDiagramHint: `🔄 Flowchart: Step 1 ➔ Step 2 ➔ Step 3`,
            keyTakeaway: `Breaking processes into 3 steps prevents cognitive overload.`,
            emotion: 'pointing'
          },
          {
            slideNumber: 3,
            title: `Memory Trick & Exam Strategy`,
            robotTeacherDialogue: getFallbackDialogue(query, 3, emotionTone, mentalBattery),
            bulletPoints: [
              `Use vivid associations to link formulas or definitions.`,
              `Common exam trap: double-check key terminology in questions.`,
              `Active Recall: explain this concept out loud to a friend or yourself.`
            ],
            visualDiagramHint: `🧠 Memory Anchor for ${query}`,
            keyTakeaway: `Mnemonics and active recall lock concepts into long-term memory.`,
            emotion: 'empathy'
          }
        ],
        classroomQuiz: {
          question: `What is the most effective approach when studying ${query}?`,
          options: [
            `Breaking the concept into clear step-by-step visual chunks`,
            `Cramming for 8 hours without resting`,
            `Ignoring definitions and formulas`,
            `Avoiding practice questions`
          ],
          correctIndex: 0,
          teacherFeedback: `Spot on! Visual chunking and step-by-step learning build lasting understanding!`
        },
        stressReliefTip: `Take a deep breath! Learning ${query} is a process—take it one slide at a time.`
      };

      setPresentation(fallbackPres);
      speakText(fallbackPres.slides[0].robotTeacherDialogue);
    } finally {
      setLoading(false);
    }
  };

  // Speech Synth
  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = prefs.speechSpeed || 1.0;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  const stopSpeech = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const currentSlide = presentation?.slides[currentSlideIndex];

  const handleNextSlide = () => {
    if (presentation && currentSlideIndex < presentation.slides.length) {
      const nextIdx = currentSlideIndex + 1;
      setCurrentSlideIndex(nextIdx);
      if (nextIdx < presentation.slides.length) {
        speakText(presentation.slides[nextIdx].robotTeacherDialogue);
      }
    }
  };

  const handlePrevSlide = () => {
    if (currentSlideIndex > 0) {
      const prevIdx = currentSlideIndex - 1;
      setCurrentSlideIndex(prevIdx);
      if (presentation) {
        speakText(presentation.slides[prevIdx].robotTeacherDialogue);
      }
    }
  };

  const presetTopics = [
    "Cell Biology & Energy",
    "Newton's 3 Laws of Motion",
    "How to Overcome Exam Anxiety",
    "Solving Quadratic Equations",
    "Photosynthesis Step-by-Step",
    "World War II Key Causes"
  ];

  return (
    <div className="space-y-6" role="region" aria-label="AI Robot Teacher Interactive Classroom">
      {/* Search & Topic Selector Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 md:p-5 shadow-sm">
        <div className="flex items-center space-x-2 mb-3">
          <GraduationCap className="w-5 h-5 text-indigo-600 dark:text-indigo-400" aria-hidden="true" />
          <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            AI Robot Teacher Presentation Classroom
          </h2>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2 mb-3">
          <div className="relative flex-1 w-full">
            <input
              type="text"
              value={topicInput}
              onChange={(e) => setTopicInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleFetchPresentation()}
              placeholder="Ask Robo-Teacher to present any topic (e.g. Calculus, Cell Biology, Beating Stress)..."
              className="w-full pl-4 pr-10 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-medium focus:ring-2 focus:ring-indigo-500 outline-none"
            />
            {loading && (
              <Loader2 className="w-4 h-4 text-indigo-600 animate-spin absolute right-3 top-3.5" />
            )}
          </div>
          <button
            onClick={() => handleFetchPresentation()}
            disabled={loading}
            className="w-full sm:w-auto px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 shrink-0 disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate Lesson</span>
          </button>
        </div>

        {/* Preset Chips */}
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mr-1">Quick Lessons:</span>
          {presetTopics.map((topic, i) => (
            <button
              key={i}
              onClick={() => {
                setTopicInput(topic);
                handleFetchPresentation(topic);
              }}
              className="text-[11px] font-medium px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 border border-slate-200 dark:border-slate-700 transition-all"
            >
              {topic}
            </button>
          ))}
        </div>
      </div>

      {/* AI PERSONA & ADAPTIVE TONE DASHBOARD */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 md:p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-black text-slate-900 dark:text-white uppercase tracking-wider">
                AI Persona & Adaptive Tone Dashboard
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Dynamically adjust Robo-Teacher's emotional persona and focus battery responsiveness
              </p>
            </div>
          </div>

          {/* Live Status Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold border flex items-center space-x-1.5 ${batteryMode.badgeBg}`}>
              <span>{batteryMode.icon}</span>
              <span>{batteryMode.status} ({mentalBattery}%)</span>
            </span>
            <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 flex items-center space-x-1">
              <span>{selectedToneOption.icon}</span>
              <span>{selectedToneOption.label}</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* 1. TUTOR EMOTIONAL PERSONA SELECTION */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center space-x-1.5">
              <Brain className="w-3.5 h-3.5 text-indigo-500" />
              <span>1. Select AI Tutor Emotional Persona:</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {TEACHER_EMOTION_OPTIONS.map((option) => {
                const active = emotionTone === option.id;
                return (
                  <button
                    key={option.id}
                    onClick={() => setEmotionTone(option.id)}
                    className={`p-3 rounded-xl border text-left transition-all flex flex-col justify-between ${
                      active
                        ? `${option.borderColor} bg-indigo-50/50 dark:bg-indigo-950/50 ring-2 ring-indigo-500/30 shadow-xs`
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-slate-900 dark:text-white flex items-center space-x-1.5">
                        <span className="text-base">{option.icon}</span>
                        <span>{option.label}</span>
                      </span>
                      {active && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                      )}
                    </div>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-tight">
                      {option.description}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. MENTAL BATTERY SCORE & LANGUAGE STYLE LOGIC */}
          <div className="space-y-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 p-3.5 rounded-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-bold uppercase tracking-wider text-slate-600 dark:text-slate-300 flex items-center space-x-1.5">
                  <Battery className="w-3.5 h-3.5 text-emerald-500" />
                  <span>2. Mental Battery Score:</span>
                </label>
                <span className="text-xs font-mono font-black text-indigo-600 dark:text-indigo-400">
                  {mentalBattery}% Focus Energy
                </span>
              </div>

              {/* Mental Battery Range Slider */}
              <input
                type="range"
                min="10"
                max="100"
                step="5"
                value={mentalBattery}
                onChange={(e) => setMentalBattery(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-600 my-2"
              />

              {/* Quick Presets */}
              <div className="flex items-center justify-between gap-1 text-[10px] font-bold mt-1">
                <button
                  onClick={() => setMentalBattery(30)}
                  className={`px-2 py-1 rounded-lg border transition-all ${
                    mentalBattery <= 40
                      ? 'bg-rose-500 text-white border-rose-600 shadow-xs'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  🪫 Low Focus (30%)
                </button>
                <button
                  onClick={() => setMentalBattery(65)}
                  className={`px-2 py-1 rounded-lg border transition-all ${
                    mentalBattery > 40 && mentalBattery < 80
                      ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  🔋 Balanced (65%)
                </button>
                <button
                  onClick={() => setMentalBattery(90)}
                  className={`px-2 py-1 rounded-lg border transition-all ${
                    mentalBattery >= 80
                      ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  ⚡ Deep Focus (90%)
                </button>
              </div>
            </div>

            {/* Dynamic Strategy Explanation */}
            <div className="mt-2 p-2.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/80 text-[11px] space-y-1">
              <div className="flex items-center space-x-1.5 font-bold text-indigo-600 dark:text-indigo-400">
                <Zap className="w-3.5 h-3.5" />
                <span>Language Style Strategy: {batteryMode.strategy}</span>
              </div>
              <p className="text-slate-600 dark:text-slate-400 leading-snug">
                {batteryMode.description}
              </p>
            </div>
          </div>
        </div>

        {/* Apply Persona & Regenerate Callout */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-xs">
          <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>
              System Instruction: Adopt <strong>{selectedToneOption.label}</strong> persona with <strong>{batteryMode.strategy}</strong> ({mentalBattery}% Battery).
            </span>
          </div>
          <button
            onClick={() => handleFetchPresentation()}
            disabled={loading}
            className="w-full sm:w-auto px-4 py-2 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-amber-400 font-bold text-[11px] rounded-xl border border-slate-700 dark:border-slate-600 shadow-xs transition-all flex items-center justify-center space-x-1.5 shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Update & Regenerate Presentation</span>
          </button>
        </div>
      </div>

      {/* MAIN ROBOT TEACHER PRESENTATION STAGE (CENTER DISPLAY) */}
      <div className="bg-slate-950 border-4 border-slate-900 rounded-3xl p-4 sm:p-6 shadow-2xl text-white relative overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-32 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Classroom Header Bar */}
        <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-3 mb-4 gap-2 relative z-10">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
            <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-widest">
              LIVE ROBO-TEACHER CLASSROOM
            </span>
          </div>

          {/* Active Persona Real-Time Visual Indicator */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-950/90 text-indigo-200 border border-indigo-700/80 flex items-center space-x-1.5 shadow-xs">
              <span>{selectedToneOption.icon}</span>
              <span>Active Persona: <strong className="text-indigo-100">{selectedToneOption.label}</strong></span>
            </span>
            <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold border flex items-center space-x-1.5 ${batteryMode.badgeBg}`}>
              <span>{batteryMode.icon}</span>
              <span>{mentalBattery}% Focus Energy</span>
            </span>
            {presentation && (
              <span className="px-2 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300 font-mono text-[11px]">
                Slide {currentSlideIndex + 1} / {presentation.slides.length + 1}
              </span>
            )}
          </div>
        </div>

        {/* Center Stage Layout: Left AI Robot Avatar | Right Blackboard Presentation Screen */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center relative z-10 min-h-[380px]">
          
          {/* AI ROBOT PRESENTER (The Robot Mascot) */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center text-center">
            <div className="relative group w-full flex flex-col items-center">
              {/* Robot Glow Ring */}
              <div className={`absolute inset-0 rounded-full blur-2xl opacity-60 transition-all ${
                isSpeaking ? 'bg-gradient-to-r from-emerald-400 via-teal-500 to-indigo-500 animate-pulse' : 'bg-emerald-500/20'
              }`}></div>

              {/* Animated Vector Robot Character with Real Arms, Visor & Body Motion */}
              <AnimatedRobotCharacter
                isSpeaking={isSpeaking}
                currentPose={robotPose !== 'idle' ? robotPose : undefined}
                explicitEmotion={currentSlide?.emotion}
                speechText={currentSlide?.robotTeacherDialogue}
                onPoseChange={(newPose) => setRobotPose(newPose)}
              />

              {/* Status Badge & Pose Picker */}
              <div className="mt-2 px-3.5 py-1 rounded-full bg-slate-900 border border-emerald-400/80 text-[10px] font-mono font-bold text-emerald-400 flex items-center space-x-1.5 shadow-xl shrink-0 whitespace-nowrap z-10">
                <span className={`w-2 h-2 rounded-full ${isSpeaking ? 'bg-emerald-400 animate-bounce' : 'bg-slate-500'}`} />
                <span>{isSpeaking ? `TEACHING (${robotPose.toUpperCase()})` : `ROBO-TEACHER READY (${robotPose.toUpperCase()})`}</span>
              </div>

              {/* Expressive Robot Emotion Pose Manual Controls */}
              <div className="mt-3 w-full z-10">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 text-center mb-1">
                  🎭 Expressive Teacher Emotion Poses:
                </p>
                <div className="flex flex-wrap items-center justify-center gap-1">
                  {[
                    { pose: 'excitement', label: '🤩 Excited' },
                    { pose: 'confusion', label: '🤔 Curious' },
                    { pose: 'empathy', label: '❤️ Empathetic' },
                    { pose: 'pointing', label: '👉 Pointing' },
                    { pose: 'explaining', label: '💬 Explaining' },
                    { pose: 'celebrating', label: '🎉 Celebrating' },
                    { pose: 'thinking', label: '🧠 Thinking' },
                    { pose: 'waving', label: '👋 Waving' }
                  ].map((item) => (
                    <button
                      key={item.pose}
                      onClick={() => setRobotPose(item.pose as RobotPose)}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-all ${
                        robotPose === item.pose 
                          ? 'bg-amber-400 text-slate-950 font-black shadow-md scale-105' 
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Robo Speech Controls */}
            <div className="mt-4 flex items-center space-x-2 z-10">
              <button
                onClick={() => {
                  if (isSpeaking) {
                    stopSpeech();
                  } else if (currentSlide) {
                    speakText(currentSlide.robotTeacherDialogue);
                  }
                }}
                className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-2 transition-all ${
                  isSpeaking 
                    ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-lg'
                    : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 shadow-md font-extrabold'
                }`}
              >
                {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                <span>{isSpeaking ? 'Mute Teacher' : 'Listen to Voice'}</span>
              </button>
            </div>
          </div>

          {/* BLACKBOARD / PRESENTATION SCREEN */}
          <div className="lg:col-span-8 bg-slate-900 border-2 border-slate-800 rounded-2xl p-5 sm:p-6 shadow-inner flex flex-col justify-between min-h-[360px]">
            {loading ? (
              <div className="flex-1 flex flex-col items-center justify-center py-12 text-center">
                <Loader2 className="w-10 h-10 text-emerald-400 animate-spin mb-3" />
                <p className="text-sm font-bold text-slate-200">Robo-Teacher is preparing your presentation board...</p>
                <p className="text-xs text-slate-400">Crafting visual mnemonics and simple steps under {selectedToneOption.label} mode</p>
              </div>
            ) : presentation ? (
              <>
                {/* SLIDE CONTENT */}
                {currentSlideIndex < presentation.slides.length && currentSlide ? (
                  <div className="space-y-4 animate-in fade-in duration-300" aria-live="polite" aria-atomic="true">
                    {/* Screen Reader Optimized Text Summary (When Mode is Active) */}
                    {prefs?.screenReaderOptimization && (
                      <div className="p-3 rounded-xl bg-emerald-900/80 border border-emerald-500 text-emerald-100 text-xs font-mono mb-2">
                        <strong className="block text-emerald-300 font-bold uppercase tracking-wider mb-1">
                          [Screen Reader Optimized Slide Transcript]
                        </strong>
                        <p>
                          Slide {currentSlide.slideNumber}: {currentSlide.title}. Teacher statement: "{currentSlide.robotTeacherDialogue}". Main key takeaway: {currentSlide.keyTakeaway}.
                        </p>
                      </div>
                    )}

                    {/* Robot Teacher Dialogue Bubble */}
                    <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800/80 text-emerald-200 text-xs font-medium leading-relaxed flex items-start space-x-2">
                      <span className="text-base" aria-hidden="true">🤖</span>
                      <div>
                        <strong className="block text-[10px] uppercase font-bold text-emerald-400 mb-0.5">
                          Robo-Teacher Says ({selectedToneOption.label} Persona):
                        </strong>
                        <p className="italic">"{currentSlide.robotTeacherDialogue}"</p>
                      </div>
                    </div>

                    {/* Slide Title */}
                    <h3 className="text-base sm:text-lg font-extrabold text-white leading-tight flex items-center gap-2">
                      <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-xs shrink-0">
                        {currentSlide.slideNumber}
                      </span>
                      <span>{currentSlide.title}</span>
                    </h3>

                    {/* Bullet Points */}
                    <ul className="space-y-2">
                      {currentSlide.bulletPoints.map((bullet, idx) => (
                        <li key={idx} className="text-xs sm:text-sm text-slate-200 flex items-start space-x-2 leading-relaxed">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{bullet}</span>
                        </li>
                      ))}
                    </ul>

                    {/* Visual Diagram Box */}
                    {currentSlide.visualDiagramHint && (
                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-indigo-300 flex items-center space-x-2">
                        <span className="text-amber-400 shrink-0">📊 Board Diagram:</span>
                        <span>{currentSlide.visualDiagramHint}</span>
                      </div>
                    )}

                    {/* Key Takeaway Note */}
                    <div className="p-2.5 rounded-lg bg-indigo-950/40 border border-indigo-800/50 text-[11px] text-indigo-200 flex items-center space-x-2">
                      <Lightbulb className="w-4 h-4 text-amber-300 shrink-0" />
                      <span><strong>Key Memory Note:</strong> {currentSlide.keyTakeaway}</span>
                    </div>
                  </div>
                ) : (
                  /* FINAL SLIDE: CLASSROOM QUIZ */
                  <div className="space-y-4 animate-in fade-in duration-300">
                    <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-800/60 text-amber-200 text-xs flex items-center space-x-2">
                      <HelpCircle className="w-4 h-4 text-amber-400 shrink-0" />
                      <span><strong>Classroom Checkpoint:</strong> Let's see how much you remembered!</span>
                    </div>

                    <h3 className="text-sm sm:text-base font-bold text-white">
                      Q: {presentation.classroomQuiz.question}
                    </h3>

                    <div className="space-y-2">
                      {presentation.classroomQuiz.options.map((opt, idx) => {
                        const isCorrect = idx === presentation.classroomQuiz.correctIndex;
                        const isSelected = selectedQuizOption === idx;

                        let btnClass = "w-full text-left p-3 rounded-xl text-xs font-medium border transition-all ";
                        if (showQuizResult) {
                          if (isCorrect) {
                            btnClass += "bg-emerald-950 border-emerald-500 text-emerald-200 font-bold";
                          } else if (isSelected) {
                            btnClass += "bg-rose-950 border-rose-500 text-rose-200";
                          } else {
                            btnClass += "bg-slate-950 border-slate-800 text-slate-400 opacity-60";
                          }
                        } else {
                          btnClass += "bg-slate-950 hover:bg-slate-800 border-slate-800 text-slate-200";
                        }

                        return (
                          <button
                            key={idx}
                            onClick={() => {
                              setSelectedQuizOption(idx);
                              setShowQuizResult(true);
                              if (isCorrect) {
                                speakText("Excellent job! That is completely correct!");
                              } else {
                                speakText("Good attempt! Let's review the correct answer together.");
                              }
                            }}
                            className={btnClass}
                          >
                            <span className="font-bold mr-2">{String.fromCharCode(65 + idx)}.</span>
                            <span>{opt}</span>
                          </button>
                        );
                      })}
                    </div>

                    {showQuizResult && (
                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
                        <strong className="text-emerald-400 block mb-1">Robo-Teacher Feedback:</strong>
                        <p>{presentation.classroomQuiz.teacherFeedback}</p>
                      </div>
                    )}
                  </div>
                )}

                {/* SLIDE NAVIGATION CONTROLS */}
                <div className="flex items-center justify-between border-t border-slate-800 pt-4 mt-6">
                  <button
                    onClick={handlePrevSlide}
                    disabled={currentSlideIndex === 0}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 disabled:opacity-30 flex items-center space-x-1"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Previous</span>
                  </button>

                  <div className="text-[11px] text-slate-400 font-mono">
                    {currentSlideIndex < presentation.slides.length ? (
                      <span>Slide {currentSlideIndex + 1} of {presentation.slides.length}</span>
                    ) : (
                      <span className="text-emerald-400 font-bold">Quiz Checkpoint</span>
                    )}
                  </div>

                  {currentSlideIndex < presentation.slides.length ? (
                    <button
                      onClick={handleNextSlide}
                      className="px-4 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-xs font-bold text-slate-950 flex items-center space-x-1 shadow-md"
                    >
                      <span>Next Slide</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setCurrentSlideIndex(0);
                        setShowQuizResult(false);
                        setSelectedQuizOption(null);
                      }}
                      className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-xs font-bold text-white flex items-center space-x-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Replay Lesson</span>
                    </button>
                  )}
                </div>
              </>
            ) : null}
          </div>

        </div>

        {/* Stress Relief Tip Footer */}
        {presentation && (
          <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2 relative z-10">
            <span className="flex items-center space-x-1 text-teal-400">
              <Sparkles className="w-3.5 h-3.5" />
              <span><strong>Mindset Tip:</strong> {presentation.stressReliefTip}</span>
            </span>
            <span className="text-[11px] text-slate-500">
              Robo-Teacher AI Presentation Engine ({selectedToneOption.label} Persona)
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
