import React, { useState } from 'react';
import { 
  Calendar, 
  Sparkles, 
  Loader2, 
  CheckSquare, 
  Lightbulb, 
  BookOpen, 
  Brain, 
  Layers, 
  Eye, 
  Volume2, 
  Activity, 
  FileText,
  Target
} from 'lucide-react';
import { StudyPlan } from '../types';

export const StudyPlanGenerator: React.FC = () => {
  const [subject, setSubject] = useState('Organic Chemistry');
  const [topic, setTopic] = useState('Reaction Mechanisms & Functional Groups');
  const [learningStyle, setLearningStyle] = useState<'Visual' | 'Auditory' | 'Kinesthetic' | 'Reading'>('Visual');
  const [daysAvailable, setDaysAvailable] = useState(5);
  const [dailyMinutes, setDailyMinutes] = useState(30);
  const [loading, setLoading] = useState(false);
  const [plan, setPlan] = useState<StudyPlan | null>(null);

  const handleGenerate = async () => {
    if (!subject.trim() || !topic.trim()) {
      alert("Please enter both Subject Name and Topic.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/ai/study-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject,
          topic,
          learningStyle,
          daysAvailable,
          dailyMinutes
        })
      });

      if (!res.ok) {
        throw new Error(`HTTP Error ${res.status}`);
      }

      const data = await res.json();
      if (data.plan) {
        setPlan(data.plan);
      } else {
        throw new Error("Invalid plan object returned.");
      }
    } catch (e) {
      console.warn("Using offline fallback study plan generator:", e);
      const fallbackPlan: StudyPlan = {
        planTitle: `${subject}: ${topic} Personal Roadmap`,
        learningStyle: learningStyle,
        learningStyleAdvice: `Leverage your ${learningStyle} strengths by utilizing visual mind maps, concise bullet summaries, active recall, and spaced repetition.`,
        totalDays: daysAvailable,
        retentionTechniques: ["Visual Mind Mapping", "Active Recall Sprints", "Spaced Memory Checkpoints (24h & 72h)"],
        dailyModules: Array.from({ length: Math.min(daysAvailable, 7) }).map((_, idx) => ({
          day: idx + 1,
          focusGoal: `Mastering Phase ${idx + 1}: Key Fundamentals of ${topic}`,
          microTasks: [
            `1. Read a 2-sentence summary of ${topic} core concept`,
            `2. Create 3 visual flashcards or sketch a quick mind map node`,
            `3. Test yourself with 2 practice questions using active recall`
          ],
          breakActivity: "60-second deep breathing, stretch arms and rest your eyes",
          brainTip: "15-minute hyper-focused micro-sprints build deep memory retention without overwhelm!"
        }))
      };
      setPlan(fallbackPlan);
    } finally {
      setLoading(false);
    }
  };

  const sampleSubjects = [
    "Organic Chemistry",
    "Calculus & Algebra",
    "Physics & Mechanics",
    "World History",
    "Cell Biology",
    "Computer Science & Code"
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm space-y-6">
      
      {/* Header */}
      <div className="flex items-center space-x-3 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="p-3 bg-indigo-100 dark:bg-indigo-950 rounded-xl text-indigo-600 dark:text-indigo-400">
          <Brain className="w-6 h-6" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            Personalized Learning Path & Retention Engine
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Tailored multi-step study plan designed specifically for your learning style to conquer tough subjects.
          </p>
        </div>
      </div>

      {/* Form Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Subject Input */}
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Subject Struggling With
          </label>
          <input
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="e.g. Organic Chemistry, Physics, Algebra..."
            className="w-full text-xs p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-medium"
          />
          {/* Preset Buttons */}
          <div className="flex flex-wrap gap-1 mt-2">
            {sampleSubjects.map((s, idx) => (
              <button
                key={idx}
                onClick={() => setSubject(s)}
                className="text-[10px] px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-indigo-600"
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Exam Topic / Chapter */}
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Specific Topic or Chapter
          </label>
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g. Reaction Mechanisms, Derivatives, French Revolution..."
            className="w-full text-xs p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-medium"
          />
        </div>

        {/* Learning Style Selector */}
        <div className="sm:col-span-2">
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
            Identify Student's Primary Learning Style
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => setLearningStyle('Visual')}
              className={`p-3 rounded-xl border text-left flex flex-col items-center justify-center space-y-1 transition-all ${
                learningStyle === 'Visual'
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              <Eye className="w-5 h-5" />
              <span className="text-xs font-bold">Visual-Spatial</span>
              <span className="text-[10px] opacity-80">Mind maps & diagrams</span>
            </button>

            <button
              type="button"
              onClick={() => setLearningStyle('Auditory')}
              className={`p-3 rounded-xl border text-left flex flex-col items-center justify-center space-y-1 transition-all ${
                learningStyle === 'Auditory'
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              <Volume2 className="w-5 h-5" />
              <span className="text-xs font-bold">Auditory-Verbal</span>
              <span className="text-[10px] opacity-80">Rhymes & TTS audio</span>
            </button>

            <button
              type="button"
              onClick={() => setLearningStyle('Kinesthetic')}
              className={`p-3 rounded-xl border text-left flex flex-col items-center justify-center space-y-1 transition-all ${
                learningStyle === 'Kinesthetic'
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              <Activity className="w-5 h-5" />
              <span className="text-xs font-bold">Kinesthetic</span>
              <span className="text-[10px] opacity-80">Hands-on flashcards</span>
            </button>

            <button
              type="button"
              onClick={() => setLearningStyle('Reading')}
              className={`p-3 rounded-xl border text-left flex flex-col items-center justify-center space-y-1 transition-all ${
                learningStyle === 'Reading'
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              <FileText className="w-5 h-5" />
              <span className="text-xs font-bold">Reading/Writing</span>
              <span className="text-[10px] opacity-80">Bionic text & lists</span>
            </button>
          </div>
        </div>

        {/* Days & Minutes */}
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Days Until Exam / Target ({daysAvailable} Days)
          </label>
          <input
            type="range"
            min={1}
            max={14}
            value={daysAvailable}
            onChange={(e) => setDaysAvailable(Number(e.target.value))}
            className="w-full accent-indigo-600"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Daily Study Limit ({dailyMinutes} Mins)
          </label>
          <input
            type="range"
            min={15}
            max={120}
            step={15}
            value={dailyMinutes}
            onChange={(e) => setDailyMinutes(Number(e.target.value))}
            className="w-full accent-indigo-600"
          />
        </div>
      </div>

      <button
        onClick={handleGenerate}
        disabled={loading}
        className="w-full py-3.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Building Personalized Learning Path...</span>
          </>
        ) : (
          <>
            <Sparkles className="w-4 h-4" />
            <span>Generate Personalized Learning Path for {subject}</span>
          </>
        )}
      </button>

      {/* Generated Plan Output */}
      {plan && (
        <div className="space-y-6 border-t border-slate-200 dark:border-slate-800 pt-6 animate-in fade-in">
          {/* Header Card */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-500/10 via-teal-500/10 to-amber-500/10 border border-indigo-200 dark:border-indigo-800">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                {plan.planTitle} ({plan.totalDays} Days Roadmap)
              </h3>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full bg-indigo-600 text-white shadow-xs">
                {plan.learningStyle || learningStyle} Style
              </span>
            </div>

            {plan.learningStyleAdvice && (
              <p className="text-xs text-slate-700 dark:text-slate-300 mb-3">
                <strong>Learning Advice:</strong> {plan.learningStyleAdvice}
              </p>
            )}

            {plan.retentionTechniques && plan.retentionTechniques.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-indigo-200/50 dark:border-indigo-800/50">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Retention Tactics:</span>
                {plan.retentionTechniques.map((tech, idx) => (
                  <span key={idx} className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300">
                    {tech}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Daily Multi-Step Modules */}
          <div className="space-y-4">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-400">
              Multi-Step Daily Milestones
            </h4>

            {plan.dailyModules.map((m) => (
              <div
                key={m.day}
                className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/60 shadow-xs"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="font-extrabold text-xs text-indigo-600 dark:text-indigo-400 uppercase tracking-wider flex items-center gap-2">
                    <Target className="w-4 h-4 text-indigo-500" />
                    <span>Day {m.day}: {m.focusGoal}</span>
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">Step {m.day}</span>
                </div>

                <ul className="space-y-2 mb-3">
                  {m.microTasks.map((task, i) => (
                    <li key={i} className="text-xs text-slate-700 dark:text-slate-300 flex items-start space-x-2">
                      <CheckSquare className="w-3.5 h-3.5 text-teal-500 shrink-0 mt-0.5" />
                      <span>{task}</span>
                    </li>
                  ))}
                </ul>

                <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] pt-2 border-t border-slate-200/60 dark:border-slate-700/60 text-slate-500 dark:text-slate-400">
                  <span>☕ Brain Break: {m.breakActivity}</span>
                  <span className="italic font-medium text-amber-600 dark:text-amber-400">💡 Tip: {m.brainTip}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
