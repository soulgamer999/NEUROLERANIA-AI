import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LearningCondition, DisplayTheme } from '../types';

interface DynamicStudyBackgroundProps {
  condition: LearningCondition;
  theme: DisplayTheme;
}

export const DynamicStudyBackground: React.FC<DynamicStudyBackgroundProps> = ({ condition, theme }) => {
  const isDark = theme === 'dark-slate' || theme === 'high-contrast';
  const isWarm = theme === 'dyslexia-warm';

  // Base opacity adjustment for readability
  const opacityMultiplier = isDark ? 0.35 : isWarm ? 0.25 : 0.2;

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none" aria-hidden="true">
      <AnimatePresence mode="wait">
        {/* DYSCALCULIA: Organized Spatial Grid & Coordinate Metric Matrix */}
        {condition === 'dyscalculia' && (
          <motion.div
            key="dyscalculia-bg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0"
          >
            {/* Metric SVG Grid */}
            <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="spatialGridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path
                    d="M 40 0 L 0 0 0 40"
                    fill="none"
                    stroke={isDark ? '#38bdf8' : '#0284c7'}
                    strokeWidth="0.75"
                    strokeOpacity={isDark ? 0.15 : 0.1}
                  />
                  <circle cx="0" cy="0" r="1.5" fill={isDark ? '#38bdf8' : '#0284c7'} fillOpacity={0.3} />
                </pattern>
                <pattern id="majorGridPattern" width="200" height="200" patternUnits="userSpaceOnUse">
                  <rect width="200" height="200" fill="url(#spatialGridPattern)" />
                  <path
                    d="M 200 0 L 0 0 0 200"
                    fill="none"
                    stroke={isDark ? '#818cf8' : '#6366f1'}
                    strokeWidth="1.5"
                    strokeOpacity={isDark ? 0.25 : 0.18}
                  />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#majorGridPattern)" />
            </svg>

            {/* Floating Metric Axes Pulse */}
            <motion.div
              animate={{
                scale: [1, 1.05, 1],
                opacity: [opacityMultiplier * 0.8, opacityMultiplier * 1.2, opacityMultiplier * 0.8],
              }}
              transition={{ repeat: Infinity, duration: 6, ease: 'easeInOut' }}
              className="absolute top-1/4 left-10 w-72 h-72 rounded-full border border-indigo-500/20 dark:border-indigo-400/30 flex items-center justify-center"
            >
              <div className="w-48 h-48 rounded-full border border-dashed border-sky-500/20 dark:border-sky-400/30" />
            </motion.div>

            {/* Subitizing Number Grouping Dots */}
            <div className="absolute top-1/3 right-12 flex gap-3">
              {[0, 1, 2, 3, 4].map((i) => (
                <motion.div
                  key={i}
                  animate={{
                    y: [0, -6, 0],
                    opacity: [0.2, 0.5, 0.2],
                  }}
                  transition={{ repeat: Infinity, duration: 3, delay: i * 0.4, ease: 'easeInOut' }}
                  className="w-3 h-3 rounded-full bg-indigo-500/40 dark:bg-indigo-400/50"
                />
              ))}
            </div>
          </motion.div>
        )}

        {/* DYSLEXIA: High-Contrast Reading Ruler Guides & Balanced Edge Frame */}
        {condition === 'dyslexia' && (
          <motion.div
            key="dyslexia-bg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0"
          >
            {/* Horizontal Reading Line Guide Overlay */}
            <div className="absolute inset-0 flex flex-col justify-between py-12 pointer-events-none opacity-20 dark:opacity-15">
              {Array.from({ length: 12 }).map((_, idx) => (
                <div
                  key={idx}
                  className={`w-full h-px ${
                    isWarm ? 'bg-amber-900/40' : isDark ? 'bg-amber-300/30' : 'bg-slate-400/40'
                  }`}
                />
              ))}
            </div>

            {/* High Contrast Reading Focus Channel */}
            <motion.div
              animate={{
                y: ['0%', '100%', '0%'],
              }}
              transition={{ repeat: Infinity, duration: 18, ease: 'easeInOut' }}
              className={`w-full h-24 border-y-2 pointer-events-none ${
                isWarm
                  ? 'border-amber-600/20 bg-amber-200/10'
                  : isDark
                  ? 'border-amber-400/20 bg-amber-400/5'
                  : 'border-indigo-400/20 bg-indigo-50/20'
              }`}
            />
          </motion.div>
        )}

        {/* DYSGRAPHIA: Lined Notebook Ruling & Writing Margin Guides */}
        {condition === 'dysgraphia' && (
          <motion.div
            key="dysgraphia-bg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0"
          >
            {/* Lined Paper SVG */}
            <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="notebookLines" width="100%" height="32" patternUnits="userSpaceOnUse">
                  <line
                    x1="0"
                    y1="31"
                    x2="100%"
                    y2="31"
                    stroke={isDark ? '#a855f7' : '#9333ea'}
                    strokeWidth="1"
                    strokeOpacity={isDark ? 0.2 : 0.12}
                  />
                  <line
                    x1="0"
                    y1="16"
                    x2="100%"
                    y2="16"
                    stroke={isDark ? '#c084fc' : '#a855f7'}
                    strokeWidth="0.5"
                    strokeDasharray="4 4"
                    strokeOpacity={isDark ? 0.15 : 0.08}
                  />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#notebookLines)" />
              {/* Vertical Margin Line */}
              <line
                x1="60"
                y1="0"
                x2="60"
                y2="100%"
                stroke="#f43f5e"
                strokeWidth="1.5"
                strokeOpacity={isDark ? 0.35 : 0.25}
              />
            </svg>

            {/* Letter Alignment Baseline Pulse */}
            <motion.div
              animate={{
                opacity: [0.15, 0.35, 0.15],
              }}
              transition={{ repeat: Infinity, duration: 4, ease: 'easeInOut' }}
              className="absolute left-20 top-1/2 -translate-y-1/2 flex flex-col gap-8"
            >
              <div className="text-[10px] font-mono tracking-widest text-purple-400 dark:text-purple-300 uppercase">
                ├── Letter Height Baseline ──┤
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* AUDITORY PROCESSING DISORDER (APD): Soundwave Equalizer Cadence */}
        {condition === 'apd' && (
          <motion.div
            key="apd-bg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0"
          >
            {/* Flowing Wave Lines */}
            <svg className="w-full h-full opacity-30 dark:opacity-20" xmlns="http://www.w3.org/2000/svg">
              <motion.path
                d="M 0 300 Q 350 200 700 300 T 1400 300 T 2100 300"
                fill="none"
                stroke={isDark ? '#22d3ee' : '#0891b2'}
                strokeWidth="2"
                animate={{
                  d: [
                    'M 0 300 Q 350 200 700 300 T 1400 300 T 2100 300',
                    'M 0 300 Q 350 400 700 300 T 1400 300 T 2100 300',
                    'M 0 300 Q 350 200 700 300 T 1400 300 T 2100 300',
                  ],
                }}
                transition={{ repeat: Infinity, duration: 8, ease: 'easeInOut' }}
              />
              <motion.path
                d="M 0 500 Q 400 600 800 500 T 1600 500"
                fill="none"
                stroke={isDark ? '#818cf8' : '#4f46e5'}
                strokeWidth="1.5"
                animate={{
                  d: [
                    'M 0 500 Q 400 600 800 500 T 1600 500',
                    'M 0 500 Q 400 400 800 500 T 1600 500',
                    'M 0 500 Q 400 600 800 500 T 1600 500',
                  ],
                }}
                transition={{ repeat: Infinity, duration: 10, ease: 'easeInOut', delay: 1 }}
              />
            </svg>

            {/* Bottom Ambient Equalizer Frequency Pulse */}
            <div className="absolute bottom-0 left-0 right-0 h-16 flex items-end justify-around px-8 gap-1 opacity-20 dark:opacity-15">
              {Array.from({ length: 32 }).map((_, i) => (
                <motion.div
                  key={i}
                  animate={{
                    height: ['10%', `${20 + ((i * 7) % 70)}%`, '10%'],
                  }}
                  transition={{
                    repeat: Infinity,
                    duration: 1.8 + (i % 5) * 0.3,
                    ease: 'easeInOut',
                  }}
                  className="w-1.5 rounded-t-sm bg-cyan-500 dark:bg-cyan-400"
                />
              ))}
            </div>
          </motion.div>
        )}

        {/* DYSPRAXIA: Spacious Tactile Anchor Nodes & Navigation Markers */}
        {condition === 'dyspraxia' && (
          <motion.div
            key="dyspraxia-bg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0"
          >
            {/* Corner Tactile Alignment Anchors */}
            <div className="absolute top-6 left-6 w-16 h-16 border-t-2 border-l-2 border-emerald-500/30 dark:border-emerald-400/40 rounded-tl-xl" />
            <div className="absolute top-6 right-6 w-16 h-16 border-t-2 border-r-2 border-emerald-500/30 dark:border-emerald-400/40 rounded-tr-xl" />
            <div className="absolute bottom-6 left-6 w-16 h-16 border-b-2 border-l-2 border-emerald-500/30 dark:border-emerald-400/40 rounded-bl-xl" />
            <div className="absolute bottom-6 right-6 w-16 h-16 border-b-2 border-r-2 border-emerald-500/30 dark:border-emerald-400/40 rounded-br-xl" />

            {/* Soft Breathing Target Center Node */}
            <motion.div
              animate={{
                scale: [1, 1.15, 1],
                opacity: [0.08, 0.2, 0.08],
              }}
              transition={{ repeat: Infinity, duration: 5, ease: 'easeInOut' }}
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full border-4 border-emerald-500 dark:border-emerald-400"
            />
          </motion.div>
        )}

        {/* NVLD & GENERAL / ADHD: Calming Ambient Focus Orbits */}
        {(condition === 'nvld' || !['dyscalculia', 'dyslexia', 'dysgraphia', 'apd', 'dyspraxia'].includes(condition)) && (
          <motion.div
            key="nvld-adhd-bg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0"
          >
            {/* Calming Glowing Mesh Orbits */}
            <motion.div
              animate={{
                x: [0, 40, -20, 0],
                y: [0, -30, 30, 0],
                scale: [1, 1.1, 0.95, 1],
              }}
              transition={{ repeat: Infinity, duration: 16, ease: 'easeInOut' }}
              className={`absolute top-10 right-10 w-96 h-96 rounded-full blur-3xl opacity-20 dark:opacity-15 ${
                isWarm ? 'bg-amber-300' : 'bg-emerald-400'
              }`}
            />
            <motion.div
              animate={{
                x: [0, -30, 30, 0],
                y: [0, 40, -20, 0],
                scale: [1, 0.9, 1.08, 1],
              }}
              transition={{ repeat: Infinity, duration: 20, ease: 'easeInOut', delay: 2 }}
              className={`absolute bottom-10 left-10 w-[30rem] h-[30rem] rounded-full blur-3xl opacity-20 dark:opacity-15 ${
                isDark ? 'bg-indigo-600' : 'bg-sky-300'
              }`}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
