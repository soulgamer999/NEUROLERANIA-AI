import React, { useState } from 'react';
import { 
  GraduationCap, 
  Users, 
  UserPlus, 
  Trash2, 
  Search, 
  Sparkles, 
  Brain, 
  BookOpen, 
  Calculator, 
  PenTool, 
  Captions, 
  MousePointer, 
  Eye, 
  ShieldCheck, 
  LogIn, 
  Activity, 
  BarChart3, 
  X, 
  CheckCircle2, 
  FileText, 
  Layers, 
  Zap, 
  Battery, 
  MessageSquare,
  Award
} from 'lucide-react';
import { StudentProfileData, TeacherProfileData, LearningCondition, UserPreferences } from '../types';
import { CONDITION_PROFILES } from './NeuroConditionSelector';

interface TeacherAdminDashboardProps {
  teacher: TeacherProfileData;
  students: StudentProfileData[];
  onAddStudent: (newStudent: Omit<StudentProfileData, 'id' | 'createdAt'>) => void;
  onDeleteStudent: (studentId: string) => void;
  onSelectStudentProfile: (studentId: string) => void;
}

export const TeacherAdminDashboard: React.FC<TeacherAdminDashboardProps> = ({
  teacher,
  students,
  onAddStudent,
  onDeleteStudent,
  onSelectStudentProfile
}) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [inspectStudent, setInspectStudent] = useState<StudentProfileData | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [conditionFilter, setConditionFilter] = useState<string>('all');

  // Form State for Adding New Student
  const [newName, setNewName] = useState('');
  const [newGrade, setNewGrade] = useState('Grade 5');
  const [newCondition, setNewCondition] = useState<LearningCondition>('dyslexia');
  const [newBattery, setNewBattery] = useState<number>(85);
  const [newNotes, setNewNotes] = useState('');

  const handleCreateStudentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    // Build condition-tailored preferences for the student
    const defaultPrefs: UserPreferences = {
      activeCondition: newCondition,
      dyslexicFont: newCondition === 'dyslexia',
      bionicHighlight: true,
      fontSize: 'normal',
      letterSpacing: 'wide',
      lineHeight: 'relaxed',
      theme: 'light',
      speechSpeed: newCondition === 'apd' ? 0.75 : 1.0,
      speechVoice: '',
      soundEffectVolume: 0.15,
      mathVisualizerEnabled: true,
      voiceTypingAssistant: newCondition === 'dysgraphia',
      audioClosedCaptions: newCondition === 'apd',
      largeTouchTargets: newCondition === 'dyspraxia',
      explicitTextLabels: newCondition === 'nvld',
      screenReaderOptimization: false
    };

    onAddStudent({
      name: newName.trim(),
      role: 'student',
      gradeLevel: newGrade,
      primaryCondition: newCondition,
      avatarIcon: newCondition === 'dyslexia' ? '📚' : newCondition === 'dyscalculia' ? '🧮' : newCondition === 'dysgraphia' ? '✍️' : newCondition === 'apd' ? '🎧' : newCondition === 'dyspraxia' ? '🎯' : '👁️',
      avatarBg: 'bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-200',
      notes: newNotes,
      prefs: defaultPrefs,
      savedFlashcards: [
        {
          id: 'card-1',
          question: `Sample Question for ${newName}`,
          answer: `Key foundational answer for ${newCondition} learning style`,
          hint: 'Remember to chunk concepts into visual steps'
        }
      ],
      aiReactions: [
        {
          id: 'rx-1',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          topic: 'Introductory Welcome Lesson',
          persona: 'Encouraging',
          userPromptOrQuestion: `Hello Robo-Teacher, I am ready to start learning ${newGrade} topics.`,
          aiResponseSnippet: `Welcome aboard ${newName}! I have configured my teaching style specifically for your ${newCondition} learning profile.`,
          detectedEmotion: 'Optimistic & Focused'
        }
      ],
      quizScores: [
        {
          id: 'qs-1',
          topic: 'Baseline Diagnostic',
          scorePct: 85,
          date: new Date().toLocaleDateString()
        }
      ],
      mentalBatteryPct: newBattery
    });

    // Reset Form
    setNewName('');
    setNewNotes('');
    setIsAddModalOpen(false);
  };

  const filteredStudents = students.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || s.gradeLevel.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCondition = conditionFilter === 'all' || s.primaryCondition === conditionFilter;
    return matchesSearch && matchesCondition;
  });

  const totalStudents = students.length;
  const avgBattery = students.length > 0
    ? Math.round(students.reduce((acc, curr) => acc + curr.mentalBatteryPct, 0) / students.length)
    : 85;

  return (
    <div className="space-y-6">
      
      {/* TEACHER ADMIN HEADER BANNER */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 shadow-xl border border-indigo-900 relative overflow-hidden">
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-2xl shadow-lg shrink-0">
              🎓
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-400/20 text-amber-300 border border-amber-400/40">
                  Admin & Educator Control Center
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  Isolated Student Data
                </span>
              </div>
              <h2 className="text-xl font-black text-white mt-1">
                {teacher.name}
              </h2>
              <p className="text-xs text-indigo-200">
                Classroom Roster Manager • {teacher.schoolName} ({teacher.email})
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow-lg transition-all flex items-center space-x-2 active:scale-95"
            >
              <UserPlus className="w-4 h-4" />
              <span>Add New Student Profile</span>
            </button>
          </div>
        </div>

        {/* Overview Stats Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-indigo-900/80">
          <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/10">
            <p className="text-[10px] font-bold uppercase text-indigo-300">Total Enrolled Students</p>
            <p className="text-xl font-black text-white mt-0.5">{totalStudents}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/10">
            <p className="text-[10px] font-bold uppercase text-emerald-300">Class Focus Battery Avg</p>
            <p className="text-xl font-black text-emerald-400 mt-0.5">{avgBattery}%</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/10">
            <p className="text-[10px] font-bold uppercase text-amber-300">Neurodiverse Conditions</p>
            <p className="text-xl font-black text-amber-300 mt-0.5">6 Profiles</p>
          </div>
          <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/10">
            <p className="text-[10px] font-bold uppercase text-sky-300">Privacy & Data Isolation</p>
            <p className="text-xl font-black text-sky-300 mt-0.5">Strict (Separate)</p>
          </div>
        </div>
      </div>

      {/* FILTER & SEARCH TOOLBAR */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-2 flex-1 min-w-[240px]">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search student name or grade..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <span className="text-xs font-bold text-slate-500 dark:text-slate-400 hidden sm:inline">Filter Condition:</span>
          <select
            value={conditionFilter}
            onChange={(e) => setConditionFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 px-3 py-2 rounded-xl focus:outline-hidden"
          >
            <option value="all">All Neurodiverse Profiles</option>
            <option value="dyslexia">Dyslexia Support</option>
            <option value="dyscalculia">Dyscalculia Math</option>
            <option value="dysgraphia">Dysgraphia Scribe</option>
            <option value="apd">APD Captions</option>
            <option value="dyspraxia">Dyspraxia Motor</option>
            <option value="nvld">NVLD Spatial</option>
          </select>
        </div>
      </div>

      {/* STUDENT CLASS ROSTER GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredStudents.length === 0 ? (
          <div className="col-span-full bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-800 p-8 rounded-2xl text-center">
            <Users className="w-10 h-10 text-slate-400 mx-auto mb-2" />
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">No Student Profiles Found</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 mb-4">
              Click "Add New Student Profile" above to enroll your first student with tailored neurodiverse support!
            </p>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs"
            >
              Add Student
            </button>
          </div>
        ) : (
          filteredStudents.map((student) => {
            const condInfo = CONDITION_PROFILES.find(p => p.id === student.primaryCondition) || CONDITION_PROFILES[0];
            return (
              <div
                key={student.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-600 rounded-2xl p-5 shadow-xs transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Top Row: Avatar & Grade & Actions */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl font-bold border border-slate-200 dark:border-slate-700 shadow-xs ${student.avatarBg}`}>
                        {student.avatarIcon}
                      </div>
                      <div>
                        <h3 className="text-sm font-black text-slate-900 dark:text-white leading-tight">
                          {student.name}
                        </h3>
                        <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
                          {student.gradeLevel}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => onDeleteStudent(student.id)}
                      title={`Remove profile for ${student.name}`}
                      className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Primary Accommodation Badge */}
                  <div className="mb-3">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold border inline-flex items-center space-x-1 ${condInfo.badgeColor}`}>
                      <span>{condInfo.icon}</span>
                      <span>{condInfo.title}</span>
                    </span>
                  </div>

                  {/* Mental Battery Level Bar */}
                  <div className="space-y-1 mb-4 p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <div className="flex items-center justify-between text-[11px] font-bold">
                      <span className="text-slate-600 dark:text-slate-400 flex items-center space-x-1">
                        <Battery className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Mental Battery Focus</span>
                      </span>
                      <span className="text-indigo-600 dark:text-indigo-400 font-mono font-black">
                        {student.mentalBatteryPct}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          student.mentalBatteryPct <= 40
                            ? 'bg-rose-500'
                            : student.mentalBatteryPct >= 80
                            ? 'bg-emerald-500'
                            : 'bg-indigo-500'
                        }`}
                        style={{ width: `${student.mentalBatteryPct}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Student Stats Summary */}
                  <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-bold mb-4">
                    <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      <span className="block text-slate-400 text-[9px] uppercase font-bold">Deck Cards</span>
                      <span className="text-xs font-black text-indigo-600 dark:text-indigo-400">{student.savedFlashcards.length}</span>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      <span className="block text-slate-400 text-[9px] uppercase font-bold">Quiz Avg</span>
                      <span className="text-xs font-black text-emerald-600 dark:text-emerald-400">
                        {student.quizScores.length > 0 ? `${Math.round(student.quizScores.reduce((a,b) => a + b.scorePct, 0)/student.quizScores.length)}%` : 'N/A'}
                      </span>
                    </div>
                    <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      <span className="block text-slate-400 text-[9px] uppercase font-bold">AI Reactions</span>
                      <span className="text-xs font-black text-amber-600 dark:text-amber-400">{student.aiReactions.length}</span>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Buttons */}
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <button
                    onClick={() => setInspectStudent(student)}
                    className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs rounded-xl transition-all flex items-center justify-center space-x-1"
                  >
                    <Eye className="w-3.5 h-3.5 text-indigo-500" />
                    <span>Inspect Data</span>
                  </button>

                  <button
                    onClick={() => onSelectStudentProfile(student.id)}
                    className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center space-x-1 active:scale-95"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Log In</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* INSPECT STUDENT DATA & AI REACTIONS MODAL */}
      {inspectStudent && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-2xl w-full shadow-2xl space-y-5 my-8">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
              <div className="flex items-center space-x-3">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl font-bold ${inspectStudent.avatarBg}`}>
                  {inspectStudent.avatarIcon}
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white">
                    {inspectStudent.name} — Student Profile Insights
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {inspectStudent.gradeLevel} • Accommodation: <strong className="text-indigo-600 dark:text-indigo-400">{inspectStudent.primaryCondition.toUpperCase()}</strong>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setInspectStudent(null)}
                className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* AI Reactions & Interactions Log */}
            <div className="space-y-3">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center space-x-1.5">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Isolated AI Reactions & Tutor History ({inspectStudent.aiReactions.length}):</span>
              </h4>
              <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                {inspectStudent.aiReactions.map((rx) => (
                  <div key={rx.id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700/80 text-xs space-y-1">
                    <div className="flex items-center justify-between text-[10px] font-bold text-slate-500">
                      <span className="text-indigo-600 dark:text-indigo-400">Topic: {rx.topic}</span>
                      <span>{rx.timestamp} • Persona: {rx.persona}</span>
                    </div>
                    <p className="text-slate-700 dark:text-slate-300 font-medium">
                      <strong>Student Asked:</strong> "{rx.userPromptOrQuestion}"
                    </p>
                    <p className="text-emerald-700 dark:text-emerald-300 italic bg-emerald-50 dark:bg-emerald-950/40 p-2 rounded-lg border border-emerald-100 dark:border-emerald-900">
                      🤖 <strong>Robo-Teacher Reaction:</strong> "{rx.aiResponseSnippet}"
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Student Saved Flashcards */}
            <div className="space-y-3">
              <h4 className="text-xs font-black uppercase tracking-wider text-slate-800 dark:text-slate-200 flex items-center space-x-1.5">
                <BookOpen className="w-4 h-4 text-indigo-500" />
                <span>Saved Flashcard Decks ({inspectStudent.savedFlashcards.length}):</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                {inspectStudent.savedFlashcards.map((card) => (
                  <div key={card.id} className="p-2.5 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/50 border border-indigo-100 dark:border-indigo-900 text-xs">
                    <p className="font-bold text-slate-900 dark:text-white">Q: {card.question}</p>
                    <p className="text-slate-600 dark:text-slate-300 text-[11px] mt-0.5">A: {card.answer}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
              <span className="text-[11px] text-slate-500 italic">
                Data is securely partitioned and inaccessible to other students.
              </span>
              <button
                onClick={() => {
                  onSelectStudentProfile(inspectStudent.id);
                  setInspectStudent(null);
                }}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center space-x-1.5"
              >
                <LogIn className="w-4 h-4" />
                <span>Log In as {inspectStudent.name}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD NEW STUDENT PROFILE MODAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
          <form
            onSubmit={handleCreateStudentSubmit}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl space-y-4 my-8"
          >
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <UserPlus className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  Add New Class Student Profile
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Student Name */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Student Full Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Alex Rivera"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            {/* Grade Level */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Grade Level
              </label>
              <select
                value={newGrade}
                onChange={(e) => setNewGrade(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-hidden"
              >
                <option value="Grade 3">Grade 3</option>
                <option value="Grade 4">Grade 4</option>
                <option value="Grade 5">Grade 5</option>
                <option value="Grade 6">Grade 6</option>
                <option value="Grade 7">Grade 7</option>
                <option value="Grade 8">Grade 8</option>
                <option value="High School">High School</option>
              </select>
            </div>

            {/* Neurodiverse Primary Accommodation */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Primary Neurodiverse Learning Accommodation
              </label>
              <div className="grid grid-cols-2 gap-2">
                {CONDITION_PROFILES.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setNewCondition(p.id)}
                    className={`p-2.5 rounded-xl border text-left text-xs font-bold transition-all flex items-center space-x-2 ${
                      newCondition === p.id
                        ? `${p.borderActive} bg-indigo-50 dark:bg-indigo-950 text-indigo-900 dark:text-indigo-200`
                        : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800'
                    }`}
                  >
                    <span>{p.icon}</span>
                    <span className="truncate">{p.title}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Focus Battery Level */}
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-slate-700 dark:text-slate-300">Initial Mental Battery Focus Level:</span>
                <span className="text-indigo-600 dark:text-indigo-400">{newBattery}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                step="5"
                value={newBattery}
                onChange={(e) => setNewBattery(Number(e.target.value))}
                className="w-full accent-indigo-600"
              />
            </div>

            {/* IEP Notes */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Teacher Notes & IEP Focus Goals (Optional)
              </label>
              <textarea
                rows={2}
                placeholder="e.g. Focus on phonics chunking and 0.75x audio pacing..."
                value={newNotes}
                onChange={(e) => setNewNotes(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-hidden"
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold text-xs rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md"
              >
                Create Student Profile
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
