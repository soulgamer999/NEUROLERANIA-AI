import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export type RobotPose = 
  | 'idle' 
  | 'pointing' 
  | 'explaining' 
  | 'waving' 
  | 'thinking' 
  | 'celebrating' 
  | 'excitement' 
  | 'confusion' 
  | 'empathy';

export interface AnimatedRobotCharacterProps {
  isSpeaking: boolean;
  currentPose?: RobotPose;
  speechText?: string;
  explicitEmotion?: string;
  onPoseChange?: (pose: RobotPose) => void;
  className?: string;
}

/**
 * Sentiment analysis helper that maps AI dialogue text or explicit sentiment parameters
 * into specific robotic poses and motion keyframes.
 */
export function analyzeTextSentiment(text: string, explicitEmotion?: string): RobotPose {
  if (
    explicitEmotion &&
    ['excitement', 'confusion', 'empathy', 'pointing', 'explaining', 'thinking', 'celebrating', 'waving'].includes(explicitEmotion.toLowerCase())
  ) {
    return explicitEmotion.toLowerCase() as RobotPose;
  }

  if (!text || !text.trim()) return 'idle';

  const lower = text.toLowerCase();

  // 1. Excitement / High Energy / Eureka
  if (
    lower.includes('awesome') ||
    lower.includes('fantastic') ||
    lower.includes('brilliant') ||
    lower.includes('yay') ||
    lower.includes('eureka') ||
    lower.includes('amazing') ||
    lower.includes('spot on') ||
    lower.includes('congratulations') ||
    lower.includes('woohoo') ||
    lower.includes('superstar') ||
    lower.includes('mastered') ||
    (lower.includes('!') && (lower.includes('great') || lower.includes('unlock') || lower.includes('boom')))
  ) {
    return 'excitement';
  }

  // 2. Confusion / Curiosity / Puzzled Inquiry
  if (
    lower.includes('why') ||
    lower.includes('how come') ||
    lower.includes('tricky') ||
    lower.includes('curious') ||
    lower.includes('puzzle') ||
    lower.includes('mystery') ||
    lower.includes('confused') ||
    lower.includes('wondering') ||
    lower.includes('under the hood') ||
    lower.includes('let\'s examine') ||
    lower.includes('what happens if') ||
    lower.includes('?')
  ) {
    return 'confusion';
  }

  // 3. Empathy / Reassurance / Calming Comfort
  if (
    lower.includes('don\'t worry') ||
    lower.includes('take a deep breath') ||
    lower.includes('relax') ||
    lower.includes('completely normal') ||
    lower.includes('you\'ve got this') ||
    lower.includes('take it easy') ||
    lower.includes('no stress') ||
    lower.includes('calm') ||
    lower.includes('patient') ||
    lower.includes('here for you') ||
    lower.includes('overwhelm') ||
    lower.includes('one step at a time')
  ) {
    return 'empathy';
  }

  // 4. Pointing / Highlighting / Visual Focus
  if (
    lower.includes('look at') ||
    lower.includes('diagram') ||
    lower.includes('step 1') ||
    lower.includes('notice') ||
    lower.includes('on the board') ||
    lower.includes('key takeaway') ||
    lower.includes('here is the') ||
    lower.includes('first principle') ||
    lower.includes('chart') ||
    lower.includes('visual')
  ) {
    return 'pointing';
  }

  // Default to conversational explaining gesture
  return 'explaining';
}

export const AnimatedRobotCharacter: React.FC<AnimatedRobotCharacterProps> = ({
  isSpeaking,
  currentPose = 'idle',
  speechText = '',
  explicitEmotion,
  onPoseChange,
  className = ''
}) => {
  // Active pose state
  const [activePose, setActivePose] = useState<RobotPose>(currentPose);
  const [eyeState, setEyeState] = useState<'normal' | 'blink' | 'happy' | 'question' | 'soft'>('normal');

  // Automatic sentiment analysis trigger on text / explicit emotion change
  useEffect(() => {
    if (currentPose && currentPose !== 'idle') {
      setActivePose(currentPose);
      return;
    }

    if (speechText || explicitEmotion) {
      const detected = analyzeTextSentiment(speechText, explicitEmotion);
      setActivePose(detected);
    } else if (isSpeaking) {
      setActivePose('explaining');
    } else {
      setActivePose('idle');
    }
  }, [speechText, explicitEmotion, currentPose, isSpeaking]);

  // Sync state upward if requested
  useEffect(() => {
    onPoseChange?.(activePose);
  }, [activePose, onPoseChange]);

  // Automatic Eye Blinking effect
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setEyeState('blink');
      setTimeout(() => setEyeState('normal'), 180);
    }, 4200);
    return () => clearInterval(blinkInterval);
  }, []);

  // Update Eye expression based on current pose/sentiment
  useEffect(() => {
    if (activePose === 'celebrating' || activePose === 'excitement') {
      setEyeState('happy');
    } else if (activePose === 'thinking' || activePose === 'confusion') {
      setEyeState('question');
    } else if (activePose === 'empathy') {
      setEyeState('soft');
    } else if (eyeState !== 'blink') {
      setEyeState('normal');
    }
  }, [activePose]);

  // Body Chassis Keyframe Motion Variants - Smooth Physics-Driven Motion
  const bodyVariants = {
    idle: {
      y: [0, -6, 0],
      rotate: [0, 1.2, -1.2, 0],
      scale: 1,
      transition: { repeat: Infinity, duration: 4.2, ease: 'easeInOut' }
    },
    excitement: {
      y: [0, -8, 0],
      rotate: [0, 2, -2, 0],
      scale: [1, 1.03, 1],
      transition: { repeat: Infinity, duration: 3.2, ease: 'easeInOut' }
    },
    confusion: {
      y: [0, -4, 0],
      rotate: [0, 5, 3, 5],
      x: [-2, 2, -2],
      scale: 0.99,
      transition: { repeat: Infinity, duration: 3.2, ease: 'easeInOut' }
    },
    empathy: {
      y: [0, -6, 0],
      rotate: [-2, 2, -2],
      x: [-4, 4, -4],
      scale: 1.01,
      transition: { repeat: Infinity, duration: 4.2, ease: 'easeInOut' }
    },
    pointing: {
      x: [0, 6, 5],
      y: [0, -4, 0],
      rotate: -2,
      scale: 1,
      transition: { type: 'spring', stiffness: 140, damping: 20, mass: 0.9 }
    },
    explaining: {
      y: [0, -6, 0],
      rotate: [0, 1.5, -1.5, 0],
      scale: 1,
      transition: { repeat: Infinity, duration: 3.0, ease: 'easeInOut' }
    },
    waving: {
      y: [0, -5, 0],
      rotate: [0, -2, 2, 0],
      transition: { repeat: Infinity, duration: 2.5, ease: 'easeInOut' }
    },
    thinking: {
      y: [0, -4, 0],
      rotate: 6,
      transition: { type: 'spring', stiffness: 120, damping: 18 }
    },
    celebrating: {
      y: [0, -10, 0],
      rotate: [0, -3, 3, 0],
      scale: [1, 1.04, 1],
      transition: { repeat: Infinity, duration: 2.8, ease: 'easeInOut' }
    }
  };

  // Left Arm Keyframe Variants - Natural Fluid Motion
  const leftArmVariants = {
    idle: {
      rotate: [0, -4, 0],
      y: [0, 2, 0],
      transition: { repeat: Infinity, duration: 3.5, ease: 'easeInOut' }
    },
    excitement: {
      rotate: [-35, -20, -35],
      y: [-12, -4, -12],
      x: [-6, -2, -6],
      transition: { repeat: Infinity, duration: 2.8, ease: 'easeInOut' }
    },
    confusion: {
      rotate: [20, 28, 20],
      x: [10, 14, 10],
      y: [-6, -2, -6],
      transition: { repeat: Infinity, duration: 3.0, ease: 'easeInOut' }
    },
    empathy: {
      rotate: [-25, -15, -25],
      y: [-10, -4, -10],
      x: [-10, -6, -10],
      transition: { repeat: Infinity, duration: 3.8, ease: 'easeInOut' }
    },
    pointing: {
      rotate: -10,
      x: -4,
      y: -6,
      transition: { type: 'spring', stiffness: 140, damping: 20 }
    },
    explaining: {
      rotate: [-12, 8, -8, 4],
      y: [-4, 4, -4],
      transition: { repeat: Infinity, duration: 3.2, ease: 'easeInOut' }
    },
    waving: {
      rotate: [0, -8, 0],
      transition: { repeat: Infinity, duration: 2.0, ease: 'easeInOut' }
    },
    thinking: {
      rotate: 30,
      x: 16,
      y: -22,
      transition: { type: 'spring', stiffness: 140, damping: 20 }
    },
    celebrating: {
      rotate: -45,
      y: -15,
      x: -6,
      transition: { type: 'spring', stiffness: 140, damping: 20 }
    }
  };

  // Right Arm Keyframe Variants - Smooth Natural Gestures
  const rightArmVariants = {
    idle: {
      rotate: [0, 4, 0],
      y: [0, 2, 0],
      transition: { repeat: Infinity, duration: 3.5, ease: 'easeInOut', delay: 0.5 }
    },
    excitement: {
      rotate: [35, 20, 35],
      y: [-12, -4, -12],
      x: [6, 2, 6],
      transition: { repeat: Infinity, duration: 2.8, ease: 'easeInOut' }
    },
    confusion: {
      rotate: [-45, -35, -45],
      x: [-12, -8, -12],
      y: [-22, -18, -22],
      transition: { repeat: Infinity, duration: 3.0, ease: 'easeInOut' }
    },
    empathy: {
      rotate: [25, 15, 25],
      y: [-10, -4, -10],
      x: [10, 6, 10],
      transition: { repeat: Infinity, duration: 3.8, ease: 'easeInOut' }
    },
    pointing: {
      rotate: -72,
      x: 32,
      y: -18,
      scale: 1.08,
      transition: { type: 'spring', stiffness: 140, damping: 20 }
    },
    explaining: {
      rotate: [8, -14, 10, -6],
      y: [4, -4, 4],
      transition: { repeat: Infinity, duration: 3.2, ease: 'easeInOut' }
    },
    waving: {
      rotate: [-80, -105, -80],
      x: 8,
      y: -20,
      transition: { repeat: Infinity, duration: 1.5, ease: 'easeInOut' }
    },
    thinking: {
      rotate: -8,
      y: 0,
      transition: { duration: 0.4 }
    },
    celebrating: {
      rotate: 45,
      y: -15,
      x: 6,
      transition: { type: 'spring', stiffness: 140, damping: 20 }
    }
  };

  // Head Movement Variants - Organic Tilting & Breathing
  const headVariants = {
    idle: {
      y: [0, -3, 0],
      rotate: [0, 1.2, -1.2, 0],
      transition: { repeat: Infinity, duration: 4.5, ease: 'easeInOut' }
    },
    excitement: {
      y: [-4, 1, -4],
      rotate: [0, -3, 3, 0],
      transition: { repeat: Infinity, duration: 2.5, ease: 'easeInOut' }
    },
    confusion: {
      rotate: 12,
      y: -4,
      transition: { type: 'spring', stiffness: 140, damping: 20 }
    },
    empathy: {
      rotate: [-3, 3, -3],
      y: [0, -3, 0],
      transition: { repeat: Infinity, duration: 4.0, ease: 'easeInOut' }
    },
    pointing: {
      rotate: -6,
      y: -2,
      transition: { type: 'spring', stiffness: 140, damping: 20 }
    },
    explaining: {
      y: [0, -3, 1, -1, 0],
      rotate: [0, -2, 2, -1, 0],
      transition: { repeat: Infinity, duration: 2.2, ease: 'easeInOut' }
    },
    waving: {
      rotate: [-2, 2, -2],
      transition: { repeat: Infinity, duration: 2.0, ease: 'easeInOut' }
    },
    thinking: {
      rotate: 10,
      y: -4,
      transition: { type: 'spring', stiffness: 140, damping: 20 }
    },
    celebrating: {
      y: [-4, 1, -4],
      rotate: [0, -3, 3, 0],
      transition: { repeat: Infinity, duration: 2.5, ease: 'easeInOut' }
    }
  };

  // Chest Arc Reactor Color & Pulse Mapping - Smooth Breathing Dynamics
  const getChestCoreGlow = () => {
    switch (activePose) {
      case 'excitement':
      case 'celebrating':
        return {
          fill: ['#34d399', '#fbbf24', '#34d399'],
          scale: [1, 1.15, 1],
          opacity: [0.9, 1, 0.9],
          duration: 2.0
        };
      case 'confusion':
      case 'thinking':
        return {
          fill: ['#818cf8', '#c084fc', '#818cf8'],
          scale: [1, 1.12, 1],
          opacity: [0.8, 1, 0.8],
          duration: 2.2
        };
      case 'empathy':
        return {
          fill: ['#38bdf8', '#2dd4bf', '#38bdf8'],
          scale: [1, 1.15, 1],
          opacity: [0.85, 1, 0.85],
          duration: 2.5
        };
      case 'pointing':
        return {
          fill: '#10b981',
          scale: [1, 1.12, 1],
          opacity: 0.95,
          duration: 1.8
        };
      default:
        return {
          fill: '#10b981',
          scale: isSpeaking ? [1, 1.18, 1] : [1, 1.08, 1],
          opacity: 0.9,
          duration: isSpeaking ? 1.0 : 2.5
        };
    }
  };

  const coreGlow = getChestCoreGlow();

  // Sentiment UI Label & Icon
  const getSentimentInfo = () => {
    switch (activePose) {
      case 'excitement':
        return { label: 'Encouragement', icon: '🌟', color: 'from-amber-400 to-emerald-400 text-amber-300 border-amber-400/50' };
      case 'confusion':
        return { label: 'Curiosity / Inquiry', icon: '🤔', color: 'from-indigo-400 to-purple-400 text-purple-300 border-purple-400/50' };
      case 'empathy':
        return { label: 'Empathy & Support', icon: '💗', color: 'from-sky-400 to-teal-400 text-sky-300 border-sky-400/50' };
      case 'pointing':
        return { label: 'Highlighting Concept', icon: '👉', color: 'from-emerald-400 to-teal-400 text-emerald-300 border-emerald-400/50' };
      case 'celebrating':
        return { label: 'Celebration', icon: '🙌', color: 'from-yellow-400 to-amber-400 text-yellow-300 border-yellow-400/50' };
      case 'thinking':
        return { label: 'Processing', icon: '💭', color: 'from-blue-400 to-indigo-400 text-blue-300 border-blue-400/50' };
      default:
        return { label: 'Teaching Dialogue', icon: '🗣️', color: 'from-emerald-400 to-green-400 text-emerald-300 border-emerald-400/50' };
    }
  };

  const sentimentInfo = getSentimentInfo();

  return (
    <div className={`flex flex-col items-center justify-center select-none ${className}`}>
      
      {/* ROBOT CHARACTER CONTAINER */}
      <motion.div
        variants={bodyVariants}
        animate={activePose}
        className="relative w-56 h-64 sm:w-64 sm:h-72 flex items-center justify-center"
      >
        
        {/* Glowing Background Pedestal & Aura */}
        <div className={`absolute bottom-2 left-1/2 -translate-x-1/2 w-36 h-7 rounded-full blur-md animate-pulse ${
          activePose === 'excitement' ? 'bg-amber-400/20' : activePose === 'confusion' ? 'bg-purple-500/20' : activePose === 'empathy' ? 'bg-sky-400/20' : 'bg-emerald-500/20'
        }`}></div>
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-28 h-2.5 bg-emerald-400/80 rounded-full blur-xs"></div>

        {/* MAIN SVG ROBOT CHARACTER */}
        <svg
          viewBox="0 0 240 280"
          className="w-full h-full drop-shadow-[0_10px_25px_rgba(16,185,129,0.2)]"
          style={{ overflow: 'visible' }}
        >
          <defs>
            {/* Smooth Gradients */}
            <linearGradient id="bodyWhite" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="70%" stopColor="#f1f5f9" />
              <stop offset="100%" stopColor="#cbd5e1" />
            </linearGradient>

            <linearGradient id="visorBlack" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#020617" />
            </linearGradient>

            <linearGradient id="neonGreen" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#34d399" />
              <stop offset="100%" stopColor="#10b981" />
            </linearGradient>

            <linearGradient id="glowLaser" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#34d399" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
            </linearGradient>

            {/* Neon Glow Filter */}
            <filter id="neonGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* LASER POINTER BEAM (Appears when pointing at presentation screen!) */}
          <AnimatePresence>
            {activePose === 'pointing' && (
              <motion.g
                initial={{ opacity: 0, scaleX: 0 }}
                animate={{ opacity: 1, scaleX: 1 }}
                exit={{ opacity: 0, scaleX: 0 }}
                transition={{ duration: 0.4, ease: 'easeOut' }}
              >
                <path
                  d="M 185 130 L 260 110"
                  stroke="url(#glowLaser)"
                  strokeWidth="4"
                  strokeDasharray="6 3"
                  filter="url(#neonGlow)"
                  className="animate-pulse"
                />
                <circle cx="260" cy="110" r="5" fill="#34d399" filter="url(#neonGlow)" />
              </motion.g>
            )}
          </AnimatePresence>

          {/* LEFT ROBOT ARM (Presenter's Left) */}
          <motion.g
            variants={leftArmVariants}
            animate={activePose}
            style={{ transformOrigin: '70px 140px' }}
          >
            {/* Shoulder Joint */}
            <circle cx="70" cy="140" r="10" fill="#64748b" />
            {/* Upper Arm */}
            <rect x="52" y="140" width="16" height="38" rx="8" fill="url(#bodyWhite)" stroke="#94a3b8" strokeWidth="1.5" />
            {/* Elbow Joint */}
            <circle cx="60" cy="178" r="7" fill={activePose === 'excitement' ? '#fbbf24' : '#10b981'} />
            {/* Forearm */}
            <rect x="53" y="180" width="14" height="32" rx="7" fill="url(#bodyWhite)" stroke="#94a3b8" strokeWidth="1.5" />
            {/* Robot Hand Gripper */}
            <circle cx="60" cy="216" r="8" fill="#0f172a" />
            <path d="M 54 216 C 54 224, 66 224, 66 216" stroke="#10b981" strokeWidth="2.5" fill="none" />
          </motion.g>

          {/* RIGHT ROBOT ARM (Points & Gestures to Blackboard) */}
          <motion.g
            variants={rightArmVariants}
            animate={activePose}
            style={{ transformOrigin: '170px 140px' }}
          >
            {/* Shoulder Joint */}
            <circle cx="170" cy="140" r="10" fill="#64748b" />
            {/* Upper Arm */}
            <rect x="172" y="140" width="16" height="38" rx="8" fill="url(#bodyWhite)" stroke="#94a3b8" strokeWidth="1.5" />
            {/* Elbow Joint */}
            <circle cx="180" cy="178" r="7" fill={activePose === 'confusion' ? '#a855f7' : '#10b981'} />
            {/* Forearm */}
            <rect x="173" y="180" width="14" height="32" rx="7" fill="url(#bodyWhite)" stroke="#94a3b8" strokeWidth="1.5" />
            {/* Robot Hand / Pointer Tip */}
            <circle cx="180" cy="216" r="8" fill="#0f172a" />
            {activePose === 'pointing' ? (
              // Pointing index finger emitter
              <path d="M 180 216 L 195 210" stroke="#34d399" strokeWidth="3.5" strokeLinecap="round" filter="url(#neonGlow)" />
            ) : (
              <path d="M 174 216 C 174 224, 186 224, 186 216" stroke="#10b981" strokeWidth="2.5" fill="none" />
            )}
          </motion.g>

          {/* MAIN ROBOT TORSO / BODY */}
          <g>
            {/* White Futuristic Body Chassis */}
            <rect x="80" y="125" width="80" height="95" rx="35" fill="url(#bodyWhite)" stroke="#cbd5e1" strokeWidth="2" />
            
            {/* Glowing Chest Arc Reactor / Core */}
            <circle cx="120" cy="165" r="16" fill="#0f172a" stroke="#334155" strokeWidth="2" />
            <motion.circle
              cx="120"
              cy="165"
              r="10"
              filter="url(#neonGlow)"
              animate={{
                fill: coreGlow.fill,
                scale: coreGlow.scale,
                opacity: coreGlow.opacity
              }}
              transition={{ repeat: Infinity, duration: coreGlow.duration }}
            />
            {/* Chest Core Pulse Rings */}
            <circle cx="120" cy="165" r="5" fill="#ffffff" opacity="0.9" />

            {/* Anti-Gravity Bottom Thruster Vent */}
            <ellipse cx="120" cy="218" rx="22" ry="7" fill="#0f172a" />
            <motion.ellipse
              cx="120"
              cy="222"
              rx="16"
              ry="8"
              fill={activePose === 'excitement' ? '#fbbf24' : activePose === 'empathy' ? '#38bdf8' : '#10b981'}
              filter="url(#neonGlow)"
              animate={{
                ry: activePose === 'excitement' ? [6, 11, 6] : [6, 10, 6],
                opacity: [0.75, 0.95, 0.75]
              }}
              transition={{ repeat: Infinity, duration: 1.6, ease: 'easeInOut' }}
            />
          </g>

          {/* ROBOT HEAD & VISOR ASSEMBLY */}
          <motion.g
            variants={headVariants}
            animate={activePose}
            style={{ transformOrigin: '120px 115px' }}
          >
            {/* Antenna Pole & Top Light */}
            <rect x="117" y="18" width="6" height="22" rx="3" fill="#64748b" />
            <motion.circle
              cx="120"
              cy="16"
              r="8"
              filter="url(#neonGlow)"
              animate={{
                scale: isSpeaking ? [1, 1.25, 1] : [1, 1.1, 1],
                fill: activePose === 'excitement' ? ['#fbbf24', '#f59e0b', '#fbbf24'] : activePose === 'confusion' ? ['#c084fc', '#a855f7', '#c084fc'] : ['#34d399', '#22c55e', '#34d399']
              }}
              transition={{ repeat: Infinity, duration: isSpeaking ? 0.8 : 2.5, ease: 'easeInOut' }}
            />

            {/* White Rounded Ceramic Head Helmet */}
            <rect x="65" y="38" width="110" height="82" rx="40" fill="url(#bodyWhite)" stroke="#cbd5e1" strokeWidth="2.5" />

            {/* Side Ear Caps / Speakers */}
            <rect x="55" y="62" width="12" height="34" rx="6" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />
            <rect x="173" y="62" width="12" height="34" rx="6" fill="#0f172a" stroke="#10b981" strokeWidth="1.5" />

            {/* Dark Glossy Visor Screen */}
            <rect x="75" y="48" width="90" height="60" rx="25" fill="url(#visorBlack)" stroke="#334155" strokeWidth="2" />

            {/* GLOWING DIGITAL NEON EYES */}
            <g filter="url(#neonGlow)">
              {eyeState === 'blink' ? (
                // Blinking Eyes (Horizontal Lines)
                <>
                  <line x1="92" y1="76" x2="108" y2="76" stroke="#34d399" strokeWidth="4" strokeLinecap="round" />
                  <line x1="132" y1="76" x2="148" y2="76" stroke="#34d399" strokeWidth="4" strokeLinecap="round" />
                </>
              ) : eyeState === 'happy' ? (
                // Happy Arc Eyes (^ ^)
                <>
                  <path d="M 90 80 Q 100 66 110 80" stroke="#fbbf24" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                  <path d="M 130 80 Q 140 66 150 80" stroke="#fbbf24" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                </>
              ) : eyeState === 'question' ? (
                // Questioning / Curious Eyes (One raised, one tilted)
                <>
                  <circle cx="100" cy="70" r="7.5" fill="#c084fc" />
                  <rect x="130" y="76" width="18" height="6" rx="3" fill="#c084fc" />
                </>
              ) : eyeState === 'soft' ? (
                // Empathetic Soft Eyes
                <>
                  <path d="M 92 76 Q 100 84 108 76" stroke="#38bdf8" strokeWidth="4" strokeLinecap="round" fill="none" />
                  <path d="M 132 76 Q 140 84 148 76" stroke="#38bdf8" strokeWidth="4" strokeLinecap="round" fill="none" />
                </>
              ) : (
                // Normal Expressive Glowing Oval Eyes
                <>
                  <motion.ellipse
                    cx="100"
                    cy="75"
                    rx="9"
                    ry="11"
                    fill="#34d399"
                    animate={{ rx: isSpeaking ? [8.5, 9.5, 8.5] : 9 }}
                    transition={{ repeat: Infinity, duration: 1.2, ease: 'easeInOut' }}
                  />
                  <motion.ellipse
                    cx="140"
                    cy="75"
                    rx="9"
                    ry="11"
                    fill="#34d399"
                    animate={{ rx: isSpeaking ? [8.5, 9.5, 8.5] : 9 }}
                    transition={{ repeat: Infinity, duration: 1.2, ease: 'easeInOut' }}
                  />
                  {/* Eye Reflection Highlights */}
                  <circle cx="97" cy="71" r="3" fill="#ffffff" />
                  <circle cx="137" cy="71" r="3" fill="#ffffff" />
                </>
              )}
            </g>

            {/* DIGITAL SPEECH VISEME / MOUTH BAR */}
            <g>
              {isSpeaking ? (
                // Animated Audio Equalizer Speech Bar
                <g filter="url(#neonGlow)">
                  <motion.rect
                    x="105" y="94" width="4" height="8" rx="2" fill={activePose === 'excitement' ? '#fbbf24' : '#34d399'}
                    animate={{ height: [4, 12, 6, 14, 4] }}
                    transition={{ repeat: Infinity, duration: 0.5, ease: 'easeInOut' }}
                  />
                  <motion.rect
                    x="113" y="94" width="4" height="12" rx="2" fill={activePose === 'excitement' ? '#fbbf24' : '#34d399'}
                    animate={{ height: [10, 5, 15, 4, 10] }}
                    transition={{ repeat: Infinity, duration: 0.55, ease: 'easeInOut' }}
                  />
                  <motion.rect
                    x="121" y="94" width="4" height="10" rx="2" fill={activePose === 'excitement' ? '#fbbf24' : '#34d399'}
                    animate={{ height: [5, 14, 4, 12, 5] }}
                    transition={{ repeat: Infinity, duration: 0.48, ease: 'easeInOut' }}
                  />
                  <motion.rect
                    x="129" y="94" width="4" height="8" rx="2" fill={activePose === 'excitement' ? '#fbbf24' : '#34d399'}
                    animate={{ height: [7, 4, 12, 5, 7] }}
                    transition={{ repeat: Infinity, duration: 0.52, ease: 'easeInOut' }}
                  />
                </g>
              ) : (
                // Friendly Static Digital Smile Line
                <path
                  d="M 108 94 Q 120 100 132 94"
                  stroke={activePose === 'empathy' ? '#38bdf8' : '#10b981'}
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  fill="none"
                />
              )}
            </g>
          </motion.g>
        </svg>

      </motion.div>

      {/* ACTIVE SENTIMENT BADGE */}
      <div className="mt-2 flex items-center space-x-1.5 px-3 py-1 rounded-full bg-slate-900/90 border border-slate-700/80 shadow-md">
        <span className="text-xs">{sentimentInfo.icon}</span>
        <span className="text-[10px] font-mono font-bold uppercase tracking-wide text-slate-300">
          Robot Emotion: <span className="text-emerald-400 font-extrabold">{sentimentInfo.label}</span>
        </span>
      </div>

      {/* INTERACTIVE SENTIMENT & POSE CONTROLS */}
      <div className="mt-2.5 flex flex-wrap items-center justify-center gap-1.5 max-w-xs">
        <button
          onClick={() => {
            setActivePose('excitement');
            onPoseChange?.('excitement');
          }}
          className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border transition-all ${
            activePose === 'excitement'
              ? 'bg-amber-400 text-slate-950 border-amber-300 font-extrabold shadow-sm'
              : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
          }`}
          title="Encouraging & Delighted animation"
        >
          🌟 Encouraging
        </button>

        <button
          onClick={() => {
            setActivePose('confusion');
            onPoseChange?.('confusion');
          }}
          className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border transition-all ${
            activePose === 'confusion'
              ? 'bg-purple-500 text-white border-purple-400 font-extrabold shadow-sm'
              : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
          }`}
          title="Curiosity & Head Scratch animation"
        >
          🤔 Confusion
        </button>

        <button
          onClick={() => {
            setActivePose('empathy');
            onPoseChange?.('empathy');
          }}
          className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border transition-all ${
            activePose === 'empathy'
              ? 'bg-sky-400 text-slate-950 border-sky-300 font-extrabold shadow-sm'
              : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
          }`}
          title="Empathy & Calming Embrace animation"
        >
          💗 Empathy
        </button>

        <button
          onClick={() => {
            setActivePose('pointing');
            onPoseChange?.('pointing');
          }}
          className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border transition-all ${
            activePose === 'pointing'
              ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-extrabold shadow-sm'
              : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
          }`}
          title="Laser Pointer at Blackboard animation"
        >
          👉 Point Board
        </button>

        <button
          onClick={() => {
            setActivePose('explaining');
            onPoseChange?.('explaining');
          }}
          className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border transition-all ${
            activePose === 'explaining'
              ? 'bg-teal-500 text-slate-950 border-teal-400 font-extrabold shadow-sm'
              : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
          }`}
          title="Conversational Teaching Gesture"
        >
          🗣️ Explain
        </button>
      </div>

    </div>
  );
};
