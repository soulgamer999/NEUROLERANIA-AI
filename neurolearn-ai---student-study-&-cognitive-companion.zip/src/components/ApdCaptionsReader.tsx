import React, { useState } from 'react';
import { 
  Volume2, 
  VolumeX, 
  Eye, 
  Sparkles, 
  Sliders, 
  Captions, 
  CheckCircle2, 
  FileText,
  Play,
  Pause,
  RotateCcw
} from 'lucide-react';
import { speakText, stopSpeech } from '../utils/audio';

interface ApdCaptionsReaderProps {
  className?: string;
}

export const ApdCaptionsReader: React.FC<ApdCaptionsReaderProps> = ({ className = '' }) => {
  const [sampleText, setSampleText] = useState(
    'Welcome to today\'s lesson. First, we will examine how energy flows through the ecosystem. Next, we will identify primary producers and consumers.'
  );
  const [isPlaying, setIsPlaying] = useState(false);
  const [speed, setSpeed] = useState(0.75); // Slower speech rate ideal for APD
  const [currentWordIndex, setCurrentWordIndex] = useState(-1);
  const [isHighContrast, setIsHighContrast] = useState(true);

  const words = sampleText.split(' ');

  const handlePlaySlowAudio = () => {
    if (isPlaying) {
      stopSpeech();
      setIsPlaying(false);
      setCurrentWordIndex(-1);
    } else {
      setIsPlaying(true);
      // Simulate real-time caption highlighting
      let idx = 0;
      speakText(sampleText, speed);
      const interval = setInterval(() => {
        if (idx < words.length) {
          setCurrentWordIndex(idx);
          idx++;
        } else {
          clearInterval(interval);
          setIsPlaying(false);
          setCurrentWordIndex(-1);
        }
      }, 350 / speed);
    }
  };

  return (
    <div role="region" aria-label="Auditory Processing Disorder Closed Captions Reader Studio" className={`bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm ${className}`}>
      
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-2.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-md">
            <Captions className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              Auditory Processing Disorder (APD) Visual Assistant
              <span className="text-[10px] bg-sky-100 dark:bg-sky-950/80 text-sky-700 dark:text-sky-300 font-bold px-2 py-0.5 rounded-md border border-sky-300/50">
                Visual Captions & Slow Speech
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Bypasses auditory clutter with real-time synchronized text captions, slowed audio pacing, and clean high-contrast bullet outlines.
            </p>
          </div>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
        <div className="flex items-center space-x-2">
          <button
            onClick={handlePlaySlowAudio}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-extrabold transition-all ${
              isPlaying
                ? 'bg-rose-500 text-white shadow-md'
                : 'bg-sky-500 hover:bg-sky-600 text-white shadow-sm'
            }`}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
            <span>{isPlaying ? 'Pause Audio' : 'Play Clear Slow Speech'}</span>
          </button>

          <button
            onClick={() => setIsHighContrast(!isHighContrast)}
            className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-bold border transition-all ${
              isHighContrast
                ? 'bg-slate-900 text-amber-300 border-amber-400'
                : 'bg-white text-slate-700 border-slate-300'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>High Contrast Visuals</span>
          </button>
        </div>

        {/* Speed Slider */}
        <div className="flex items-center space-x-2 text-xs font-bold text-slate-700 dark:text-slate-300">
          <Sliders className="w-3.5 h-3.5 text-sky-500" />
          <span>Speech Rate: <span className="text-sky-600 dark:text-sky-400">{speed}x</span></span>
          <input
            type="range"
            min="0.5"
            max="1.0"
            step="0.05"
            value={speed}
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            className="w-24 accent-sky-500"
          />
        </div>
      </div>

      {/* REAL-TIME SYNCHRONIZED CAPTIONS DISPLAY CANVAS */}
      <div className={`p-5 rounded-2xl transition-all ${
        isHighContrast
          ? 'bg-black text-white border-2 border-amber-400 shadow-xl'
          : 'bg-slate-900 text-slate-100 border border-slate-800'
      }`}>
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
          <span className="text-[10px] font-mono font-bold uppercase text-sky-400 tracking-wider flex items-center gap-1.5">
            <Captions className="w-3.5 h-3.5" />
            Synchronized Visual Closed Captions
          </span>
          <span className="text-[10px] bg-sky-950 text-sky-300 px-2 py-0.5 rounded font-mono">
            APD Friendly
          </span>
        </div>

        <p className="text-base sm:text-lg font-bold leading-relaxed tracking-wide">
          {words.map((word, idx) => (
            <span
              key={idx}
              className={`inline-block mr-1.5 px-1 py-0.5 rounded transition-all ${
                idx === currentWordIndex
                  ? 'bg-amber-400 text-slate-950 font-black scale-105 shadow-md shadow-amber-400/50'
                  : 'hover:text-sky-300'
              }`}
            >
              {word}
            </span>
          ))}
        </p>
      </div>

      {/* VISUAL BULLET OUTLINE REINFORCEMENT */}
      <div className="mt-4 p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700">
        <h4 className="text-xs font-black uppercase text-sky-600 dark:text-sky-400 mb-2">
          Step-by-Step Visual Summary (No Auditory Strain):
        </h4>
        <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 font-medium">
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
            <span><strong>Part 1:</strong> Energy Flow in the Ecosystem</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-sky-500 shrink-0 mt-0.5" />
            <span><strong>Part 2:</strong> Primary Producers & Consumer Identification</span>
          </li>
        </ul>
      </div>

    </div>
  );
};
