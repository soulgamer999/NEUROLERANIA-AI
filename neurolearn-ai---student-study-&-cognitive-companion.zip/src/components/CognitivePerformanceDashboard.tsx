import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { motion } from 'motion/react';
import { 
  TrendingUp, 
  Battery, 
  Zap, 
  Clock, 
  Sparkles, 
  Calendar,
  AlertCircle,
  Brain,
  CheckCircle2
} from 'lucide-react';
import { WeeklyPerformanceData } from '../types';

const INITIAL_WEEKLY_DATA: WeeklyPerformanceData[] = [
  { dayLabel: 'Mon', date: 'Aug 2', focusMinutes: 25, mentalBatteryPct: 70, tasksCompleted: 3, cognitiveLoad: 'Optimal' },
  { dayLabel: 'Tue', date: 'Aug 3', focusMinutes: 45, mentalBatteryPct: 88, tasksCompleted: 5, cognitiveLoad: 'Optimal' },
  { dayLabel: 'Wed', date: 'Aug 4', focusMinutes: 30, mentalBatteryPct: 65, tasksCompleted: 4, cognitiveLoad: 'High' },
  { dayLabel: 'Thu', date: 'Aug 5', focusMinutes: 60, mentalBatteryPct: 92, tasksCompleted: 7, cognitiveLoad: 'Optimal' },
  { dayLabel: 'Fri', date: 'Aug 6', focusMinutes: 40, mentalBatteryPct: 78, tasksCompleted: 4, cognitiveLoad: 'Optimal' },
  { dayLabel: 'Sat', date: 'Aug 7', focusMinutes: 15, mentalBatteryPct: 85, tasksCompleted: 2, cognitiveLoad: 'Low' },
  { dayLabel: 'Sun', date: 'Aug 8', focusMinutes: 50, mentalBatteryPct: 90, tasksCompleted: 6, cognitiveLoad: 'Optimal' },
];

export const CognitivePerformanceDashboard: React.FC = () => {
  const [data, setData] = useState<WeeklyPerformanceData[]>(INITIAL_WEEKLY_DATA);
  const [hoveredDay, setHoveredDay] = useState<WeeklyPerformanceData | null>(data[data.length - 1]);
  const [selectedMetric, setSelectedMetric] = useState<'both' | 'focus' | 'battery'>('both');
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    // Clear previous SVG contents
    d3.select(svgRef.current).selectAll('*').remove();

    const width = 640;
    const height = 260;
    const margin = { top: 20, right: 30, bottom: 40, left: 40 };

    const svg = d3.select(svgRef.current)
      .attr('viewBox', `0 0 ${width} ${height}`)
      .attr('style', 'max-width: 100%; height: auto;');

    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Scales
    const xScale = d3.scalePoint()
      .domain(data.map(d => d.dayLabel))
      .range([0, innerWidth])
      .padding(0.5);

    const maxFocus = Math.max(...data.map(d => d.focusMinutes), 80);
    const yScaleFocus = d3.scaleLinear()
      .domain([0, maxFocus])
      .range([innerHeight, 0])
      .nice();

    const yScaleBattery = d3.scaleLinear()
      .domain([0, 100])
      .range([innerHeight, 0]);

    // Gradients
    const defs = svg.append('defs');

    // Focus gradient (emerald)
    const focusGrad = defs.append('linearGradient')
      .attr('id', 'focus-gradient')
      .attr('x1', '0%').attr('y1', '0%')
      .attr('x2', '0%').attr('y2', '100%');
    focusGrad.append('stop').attr('offset', '0%').attr('stop-color', '#10b981').attr('stop-opacity', 0.4);
    focusGrad.append('stop').attr('offset', '100%').attr('stop-color', '#10b981').attr('stop-opacity', 0.0);

    // Battery gradient (indigo)
    const batteryGrad = defs.append('linearGradient')
      .attr('id', 'battery-gradient')
      .attr('x1', '0%').attr('y1', '0%')
      .attr('x2', '0%').attr('y2', '100%');
    batteryGrad.append('stop').attr('offset', '0%').attr('stop-color', '#6366f1').attr('stop-opacity', 0.35);
    batteryGrad.append('stop').attr('offset', '100%').attr('stop-color', '#6366f1').attr('stop-opacity', 0.0);

    // Grid lines
    g.append('g')
      .attr('class', 'grid-lines')
      .call(
        d3.axisLeft(yScaleBattery)
          .ticks(5)
          .tickSize(-innerWidth)
          .tickFormat(() => '')
      )
      .selectAll('line')
      .attr('stroke', '#e2e8f0')
      .attr('stroke-dasharray', '3,3')
      .attr('stroke-opacity', 0.5);

    // Area Generators
    const areaFocus = d3.area<WeeklyPerformanceData>()
      .x(d => xScale(d.dayLabel) || 0)
      .y0(innerHeight)
      .y1(d => yScaleFocus(d.focusMinutes))
      .curve(d3.curveMonotoneX);

    const areaBattery = d3.area<WeeklyPerformanceData>()
      .x(d => xScale(d.dayLabel) || 0)
      .y0(innerHeight)
      .y1(d => yScaleBattery(d.mentalBatteryPct))
      .curve(d3.curveMonotoneX);

    // Line Generators
    const lineFocus = d3.line<WeeklyPerformanceData>()
      .x(d => xScale(d.dayLabel) || 0)
      .y(d => yScaleFocus(d.focusMinutes))
      .curve(d3.curveMonotoneX);

    const lineBattery = d3.line<WeeklyPerformanceData>()
      .x(d => xScale(d.dayLabel) || 0)
      .y(d => yScaleBattery(d.mentalBatteryPct))
      .curve(d3.curveMonotoneX);

    // Render Focus Area & Line
    if (selectedMetric === 'both' || selectedMetric === 'focus') {
      g.append('path')
        .datum(data)
        .attr('fill', 'url(#focus-gradient)')
        .attr('d', areaFocus);

      g.append('path')
        .datum(data)
        .attr('fill', 'none')
        .attr('stroke', '#10b981')
        .attr('stroke-width', 3)
        .attr('d', lineFocus);
    }

    // Render Battery Area & Line
    if (selectedMetric === 'both' || selectedMetric === 'battery') {
      g.append('path')
        .datum(data)
        .attr('fill', 'url(#battery-gradient)')
        .attr('d', areaBattery);

      g.append('path')
        .datum(data)
        .attr('fill', 'none')
        .attr('stroke', '#6366f1')
        .attr('stroke-width', 2.5)
        .attr('stroke-dasharray', selectedMetric === 'both' ? '6 3' : 'none')
        .attr('d', lineBattery);
    }

    // X Axis
    const xAxis = g.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale));

    xAxis.selectAll('text')
      .attr('fill', '#64748b')
      .attr('font-size', '11px')
      .attr('font-weight', '600');

    xAxis.selectAll('line').remove();
    xAxis.select('.domain').attr('stroke', '#cbd5e1');

    // Interactive Data Dots
    data.forEach(d => {
      const cx = xScale(d.dayLabel) || 0;
      const cyFocus = yScaleFocus(d.focusMinutes);
      const cyBattery = yScaleBattery(d.mentalBatteryPct);

      if (selectedMetric === 'both' || selectedMetric === 'focus') {
        g.append('circle')
          .attr('cx', cx)
          .attr('cy', cyFocus)
          .attr('r', hoveredDay?.dayLabel === d.dayLabel ? 7 : 4.5)
          .attr('fill', '#10b981')
          .attr('stroke', '#ffffff')
          .attr('stroke-width', 2)
          .attr('class', 'cursor-pointer transition-all')
          .on('mouseenter', () => setHoveredDay(d));
      }

      if (selectedMetric === 'both' || selectedMetric === 'battery') {
        g.append('circle')
          .attr('cx', cx)
          .attr('cy', cyBattery)
          .attr('r', hoveredDay?.dayLabel === d.dayLabel ? 7 : 4.5)
          .attr('fill', '#6366f1')
          .attr('stroke', '#ffffff')
          .attr('stroke-width', 2)
          .attr('class', 'cursor-pointer transition-all')
          .on('mouseenter', () => setHoveredDay(d));
      }

      // Invisible Overlay Column for Easy Touch/Hover
      g.append('rect')
        .attr('x', cx - 20)
        .attr('y', 0)
        .attr('width', 40)
        .attr('height', innerHeight)
        .attr('fill', 'transparent')
        .attr('class', 'cursor-pointer')
        .on('mouseenter', () => setHoveredDay(d));
    });

  }, [data, hoveredDay, selectedMetric]);

  const totalFocusMins = data.reduce((acc, curr) => acc + curr.focusMinutes, 0);
  const avgBattery = Math.round(data.reduce((acc, curr) => acc + curr.mentalBatteryPct, 0) / data.length);
  const totalTasks = data.reduce((acc, curr) => acc + curr.tasksCompleted, 0);

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-emerald-100 dark:bg-emerald-950/80 rounded-xl text-emerald-600 dark:text-emerald-400">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Weekly Cognitive Performance Analytics</span>
              <Sparkles className="w-4 h-4 text-emerald-500 animate-pulse" />
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              D3-powered tracking of Focus Minutes vs Mental Battery resilience
            </p>
          </div>
        </div>

        {/* View Toggles */}
        <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl gap-1">
          <button
            onClick={() => setSelectedMetric('both')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              selectedMetric === 'both'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            All Metrics
          </button>
          <button
            onClick={() => setSelectedMetric('focus')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              selectedMetric === 'focus'
                ? 'bg-emerald-500 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Focus Streak
          </button>
          <button
            onClick={() => setSelectedMetric('battery')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              selectedMetric === 'battery'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
            }`}
          >
            Mental Battery
          </button>
        </div>
      </div>

      {/* Metric Stat Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              Weekly Focus Logged
            </span>
            <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-900/60 px-2 py-0.5 rounded-full">
              +18% vs Last Week
            </span>
          </div>
          <p className="text-2xl font-black text-emerald-950 dark:text-emerald-100">
            {totalFocusMins} <span className="text-xs font-bold text-emerald-700 dark:text-emerald-300">mins</span>
          </p>
        </div>

        <div className="p-4 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-indigo-800 dark:text-indigo-300 flex items-center gap-1.5">
              <Battery className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              Avg Mental Battery
            </span>
            <span className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-100 dark:bg-indigo-900/60 px-2 py-0.5 rounded-full">
              Optimal Recovery
            </span>
          </div>
          <p className="text-2xl font-black text-indigo-950 dark:text-indigo-100">
            {avgBattery}% <span className="text-xs font-bold text-indigo-700 dark:text-indigo-300">resilience</span>
          </p>
        </div>

        <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              Peak Focus Window
            </span>
            <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-900/60 px-2 py-0.5 rounded-full">
              Morning Alertness
            </span>
          </div>
          <p className="text-base font-black text-amber-950 dark:text-amber-100">
            10:00 AM – 12:30 PM
          </p>
          <p className="text-[10px] text-amber-700 dark:text-amber-300">
            Highest retention & focus speed
          </p>
        </div>
      </div>

      {/* D3 SVG Chart Area */}
      <div className="relative bg-slate-50 dark:bg-slate-950/50 rounded-xl p-4 border border-slate-200 dark:border-slate-800">
        <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
          <span className="font-semibold flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block"></span> Focus Minutes
            <span className="w-3 h-3 rounded-full bg-indigo-500 inline-block ml-3"></span> Mental Battery %
          </span>
          <span className="font-bold">Hover over data points to inspect details</span>
        </div>

        <svg ref={svgRef} className="w-full"></svg>

        {/* Hovered Day Tooltip Card */}
        {hoveredDay && (
          <motion.div
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-3 p-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-md flex flex-wrap items-center justify-between gap-3 text-xs"
          >
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-indigo-500" />
              <span className="font-bold text-slate-900 dark:text-white">
                {hoveredDay.dayLabel} ({hoveredDay.date}):
              </span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                ⚡ {hoveredDay.focusMinutes} mins focused
              </span>
              <span className="text-indigo-600 dark:text-indigo-400 font-bold">
                🔋 {hoveredDay.mentalBatteryPct}% battery
              </span>
              <span className="text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded font-bold">
                Tasks: {hoveredDay.tasksCompleted} completed
              </span>
            </div>
          </motion.div>
        )}
      </div>

      {/* AI Cognitive Recommendation Banner */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 text-white flex items-start space-x-3 border border-indigo-800">
        <Brain className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="text-xs font-bold text-indigo-200 uppercase tracking-wider">
            AI Psychological Insight for Peak Focus
          </p>
          <p className="text-xs text-indigo-100 leading-relaxed">
            Your mental stamina spikes between <strong>10:00 AM and 12:30 PM</strong>. We recommend scheduling heavy math or reading topics during this window, and using the 5-minute Stress Relief breathing exercise at 3:00 PM to prevent afternoon fatigue.
          </p>
        </div>
      </div>
    </div>
  );
};
