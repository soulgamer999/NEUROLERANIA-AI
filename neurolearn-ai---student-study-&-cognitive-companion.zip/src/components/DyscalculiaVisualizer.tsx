import React, { useState } from 'react';
import { 
  Calculator, 
  Sparkles, 
  HelpCircle, 
  Clock, 
  PieChart, 
  ArrowRight, 
  Plus, 
  Minus, 
  RotateCcw,
  CheckCircle2,
  Lightbulb,
  Hash
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DyscalculiaVisualizerProps {
  className?: string;
}

export const DyscalculiaVisualizer: React.FC<DyscalculiaVisualizerProps> = ({ className = '' }) => {
  const [activeSubTool, setActiveSubTool] = useState<'counter' | 'formula' | 'time' | 'fractions'>('counter');

  // Interactive Counter State
  const [numA, setNumA] = useState<number>(5);
  const [numB, setNumB] = useState<number>(3);
  const [operation, setOperation] = useState<'+' | '-' | '×'>('+');

  // Math Problem Explainer State
  const [wordProblem, setWordProblem] = useState<string>('If Sarah has 12 apples and gives 4 to Tom, how many apples remain?');
  const [explainedSteps, setExplainedSteps] = useState<{ step: string; visual: string; explanation: string }[] | null>([
    {
      step: 'Step 1: Start with total quantity',
      visual: '🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎🍎 (12 Apples)',
      explanation: 'Imagine holding a basket containing 12 physical red apples.'
    },
    {
      step: 'Step 2: Subtraction / Giving away',
      visual: '❌🍎 ❌🍎 ❌🍎 ❌🍎 (Remove 4 Apples)',
      explanation: 'Taking away 4 apples reduces the total count.'
    },
    {
      step: 'Step 3: Count remaining items',
      visual: '🍎🍎🍎🍎🍎🍎🍎🍎 = 8 Apples Left',
      explanation: 'Count the remaining apples one by one to get 8.'
    }
  ]);

  // Fraction State
  const [numerator, setNumerator] = useState<number>(3);
  const [denominator, setDenominator] = useState<number>(4);

  // Clock State
  const [hours, setHours] = useState<number>(3);
  const [minutes, setMinutes] = useState<number>(15);

  const calculateResult = () => {
    switch (operation) {
      case '+': return numA + numB;
      case '-': return Math.max(0, numA - numB);
      case '×': return numA * numB;
      default: return numA + numB;
    }
  };

  const renderVisualDots = (count: number, colorClass: string, label: string) => {
    const safeCount = Math.min(count, 30);
    return (
      <div className="flex flex-col gap-1.5" role="group" aria-label={`Visual Dot Group for ${label}: ${count} total items`}>
        <span className="text-xs font-bold text-slate-700 dark:text-slate-300">{label} ({count})</span>
        <div className="flex flex-wrap gap-1.5 p-2 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 min-h-[42px] items-center">
          {Array.from({ length: safeCount }).map((_, i) => (
            <motion.div
              key={i}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: i * 0.02 }}
              aria-label={`Dot ${i + 1} of ${count}`}
              className={`w-5 h-5 rounded-full ${colorClass} flex items-center justify-center text-[10px] font-black text-white shadow-xs`}
            >
              {i + 1}
            </motion.div>
          ))}
          {count > 30 && (
            <span className="text-xs font-bold text-slate-500">+{count - 30} more</span>
          )}
        </div>
      </div>
    );
  };

  return (
    <div role="region" aria-label="Dyscalculia Step-by-Step Visual Math Studio" className={`bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm ${className}`}>
      
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-2.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center text-white shadow-md">
            <Calculator className="w-5 h-5" aria-hidden="true" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              Dyscalculia Visual Math Assistant
              <span className="text-[10px] bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 font-bold px-2 py-0.5 rounded-md border border-amber-300/50">
                Number & Concept Helper
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Transforms abstract math formulas, numbers, and telling time into physical visual building blocks.
            </p>
          </div>
        </div>
      </div>

      {/* Sub-tool Selector Navigation */}
      <div className="flex flex-wrap gap-2 mb-5">
        <button
          onClick={() => setActiveSubTool('counter')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
            activeSubTool === 'counter'
              ? 'bg-amber-500 text-white shadow-sm'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Hash className="w-3.5 h-3.5" />
          <span>Visual Dot Counter</span>
        </button>

        <button
          onClick={() => setActiveSubTool('formula')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
            activeSubTool === 'formula'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Lightbulb className="w-3.5 h-3.5" />
          <span>Word Problem Translator</span>
        </button>

        <button
          onClick={() => setActiveSubTool('fractions')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
            activeSubTool === 'fractions'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <PieChart className="w-3.5 h-3.5" />
          <span>Fraction Visualizer</span>
        </button>

        <button
          onClick={() => setActiveSubTool('time')}
          className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
            activeSubTool === 'time'
              ? 'bg-rose-500 text-white shadow-sm'
              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Analog & Digital Time</span>
        </button>
      </div>

      {/* TOOL 1: VISUAL DOT COUNTER */}
      {activeSubTool === 'counter' && (
        <div className="space-y-4">
          <div className="bg-amber-50 dark:bg-amber-950/40 p-3.5 rounded-xl border border-amber-200 dark:border-amber-900/60 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <p>
              <strong>Concrete Quantity Representation:</strong> Instead of seeing abstract digits like "5 + 3", see exact physical counters so your brain can process total quantity directly.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
            {/* Number A Controls */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Quantity A</label>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setNumA(Math.max(1, numA - 1))}
                  className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 text-slate-800 dark:text-white font-black border border-slate-300 dark:border-slate-600 flex items-center justify-center hover:bg-slate-100"
                >
                  -
                </button>
                <input
                  type="number"
                  value={numA}
                  onChange={(e) => setNumA(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-16 h-8 text-center font-black text-slate-900 dark:text-white bg-white dark:bg-slate-700 rounded-lg border border-slate-300 dark:border-slate-600"
                />
                <button
                  onClick={() => setNumA(numA + 1)}
                  className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 text-slate-800 dark:text-white font-black border border-slate-300 dark:border-slate-600 flex items-center justify-center hover:bg-slate-100"
                >
                  +
                </button>
              </div>
            </div>

            {/* Operation Selector */}
            <div className="flex flex-col items-center justify-center space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Operation</label>
              <div className="flex items-center space-x-1.5 bg-white dark:bg-slate-700 p-1 rounded-xl border border-slate-300 dark:border-slate-600">
                {(['+', '-', '×'] as const).map(op => (
                  <button
                    key={op}
                    onClick={() => setOperation(op)}
                    className={`w-8 h-8 rounded-lg font-black text-sm transition-all ${
                      operation === op
                        ? 'bg-amber-500 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-600'
                    }`}
                  >
                    {op}
                  </button>
                ))}
              </div>
            </div>

            {/* Number B Controls */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Quantity B</label>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setNumB(Math.max(1, numB - 1))}
                  className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 text-slate-800 dark:text-white font-black border border-slate-300 dark:border-slate-600 flex items-center justify-center hover:bg-slate-100"
                >
                  -
                </button>
                <input
                  type="number"
                  value={numB}
                  onChange={(e) => setNumB(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-16 h-8 text-center font-black text-slate-900 dark:text-white bg-white dark:bg-slate-700 rounded-lg border border-slate-300 dark:border-slate-600"
                />
                <button
                  onClick={() => setNumB(numB + 1)}
                  className="w-8 h-8 rounded-lg bg-white dark:bg-slate-700 text-slate-800 dark:text-white font-black border border-slate-300 dark:border-slate-600 flex items-center justify-center hover:bg-slate-100"
                >
                  +
                </button>
              </div>
            </div>
          </div>

          {/* VISUAL DOT RESULT CANVAS */}
          <div className="space-y-3 bg-slate-900 text-white p-5 rounded-2xl shadow-inner">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-mono text-amber-400 font-bold uppercase tracking-wider">
                Visual Math Canvas: {numA} {operation} {numB} = {calculateResult()}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {renderVisualDots(numA, 'bg-amber-500', `Group A (${numA})`)}
              {renderVisualDots(numB, 'bg-indigo-500', `Group B (${numB})`)}
            </div>

            <div className="pt-3 border-t border-slate-800">
              {renderVisualDots(calculateResult(), 'bg-emerald-500', `Total Result (${calculateResult()})`)}
            </div>
          </div>
        </div>
      )}

      {/* TOOL 2: WORD PROBLEM TRANSLATOR */}
      {activeSubTool === 'formula' && (
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
              Enter any Math Word Problem or Equation:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={wordProblem}
                onChange={(e) => setWordProblem(e.target.value)}
                placeholder="e.g. 15 divided into 3 equal groups"
                className="flex-1 px-3.5 py-2 text-xs font-medium bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
              />
              <button
                onClick={() => {
                  // Simulate AI breakdown
                  setExplainedSteps([
                    {
                      step: 'Step 1: Identify key numbers',
                      visual: '🎯 Number A: 12, Number B: 4',
                      explanation: 'Highlight the given quantities in the question.'
                    },
                    {
                      step: 'Step 2: Determine math operation',
                      visual: '➖ Operation: Subtraction (-)',
                      explanation: 'Words like "gives away", "remains", or "difference" mean subtract.'
                    },
                    {
                      step: 'Step 3: Solve visually',
                      visual: '12 - 4 = 8',
                      explanation: 'Count down 4 steps from 12 to reach 8.'
                    }
                  ]);
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl transition-all shadow-sm flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Translate to Visual</span>
              </button>
            </div>
          </div>

          {explainedSteps && (
            <div className="space-y-3">
              <h4 className="text-xs font-black uppercase text-indigo-600 dark:text-indigo-400">
                Step-by-Step Visual Breakdown:
              </h4>
              <div className="space-y-2.5">
                {explainedSteps.map((s, idx) => (
                  <div key={idx} className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-black text-slate-800 dark:text-white">{s.step}</span>
                      <span className="text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950 px-2 py-0.5 rounded-md">
                        {s.visual}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300">{s.explanation}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TOOL 3: FRACTION VISUALIZER */}
      {activeSubTool === 'fractions' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            <div className="space-y-3 bg-slate-50 dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Numerator (Parts present)</span>
                <input
                  type="number"
                  min="1"
                  max={denominator}
                  value={numerator}
                  onChange={(e) => setNumerator(Math.min(denominator, Math.max(1, parseInt(e.target.value) || 1)))}
                  className="w-16 text-center font-black py-1 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg text-xs"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Denominator (Total equal slices)</span>
                <input
                  type="number"
                  min="2"
                  max="12"
                  value={denominator}
                  onChange={(e) => setDenominator(Math.max(2, parseInt(e.target.value) || 2))}
                  className="w-16 text-center font-black py-1 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg text-xs"
                />
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium pt-1">
                Fraction: <span className="font-extrabold text-emerald-600 dark:text-emerald-400">{numerator} out of {denominator}</span> slices ({Math.round((numerator/denominator)*100)}%)
              </p>
            </div>

            {/* Visual Pizza / Pie Chart */}
            <div className="flex flex-col items-center justify-center p-4 bg-slate-900 rounded-2xl text-white">
              <span className="text-xs font-mono text-emerald-400 mb-2 font-bold">Visual Pie Fraction Slices</span>
              <div className="flex flex-wrap max-w-[180px] gap-1 justify-center p-3 bg-slate-800 rounded-xl border border-slate-700">
                {Array.from({ length: denominator }).map((_, i) => (
                  <div
                    key={i}
                    className={`w-10 h-10 rounded-lg flex items-center justify-center text-xs font-extrabold transition-all ${
                      i < numerator
                        ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30'
                        : 'bg-slate-700 text-slate-400 border border-slate-600'
                    }`}
                  >
                    {i < numerator ? 'Slice' : 'Empty'}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TOOL 4: TELLING TIME GAUGE */}
      {activeSubTool === 'time' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
            <div className="space-y-3 bg-slate-50 dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Select Hour: {hours}</label>
                <input
                  type="range"
                  min="1"
                  max="12"
                  value={hours}
                  onChange={(e) => setHours(parseInt(e.target.value))}
                  className="w-full accent-rose-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Select Minutes: {minutes}</label>
                <input
                  type="range"
                  min="0"
                  max="55"
                  step="5"
                  value={minutes}
                  onChange={(e) => setMinutes(parseInt(e.target.value))}
                  className="w-full accent-rose-500"
                />
              </div>
            </div>

            <div className="p-4 bg-slate-900 rounded-2xl text-white flex flex-col items-center justify-center space-y-2">
              <span className="text-xs font-mono text-rose-400 uppercase font-bold">Analog to Plain English Time</span>
              <div className="text-3xl font-black font-mono tracking-widest text-rose-400 bg-slate-800 px-4 py-2 rounded-xl border border-slate-700">
                {String(hours).padStart(2, '0')}:{String(minutes).padStart(2, '0')}
              </div>
              <p className="text-xs font-bold text-slate-300 text-center">
                "{minutes === 0 ? `${hours} o'clock sharp` : minutes === 15 ? `Quarter past ${hours}` : minutes === 30 ? `Half past ${hours}` : minutes === 45 ? `Quarter to ${hours + 1}` : `${minutes} minutes past ${hours}`}"
              </p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
