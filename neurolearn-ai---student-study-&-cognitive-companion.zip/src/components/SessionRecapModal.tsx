import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  Sparkles, 
  Battery, 
  Clock, 
  ArrowRight, 
  Brain, 
  Award,
  RotateCcw
} from 'lucide-react';
import { SessionRecapData } from '../types';
import { soundSynth } from '../utils/audio';

interface SessionRecapModalProps {
  recap: SessionRecapData | null;
  onClose: () => void;
  onStartNextTopic: (topic: string) => void;
}

export const SessionRecapModal: React.FC<SessionRecapModalProps> = ({ recap, onClose, onStartNextTopic }) => {
  if (!recap) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs">
        <motion.div
          initial={{ scale: 0.85, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.85, opacity: 0, y: 20 }}
          className="bg-white dark:bg-slate-900 border-2 border-emerald-500 rounded-2xl p-6 max-w-lg w-full shadow-2xl space-y-5"
        >
          {/* Header Banner */}
          <div className="text-center space-y-2">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-lg animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950 px-3 py-1 rounded-full">
              Focus Session Completed!
            </span>
            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
              Cognitive Session Recap
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Great momentum! Here is your study performance summary.
            </p>
          </div>

          {/* Key Metrics Stats */}
          <div className="grid grid-cols-3 gap-2">
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-center">
              <Clock className="w-4 h-4 text-emerald-600 dark:text-emerald-400 mx-auto mb-1" />
              <p className="text-base font-black text-emerald-950 dark:text-emerald-100">
                {recap.sessionTimeMinutes}m
              </p>
              <p className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300">
                Focused Time
              </p>
            </div>

            <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 text-center">
              <Battery className="w-4 h-4 text-indigo-600 dark:text-indigo-400 mx-auto mb-1" />
              <p className="text-base font-black text-indigo-950 dark:text-indigo-100">
                {recap.mentalBatteryRemaining}%
              </p>
              <p className="text-[10px] font-bold text-indigo-700 dark:text-indigo-300">
                Battery Left
              </p>
            </div>

            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 text-center">
              <Award className="w-4 h-4 text-amber-600 dark:text-amber-400 mx-auto mb-1" />
              <p className="text-base font-black text-amber-950 dark:text-amber-100">
                +{recap.xpEarned} XP
              </p>
              <p className="text-[10px] font-bold text-amber-700 dark:text-amber-300">
                Scholar Bonus
              </p>
            </div>
          </div>

          {/* Concepts Mastered */}
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 uppercase tracking-wider">
              <Brain className="w-4 h-4 text-emerald-500" />
              Key Concepts Studied & Mastered
            </h4>
            <div className="flex flex-wrap gap-1.5">
              {recap.conceptsMastered.map((concept, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded-lg bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-[11px] font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1 shadow-2xs"
                >
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  {concept}
                </span>
              ))}
            </div>
          </div>

          {/* Next Logical Topic Recommendation */}
          <div className="p-3.5 rounded-xl bg-gradient-to-r from-indigo-900 to-slate-900 border border-indigo-700 text-white space-y-1.5">
            <div className="flex items-center space-x-2 text-indigo-300 text-[10px] font-extrabold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              Suggested Next Study Topic
            </div>
            <p className="text-xs font-bold text-white">
              {recap.suggestedNextTopic}
            </p>
            <p className="text-[10px] text-indigo-200">
              Continuing this lesson now maximizes long-term memory retention by 42%.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2 pt-2">
            <button
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs transition-all"
            >
              Take a 5-Min Break
            </button>

            <button
              onClick={() => {
                onStartNextTopic(recap.suggestedNextTopic);
                onClose();
              }}
              className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs shadow-md flex items-center justify-center space-x-1.5 transition-all"
            >
              <span>Start Next Topic</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
