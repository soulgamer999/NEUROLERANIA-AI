import React from 'react';
import { 
  Brain, 
  Sparkles, 
  Volume2, 
  VolumeX, 
  Type, 
  Sun, 
  Moon, 
  Eye, 
  Smartphone, 
  Monitor, 
  Tablet, 
  HeartHandshake,
  Settings,
  Accessibility,
  Maximize2,
  Minimize2,
  Zap
} from 'lucide-react';
import { UserPreferences, DeviceViewport, DisplayTheme, ActiveUserProfile, LearningCondition } from '../types';
import { soundSynth } from '../utils/audio';
import { CONDITION_PROFILES } from './NeuroConditionSelector';

interface HeaderProps {
  prefs: UserPreferences;
  onUpdatePrefs: (updated: Partial<UserPreferences>) => void;
  viewport: DeviceViewport;
  onChangeViewport: (v: DeviceViewport) => void;
  onOpenMindCheck: () => void;
  activeNoise: 'brown' | 'binaural' | 'rain' | 'off';
  onChangeNoise: (type: 'brown' | 'binaural' | 'rain' | 'off') => void;
  isDeepFocusMode?: boolean;
  onToggleDeepFocus?: () => void;
  currentProfile: ActiveUserProfile;
  onOpenProfileModal: () => void;
  onQuickSwitchCondition: (condition: LearningCondition) => void;
}

export const Header: React.FC<HeaderProps> = ({
  prefs,
  onUpdatePrefs,
  viewport,
  onChangeViewport,
  onOpenMindCheck,
  activeNoise,
  onChangeNoise,
  isDeepFocusMode = false,
  onToggleDeepFocus,
  currentProfile,
  onOpenProfileModal,
  onQuickSwitchCondition
}) => {
  const currentCond = CONDITION_PROFILES.find(p => p.id === prefs.activeCondition) || CONDITION_PROFILES[0];

  return (
    <header role="banner" aria-label="Application Navigation Header" className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-8 py-3 shadow-sm">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
        {/* Logo & Identity */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-indigo-600 dark:bg-indigo-500 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-indigo-200 dark:shadow-none shrink-0">
            <Brain className="w-5 h-5 text-white" aria-hidden="true" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">
                NeuroLearn AI
              </h1>
              <span className="text-[10px] text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/80 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider border border-indigo-100 dark:border-indigo-800">
                Study Expert
              </span>
            </div>
            <p className="text-[10px] text-indigo-600 dark:text-indigo-400 font-semibold uppercase tracking-wider">
              Psychological Study & Adaptive Learning
            </p>
          </div>
        </div>

        {/* Action Controls & Preferences */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3" role="toolbar" aria-label="Accessibility and preference controls">
          {/* Deep Focus Mode Toggle */}
          {onToggleDeepFocus && (
            <button
              onClick={() => {
                soundSynth.playTone(isDeepFocusMode ? 450 : 700, 'sine', 0.15);
                onToggleDeepFocus();
              }}
              aria-pressed={isDeepFocusMode}
              title={isDeepFocusMode ? "Exit Minimalist Deep Focus Mode" : "Switch to Distraction-Free Minimalist Deep Focus Mode"}
              className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all flex items-center space-x-1.5 shadow-sm active:scale-95 ${
                isDeepFocusMode
                  ? 'bg-amber-500 text-slate-950 border border-amber-300 ring-2 ring-amber-400 ring-offset-1 animate-pulse'
                  : 'bg-indigo-900 dark:bg-indigo-950 hover:bg-indigo-800 text-indigo-100 border border-indigo-700'
              }`}
            >
              {isDeepFocusMode ? <Minimize2 className="w-4 h-4 text-slate-950" /> : <Maximize2 className="w-4 h-4 text-amber-300" />}
              <span>{isDeepFocusMode ? 'Exit Deep Focus' : 'Deep Focus Mode'}</span>
            </button>
          )}

          {/* Screen Reader Optimization Mode Toggle */}
          <button
            onClick={() => onUpdatePrefs({ screenReaderOptimization: !prefs.screenReaderOptimization })}
            aria-pressed={prefs.screenReaderOptimization}
            aria-label={`Screen Reader Optimization Mode: ${prefs.screenReaderOptimization ? 'Enabled' : 'Disabled'}. Adds explicit ARIA landmarks and simplified navigation paths.`}
            title="Toggle Screen Reader Optimization & Simplified Navigation Mode"
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all flex items-center space-x-1.5 ${
              prefs.screenReaderOptimization
                ? 'bg-emerald-600 text-white border-emerald-500 shadow-md shadow-emerald-200 dark:shadow-none ring-2 ring-emerald-400 ring-offset-1'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
            }`}
          >
            <Accessibility className="w-4 h-4 text-emerald-400 dark:text-emerald-300 animate-pulse" />
            <span className="font-bold">
              SR Mode {prefs.screenReaderOptimization ? 'ON' : 'OFF'}
            </span>
          </button>

          {/* Mindset Check-In Button */}
          <button
            onClick={onOpenMindCheck}
            aria-label="Open Psychological Mindset Check-In Modal"
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-200 dark:shadow-none transition-all active:scale-95"
          >
            <HeartHandshake className="w-4 h-4" aria-hidden="true" />
            <span>Mind Check-In</span>
          </button>

          {/* Ambient Sound Selector */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-lg p-1 border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => onChangeNoise(activeNoise === 'off' ? 'brown' : 'off')}
              title="Toggle Ambient Focus Noise"
              className={`p-1.5 rounded-md text-xs font-medium transition-colors flex items-center space-x-1 ${
                activeNoise !== 'off' 
                  ? 'bg-amber-500 text-white shadow-xs' 
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}
            >
              {activeNoise !== 'off' ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
              <span className="capitalize text-[11px]">{activeNoise === 'off' ? 'Sound' : activeNoise}</span>
            </button>
            {activeNoise !== 'off' && (
              <select
                value={activeNoise}
                onChange={(e) => onChangeNoise(e.target.value as any)}
                className="bg-transparent text-[11px] text-slate-700 dark:text-slate-300 font-medium px-1 outline-none"
              >
                <option value="brown">Brown Noise</option>
                <option value="binaural">Alpha Waves (40Hz)</option>
                <option value="rain">Soft Rain</option>
              </select>
            )}
          </div>

          {/* Dyslexic Font Toggle */}
          <button
            onClick={() => onUpdatePrefs({ dyslexicFont: !prefs.dyslexicFont })}
            title="Toggle Dyslexia-Friendly Spaced Font"
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-colors flex items-center space-x-1 ${
              prefs.dyslexicFont
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
            }`}
          >
            <Type className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Lexie Font</span>
          </button>

          {/* Theme Selector */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-lg p-1 border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => onUpdatePrefs({ theme: 'light' })}
              title="Light Vibrant Theme"
              className={`p-1.5 rounded-md ${prefs.theme === 'light' ? 'bg-white text-indigo-600 shadow-xs font-semibold' : 'text-slate-500 dark:text-slate-400'}`}
            >
              <Sun className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onUpdatePrefs({ theme: 'dyslexia-warm' })}
              title="Warm Cream Theme"
              className={`p-1.5 rounded-md ${prefs.theme === 'dyslexia-warm' ? 'bg-amber-100 text-amber-900 shadow-xs font-semibold' : 'text-slate-500 dark:text-slate-400'}`}
            >
              <Eye className="w-3.5 h-3.5 text-amber-600" />
            </button>
            <button
              onClick={() => onUpdatePrefs({ theme: 'dark-slate' })}
              title="Dark Slate Theme"
              className={`p-1.5 rounded-md ${prefs.theme === 'dark-slate' ? 'bg-slate-700 text-teal-300 shadow-xs font-semibold' : 'text-slate-500 dark:text-slate-400'}`}
            >
              <Moon className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* QUICK BRAIN CONDITION SWITCHER DROPDOWN */}
          <div className="flex items-center bg-indigo-50 dark:bg-indigo-950/80 rounded-xl p-1 border border-indigo-200 dark:border-indigo-800/80">
            <span className="text-[11px] font-bold text-indigo-700 dark:text-indigo-300 pl-2 pr-1 flex items-center space-x-1 shrink-0">
              <Brain className="w-3.5 h-3.5 text-indigo-500" />
              <span className="hidden lg:inline">Brain Mode:</span>
            </span>
            <select
              value={prefs.activeCondition}
              onChange={(e) => {
                const nextCond = e.target.value as LearningCondition;
                soundSynth.playTone(600, 'sine', 0.15);
                onQuickSwitchCondition(nextCond);
              }}
              className="bg-white dark:bg-slate-900 text-xs font-black text-indigo-900 dark:text-indigo-100 py-1 px-2 rounded-lg border border-indigo-200 dark:border-indigo-700 outline-none cursor-pointer shadow-2xs"
            >
              {CONDITION_PROFILES.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </select>
          </div>

          <div className="hidden md:block h-6 w-[1px] bg-slate-200 dark:bg-slate-700"></div>

          {/* User Profile Avatar & Switcher Portal Trigger */}
          <button
            onClick={onOpenProfileModal}
            className="flex items-center space-x-2 p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 transition-all active:scale-95"
            title="Click to Switch Profile / Teacher Admin Login"
          >
            <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
              currentProfile.role === 'teacher' ? 'bg-amber-400 text-slate-950' : 'bg-indigo-600 text-white'
            }`}>
              {currentProfile.role === 'teacher' ? '🎓' : ('avatarIcon' in currentProfile ? currentProfile.avatarIcon : '👦')}
            </div>
            <div className="text-left hidden sm:block pr-1">
              <span className="block text-[11px] font-black text-slate-900 dark:text-white leading-none">
                {currentProfile.name}
              </span>
              <span className="block text-[9px] font-extrabold uppercase text-indigo-600 dark:text-indigo-400">
                {currentProfile.role === 'teacher' ? 'Teacher / Admin' : 'Student Mode'}
              </span>
            </div>
          </button>
        </div>
      </div>
    </header>
  );
};

