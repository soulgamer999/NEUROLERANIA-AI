import React, { useState } from 'react';
import { 
  PenTool, 
  Mic, 
  MicOff, 
  Sparkles, 
  FileText, 
  Check, 
  Copy, 
  Wand2, 
  HelpCircle, 
  RotateCcw,
  BookOpen,
  Send
} from 'lucide-react';
import { motion } from 'motion/react';

interface DysgraphiaScribeProps {
  className?: string;
}

export const DysgraphiaScribe: React.FC<DysgraphiaScribeProps> = ({ className = '' }) => {
  const [rawThought, setRawThought] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [polishedOutput, setPolishedOutput] = useState<{
    structuredParagraph: string;
    bulletPoints: string[];
    spellingTips: { word: string; tip: string }[];
    sentenceStarters: string[];
  } | null>(null);
  const [copied, setCopied] = useState(false);

  // Simulated Voice Dictation toggle
  const toggleListening = () => {
    if (!isListening) {
      setIsListening(true);
      // Simulate spoken dictation input
      setTimeout(() => {
        setRawThought('um i think photosynthesis happens when plants take sunlight and water and then make food and oxygen and it happens in green leaves');
        setIsListening(false);
      }, 3000);
    } else {
      setIsListening(false);
    }
  };

  const handlePolishThoughts = async () => {
    if (!rawThought.trim()) return;
    setIsProcessing(true);
    try {
      // Simulate or call AI to transform raw thoughts into polished sentences
      setTimeout(() => {
        setPolishedOutput({
          structuredParagraph: "Photosynthesis is the essential process where green plants transform sunlight, carbon dioxide, and water into chemical energy and oxygen inside their leaves.",
          bulletPoints: [
            "Input 1: Sunlight absorbed by chlorophyll in chloroplasts.",
            "Input 2: Water absorbed through roots.",
            "Output: Glucose (food) and fresh Oxygen gas released into the air."
          ],
          spellingTips: [
            { word: "Photosynthesis", tip: "Photo = Light, Synthesis = Putting together" },
            { word: "Chlorophyll", tip: "Chloro = Green pigment in plant cells" },
            { word: "Oxygen", tip: "O-X-Y-G-E-N (Remember O2)" }
          ],
          sentenceStarters: [
            "To begin with, green plants require...",
            "In conclusion, the primary output of photosynthesis is..."
          ]
        });
        setIsProcessing(false);
      }, 1000);
    } catch (e) {
      setIsProcessing(false);
    }
  };

  const handleCopy = () => {
    if (polishedOutput) {
      navigator.clipboard.writeText(polishedOutput.structuredParagraph);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div role="region" aria-label="Dysgraphia Voice Scribe & Writing Assistant" className={`bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm ${className}`}>
      
      {/* Header */}
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center space-x-2.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-500 to-pink-600 flex items-center justify-center text-white shadow-md">
            <PenTool className="w-5 h-5" aria-hidden="true" />
          </div>
          <div>
            <h2 className="text-base font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
              Dysgraphia Voice Scribe & Writing Assistant
              <span className="text-[10px] bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 font-bold px-2 py-0.5 rounded-md border border-purple-300/50">
                Thought to Sentence Transformer
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Converts raw spoken ideas or fragmented thoughts into structured, beautifully formatted sentences without physical handwriting strain.
            </p>
          </div>
        </div>
      </div>

      {/* Voice & Raw Input Area */}
      <div className="space-y-3 mb-5">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
            Speak or Type Your Raw Thoughts / Fragmented Ideas:
          </label>
          <button
            onClick={toggleListening}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all ${
              isListening
                ? 'bg-rose-500 text-white animate-pulse shadow-md shadow-rose-500/30'
                : 'bg-purple-500 hover:bg-purple-600 text-white shadow-sm'
            }`}
          >
            {isListening ? (
              <>
                <MicOff className="w-3.5 h-3.5" />
                <span>Listening... (Speak Now)</span>
              </>
            ) : (
              <>
                <Mic className="w-3.5 h-3.5" />
                <span>Voice Dictation</span>
              </>
            )}
          </button>
        </div>

        <div className="relative">
          <textarea
            rows={3}
            value={rawThought}
            onChange={(e) => setRawThought(e.target.value)}
            placeholder="Type or speak freely... e.g., 'plants take sunlight and water and then make food and oxygen'"
            className="w-full p-3.5 text-xs font-medium bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none resize-none text-slate-900 dark:text-slate-100"
          />
        </div>

        <div className="flex justify-end gap-2">
          <button
            onClick={handlePolishThoughts}
            disabled={!rawThought.trim() || isProcessing}
            className="px-5 py-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-extrabold text-xs rounded-xl transition-all shadow-md flex items-center space-x-2 disabled:opacity-50"
          >
            <Wand2 className="w-4 h-4" />
            <span>{isProcessing ? 'Polishing Sentence Structure...' : 'Polish Thoughts Into Structured Text'}</span>
          </button>
        </div>
      </div>

      {/* POLISHED OUTPUT CARD */}
      {polishedOutput && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800"
        >
          {/* Formatted Paragraph */}
          <div className="p-4 bg-purple-50/60 dark:bg-purple-950/40 rounded-2xl border border-purple-200 dark:border-purple-900/60 relative">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-black uppercase tracking-wider text-purple-700 dark:text-purple-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-500" />
                Polished Written Paragraph:
              </span>
              <button
                onClick={handleCopy}
                className="flex items-center space-x-1 px-2.5 py-1 bg-white dark:bg-slate-800 text-purple-700 dark:text-purple-300 text-[11px] font-bold rounded-lg border border-purple-200 dark:border-purple-800 hover:bg-purple-100"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy Text'}</span>
              </button>
            </div>
            <p className="text-sm font-semibold leading-relaxed text-slate-800 dark:text-slate-100">
              {polishedOutput.structuredParagraph}
            </p>
          </div>

          {/* Bulleted Points & Sentence Starters */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Structured Bullets */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
              <h4 className="text-xs font-black uppercase text-purple-600 dark:text-purple-400">
                Key Thought Outline:
              </h4>
              <ul className="space-y-1.5">
                {polishedOutput.bulletPoints.map((bp, i) => (
                  <li key={i} className="text-xs text-slate-700 dark:text-slate-300 flex items-start gap-1.5">
                    <span className="text-purple-500 font-bold">•</span>
                    <span>{bp}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Spelling Helper */}
            <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
              <h4 className="text-xs font-black uppercase text-pink-600 dark:text-pink-400">
                Spelling & Etymology Hooks:
              </h4>
              <div className="space-y-1.5">
                {polishedOutput.spellingTips.map((st, i) => (
                  <div key={i} className="text-xs bg-white dark:bg-slate-700 p-2 rounded-lg border border-slate-200 dark:border-slate-600">
                    <span className="font-extrabold text-slate-900 dark:text-white">{st.word}:</span>{' '}
                    <span className="text-slate-600 dark:text-slate-300">{st.tip}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      )}

    </div>
  );
};
