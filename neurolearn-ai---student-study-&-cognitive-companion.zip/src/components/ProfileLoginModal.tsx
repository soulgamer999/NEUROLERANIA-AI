import React, { useState } from 'react';
import { 
  GraduationCap, 
  Users, 
  ShieldCheck, 
  LogIn, 
  CheckCircle2, 
  Sparkles, 
  UserCheck, 
  X, 
  Lock, 
  Brain, 
  Layers 
} from 'lucide-react';
import { StudentProfileData, TeacherProfileData, ActiveUserProfile } from '../types';
import { CONDITION_PROFILES } from './NeuroConditionSelector';

interface ProfileLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  teacher: TeacherProfileData;
  students: StudentProfileData[];
  currentProfile: ActiveUserProfile;
  onSelectProfile: (profileId: string) => void;
}

export const ProfileLoginModal: React.FC<ProfileLoginModalProps> = ({
  isOpen,
  onClose,
  teacher,
  students,
  currentProfile,
  onSelectProfile
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fade-in">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-xl w-full shadow-2xl space-y-5 my-8">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold text-xl shadow-lg shadow-indigo-200 dark:shadow-none">
              <Brain className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900 dark:text-white">
                NeuroLearn Profile Portal
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Switch between Teacher Admin profile & isolated Student profiles
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Active Badge */}
        <div className="p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-100 dark:border-indigo-900 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-300">Logged in as:</span>
            <span className="text-xs font-black text-indigo-700 dark:text-indigo-300 flex items-center space-x-1">
              <span>{currentProfile.role === 'teacher' ? '🎓' : 'avatarIcon' in currentProfile ? currentProfile.avatarIcon : '👦'}</span>
              <span>{currentProfile.name}</span>
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-indigo-200 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200">
              {currentProfile.role === 'teacher' ? 'Admin / Mentor' : 'Isolated Student'}
            </span>
          </div>
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
        </div>

        {/* SECTION 1: TEACHER / MENTOR (ADMIN PROFILE) */}
        <div className="space-y-2">
          <label className="text-xs font-extrabold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center space-x-1.5">
            <ShieldCheck className="w-4 h-4 text-amber-500" />
            <span>1. Educator / Admin Profile:</span>
          </label>

          <button
            onClick={() => {
              onSelectProfile(teacher.id);
              onClose();
            }}
            className={`w-full p-4 rounded-2xl border text-left transition-all flex items-center justify-between ${
              currentProfile.id === teacher.id
                ? 'border-amber-400 bg-amber-50/60 dark:bg-amber-950/40 ring-2 ring-amber-400/40 shadow-sm'
                : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-lg shadow-sm">
                🎓
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h4 className="text-xs font-black text-slate-900 dark:text-white">
                    {teacher.name}
                  </h4>
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-amber-400/20 text-amber-700 dark:text-amber-300 border border-amber-400/30">
                    Teacher Admin
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {teacher.schoolName} • Manage student roster, inspect AI reactions & create profiles
                </p>
              </div>
            </div>

            {currentProfile.id === teacher.id ? (
              <span className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center space-x-1">
                <UserCheck className="w-4 h-4" />
                <span>Active</span>
              </span>
            ) : (
              <span className="px-3 py-1 bg-slate-900 text-amber-400 font-bold text-xs rounded-xl">
                Sign In as Admin
              </span>
            )}
          </button>
        </div>

        {/* SECTION 2: CLASS STUDENT PROFILES (ISOLATED DATA) */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-extrabold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center space-x-1.5">
              <Users className="w-4 h-4 text-indigo-500" />
              <span>2. Class Student Profiles ({students.length}):</span>
            </label>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 flex items-center space-x-1">
              <Lock className="w-3 h-3 text-emerald-500" />
              <span>Isolated Data & AI Reactions</span>
            </span>
          </div>

          <div className="max-h-56 overflow-y-auto space-y-2 pr-1">
            {students.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400 italic p-3 text-center border border-dashed rounded-xl">
                No students enrolled yet. Log in as Teacher Admin to create student profiles.
              </p>
            ) : (
              students.map((student) => {
                const cond = CONDITION_PROFILES.find(p => p.id === student.primaryCondition) || CONDITION_PROFILES[0];
                const isActive = currentProfile.id === student.id;

                return (
                  <button
                    key={student.id}
                    onClick={() => {
                      onSelectProfile(student.id);
                      onClose();
                    }}
                    className={`w-full p-3 rounded-2xl border text-left transition-all flex items-center justify-between ${
                      isActive
                        ? 'border-indigo-500 bg-indigo-50/60 dark:bg-indigo-950/60 ring-2 ring-indigo-500/40 shadow-sm'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg font-bold ${student.avatarBg}`}>
                        {student.avatarIcon}
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                            {student.name}
                          </h4>
                          <span className="text-[10px] text-slate-500 font-semibold">
                            ({student.gradeLevel})
                          </span>
                        </div>
                        <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold border inline-flex items-center space-x-1 mt-0.5 ${cond.badgeColor}`}>
                          <span>{cond.title}</span>
                        </span>
                      </div>
                    </div>

                    {isActive ? (
                      <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 flex items-center space-x-1">
                        <UserCheck className="w-4 h-4" />
                        <span>Active</span>
                      </span>
                    ) : (
                      <span className="px-3 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs">
                        Switch
                      </span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Data Security Guarantee Callout */}
        <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-[11px] text-slate-600 dark:text-slate-400 flex items-center space-x-2">
          <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
          <span>
            <strong>Data Privacy Isolation:</strong> Each student profile's flashcards, quiz records, mental battery scores, and AI reactions are stored independently. Students cannot access other students' profiles.
          </span>
        </div>

        <div className="flex justify-end pt-2 border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 text-white font-bold text-xs rounded-xl"
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
