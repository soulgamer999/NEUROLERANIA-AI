// Bionic Reading and Dyslexia Text Formatting Helpers

export interface BionicWord {
  boldPart: string;
  regularPart: string;
}

export function formatBionicText(text: string): BionicWord[] {
  if (!text) return [];
  const words = text.split(/(\s+)/); // keep spaces

  return words.map(word => {
    // If it's pure whitespace or punctuation
    if (/^\s+$/.test(word) || word.length <= 1) {
      return { boldPart: word, regularPart: '' };
    }

    // Determine how many letters to bold based on word length
    const len = word.length;
    let boldLength = 1;
    if (len > 3 && len <= 6) boldLength = 2;
    else if (len > 6 && len <= 9) boldLength = 3;
    else if (len > 9) boldLength = 4;

    return {
      boldPart: word.slice(0, boldLength),
      regularPart: word.slice(boldLength)
    };
  });
}

// Convert markdown text to clean paragraphs
export function parseParagraphs(text: string): string[] {
  if (!text) return [];
  return text
    .split(/\n\s*\n/)
    .map(p => p.trim())
    .filter(Boolean);
}
