// Audio Web API helper for ambient sounds, white noise, binaural beats, and TTS

class SoundSynthesizer {
  private ctx: AudioContext | null = null;
  private noiseNode: AudioNode | null = null;
  private gainNode: GainNode | null = null;
  private isPlayingNoise = false;
  private currentNoiseType: 'brown' | 'binaural' | 'rain' | 'off' = 'off';

  private initCtx() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public playAmbient(type: 'brown' | 'binaural' | 'rain' | 'off', volume = 0.15) {
    this.stopAmbient();
    if (type === 'off') return;

    this.initCtx();
    if (!this.ctx) return;

    this.currentNoiseType = type;
    this.gainNode = this.ctx.createGain();
    this.gainNode.gain.value = volume;
    this.gainNode.connect(this.ctx.destination);

    const bufferSize = 2 * this.ctx.sampleRate;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);

    if (type === 'brown') {
      let lastOut = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        output[i] = (lastOut + 0.02 * white) / 1.02;
        lastOut = output[i];
        output[i] *= 3.5; // Gain boost
      }
      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;
      whiteNoise.connect(this.gainNode);
      whiteNoise.start();
      this.noiseNode = whiteNoise;
    } else if (type === 'rain') {
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        output[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        output[i] *= 0.11;
        b6 = white * 0.115926;
      }
      const rainSource = this.ctx.createBufferSource();
      rainSource.buffer = noiseBuffer;
      rainSource.loop = true;
      rainSource.connect(this.gainNode);
      rainSource.start();
      this.noiseNode = rainSource;
    } else if (type === 'binaural') {
      // 200 Hz left ear, 210 Hz right ear (10 Hz Alpha wave for relaxed focus)
      const oscL = this.ctx.createOscillator();
      const oscR = this.ctx.createOscillator();
      const merger = this.ctx.createChannelMerger(2);

      oscL.frequency.value = 200;
      oscR.frequency.value = 210;

      oscL.connect(merger, 0, 0); // Left channel
      oscR.connect(merger, 0, 1); // Right channel

      merger.connect(this.gainNode);
      oscL.start();
      oscR.start();

      this.noiseNode = merger;
    }

    this.isPlayingNoise = true;
  }

  public setVolume(vol: number) {
    if (this.gainNode) {
      this.gainNode.gain.setValueAtTime(Math.max(0, Math.min(1, vol)), this.ctx?.currentTime || 0);
    }
  }

  public playTone(
    freq = 440,
    arg2?: number | OscillatorType,
    arg3?: number | OscillatorType,
    volume = 0.15
  ) {
    let duration = 0.15;
    let type: OscillatorType = 'sine';

    if (typeof arg2 === 'string') {
      type = arg2 as OscillatorType;
      if (typeof arg3 === 'number') {
        duration = arg3;
      }
    } else if (typeof arg2 === 'number') {
      duration = arg2;
      if (typeof arg3 === 'string') {
        type = arg3 as OscillatorType;
      }
    }

    try {
      this.initCtx();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
      gain.gain.setValueAtTime(volume, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch (e) {
      console.warn("Play tone failed", e);
    }
  }

  public stopAmbient() {
    if (this.noiseNode) {
      try {
        if ('stop' in this.noiseNode && typeof (this.noiseNode as any).stop === 'function') {
          (this.noiseNode as any).stop();
        }
      } catch (e) {
        // ignore
      }
      this.noiseNode = null;
    }
    this.isPlayingNoise = false;
    this.currentNoiseType = 'off';
  }

  public getCurrentNoiseType() {
    return this.currentNoiseType;
  }

  // Chime sound for quiz success or session completion
  public playChime(success = true) {
    try {
      this.initCtx();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(success ? 523.25 : 300, this.ctx.currentTime); // C5 or lower
      if (success) {
        osc.frequency.exponentialRampToValueAtTime(659.25, this.ctx.currentTime + 0.15); // E5
        osc.frequency.exponentialRampToValueAtTime(783.99, this.ctx.currentTime + 0.3); // G5
      }
      gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.4);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.45);
    } catch (e) {
      console.warn("Chime failed", e);
    }
  }
}

export const soundSynth = new SoundSynthesizer();

// Web Speech API wrapper for multi-sensory reading support
export const speakText = (text: string, rate = 1.0, onEnd?: () => void): SpeechSynthesisUtterance | null => {
  if (!('speechSynthesis' in window)) {
    alert("Speech synthesis is not supported on this browser.");
    return null;
  }

  window.speechSynthesis.cancel(); // Stop ongoing speech

  const cleanText = text.replace(/[*#_`~]/g, ''); // strip markdown
  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.rate = rate;
  utterance.pitch = 1.0;

  // Try picking a natural voice
  const voices = window.speechSynthesis.getVoices();
  const preferredVoice = voices.find(v => v.lang.includes('en') && (v.name.includes('Google') || v.name.includes('Natural') || v.name.includes('Samantha') || v.name.includes('Daniel'))) || voices[0];
  if (preferredVoice) {
    utterance.voice = preferredVoice;
  }

  if (onEnd) {
    utterance.onend = onEnd;
    utterance.onerror = onEnd;
  }

  window.speechSynthesis.speak(utterance);
  return utterance;
};

export const stopSpeech = () => {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
};
