import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Brain, 
  Zap, 
  Calendar, 
  Layers, 
  HeartHandshake, 
  Sparkles, 
  Smartphone, 
  ShieldAlert,
  Volume2,
  Check,
  Type,
  Calculator,
  PenTool,
  Captions,
  MousePointer,
  Eye,
  SlidersHorizontal,
  Accessibility,
  TrendingUp,
  Trophy,
  Minimize2,
  Maximize2
} from 'lucide-react';
import { Header } from './components/Header';
import { PlatformFrame } from './components/PlatformFrame';
import { MindsetCheckModal } from './components/MindsetCheckModal';
import { RobotTeacherPresentation } from './components/RobotTeacherPresentation';
import { StressAnxietyHub } from './components/StressAnxietyHub';
import { DyslexiaTransformer } from './components/DyslexiaTransformer';
import { SpecialistChat } from './components/SpecialistChat';
import { FocusTimer } from './components/FocusTimer';
import { FocusStreakCounter } from './components/FocusStreakCounter';
import { StudyPlanGenerator } from './components/StudyPlanGenerator';
import { DyscalculiaVisualizer } from './components/DyscalculiaVisualizer';
import { DysgraphiaScribe } from './components/DysgraphiaScribe';
import { ApdCaptionsReader } from './components/ApdCaptionsReader';
import { DynamicStudyBackground } from './components/DynamicStudyBackground';
import { CognitivePerformanceDashboard } from './components/CognitivePerformanceDashboard';
import { VoiceCommandNavigator } from './components/VoiceCommandNavigator';
import { MilestonesSystem } from './components/MilestonesSystem';
import { SessionRecapModal } from './components/SessionRecapModal';
import { AIStudyBuddyOverlay } from './components/AIStudyBuddyOverlay';
import { PostureAwarenessReminder } from './components/PostureAwarenessReminder';
import { NeuroConditionSelector, CONDITION_PROFILES } from './components/NeuroConditionSelector';
import { TeacherAdminDashboard } from './components/TeacherAdminDashboard';
import { ProfileLoginModal } from './components/ProfileLoginModal';
import { 
  UserPreferences, 
  DeviceViewport, 
  Flashcard, 
  MindsetDiagnosis, 
  SessionRecapData,
  TeacherProfileData,
  StudentProfileData,
  ActiveUserProfile,
  LearningCondition 
} from './types';
import { soundSynth } from './utils/audio';

const DEFAULT_TEACHER_PROFILE: TeacherProfileData = {
  id: 'teacher-admin-1',
  name: 'Prof. Sarah Jenkins',
  role: 'teacher',
  email: 'sjenkins@neurolearn.edu',
  schoolName: 'Oakridge Academy & Inclusive Learning Hub',
  avatarBg: 'bg-amber-400 text-slate-950'
};

const DEFAULT_STUDENT_PROFILES: StudentProfileData[] = [
  {
    id: 'student-alex',
    name: 'Alex Rivera',
    role: 'student',
    gradeLevel: 'Grade 5',
    primaryCondition: 'dyslexia',
    avatarIcon: '📚',
    avatarBg: 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-200',
    notes: 'Focus on phonics chunking and Bionic reader mode.',
    createdAt: new Date().toLocaleDateString(),
    prefs: {
      activeCondition: 'dyslexia',
      dyslexicFont: true,
      bionicHighlight: true,
      fontSize: 'normal',
      letterSpacing: 'wide',
      lineHeight: 'relaxed',
      theme: 'light',
      speechSpeed: 1.0,
      speechVoice: '',
      soundEffectVolume: 0.15,
      mathVisualizerEnabled: true,
      voiceTypingAssistant: false,
      audioClosedCaptions: false,
      largeTouchTargets: false,
      explicitTextLabels: false,
      screenReaderOptimization: false
    },
    savedFlashcards: [
      { id: 'f-1', question: 'What is Mitochondria?', answer: 'The powerhouse of the cell producing ATP energy.', hint: 'Think of cellular battery' }
    ],
    aiReactions: [
      {
        id: 'rx-1',
        timestamp: '10:15 AM',
        topic: 'Cell Biology',
        persona: 'Encouraging',
        userPromptOrQuestion: 'How does cell energy work?',
        aiResponseSnippet: 'Great question Alex! Mitochondria convert glucose into ATP energy for your cells.',
        detectedEmotion: 'Curious & Encouraged'
      }
    ],
    quizScores: [
      { id: 'q-1', topic: 'Cell Biology Quiz', scorePct: 90, date: new Date().toLocaleDateString() }
    ],
    mentalBatteryPct: 85
  },
  {
    id: 'student-maya',
    name: 'Maya Lin',
    role: 'student',
    gradeLevel: 'Grade 7',
    primaryCondition: 'dyscalculia',
    avatarIcon: '🧮',
    avatarBg: 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200',
    notes: 'Requires visual dot counters and step-by-step formula breakdowns.',
    createdAt: new Date().toLocaleDateString(),
    prefs: {
      activeCondition: 'dyscalculia',
      dyslexicFont: false,
      bionicHighlight: true,
      fontSize: 'normal',
      letterSpacing: 'wide',
      lineHeight: 'relaxed',
      theme: 'light',
      speechSpeed: 1.0,
      speechVoice: '',
      soundEffectVolume: 0.15,
      mathVisualizerEnabled: true,
      voiceTypingAssistant: false,
      audioClosedCaptions: false,
      largeTouchTargets: false,
      explicitTextLabels: false,
      screenReaderOptimization: false
    },
    savedFlashcards: [
      { id: 'f-2', question: 'Fraction addition rule', answer: 'Find common denominator before adding numerators.', hint: 'Visual slice circles' }
    ],
    aiReactions: [
      {
        id: 'rx-2',
        timestamp: '11:30 AM',
        topic: 'Fraction Addition',
        persona: 'Playful',
        userPromptOrQuestion: 'Why do we need a common denominator?',
        aiResponseSnippet: 'Imagine slice sizes of a pizza Maya! We must make all slices the same size before counting!',
        detectedEmotion: 'Enthusiastic'
      }
    ],
    quizScores: [
      { id: 'q-2', topic: 'Fraction Math Step Check', scorePct: 80, date: new Date().toLocaleDateString() }
    ],
    mentalBatteryPct: 75
  },
  {
    id: 'student-ethan',
    name: 'Ethan Vance',
    role: 'student',
    gradeLevel: 'Grade 6',
    primaryCondition: 'dysgraphia',
    avatarIcon: '✍️',
    avatarBg: 'bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-200',
    notes: 'Uses voice dictation and thought polish scribe.',
    createdAt: new Date().toLocaleDateString(),
    prefs: {
      activeCondition: 'dysgraphia',
      dyslexicFont: false,
      bionicHighlight: true,
      fontSize: 'normal',
      letterSpacing: 'wide',
      lineHeight: 'relaxed',
      theme: 'light',
      speechSpeed: 1.0,
      speechVoice: '',
      soundEffectVolume: 0.15,
      mathVisualizerEnabled: false,
      voiceTypingAssistant: true,
      audioClosedCaptions: false,
      largeTouchTargets: false,
      explicitTextLabels: false,
      screenReaderOptimization: false
    },
    savedFlashcards: [],
    aiReactions: [
      {
        id: 'rx-3',
        timestamp: '01:10 PM',
        topic: 'Essay Outline Scribe',
        persona: 'Direct',
        userPromptOrQuestion: 'Clean up my spoken thoughts about climate change.',
        aiResponseSnippet: 'Transformed your spoken dictation into 3 clear bullet arguments.',
        detectedEmotion: 'Relieved'
      }
    ],
    quizScores: [],
    mentalBatteryPct: 90
  }
];

export default function App() {
  // Teacher Admin & Isolated Student Profiles State
  const [teacherProfile] = useState<TeacherProfileData>(DEFAULT_TEACHER_PROFILE);
  const [studentsList, setStudentsList] = useState<StudentProfileData[]>(() => {
    const saved = localStorage.getItem('neurolearn_students_v2');
    return saved ? JSON.parse(saved) : DEFAULT_STUDENT_PROFILES;
  });
  const [activeProfileId, setActiveProfileId] = useState<string>(() => {
    const saved = localStorage.getItem('neurolearn_active_profile_id_v2');
    return saved || DEFAULT_TEACHER_PROFILE.id;
  });
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  // Active Profile Resolution
  const activeStudentProfile = studentsList.find(s => s.id === activeProfileId);
  const currentProfile: ActiveUserProfile = activeProfileId === teacherProfile.id
    ? teacherProfile
    : activeStudentProfile || teacherProfile;

  const [prefs, setPrefs] = useState<UserPreferences>(() => {
    if (activeStudentProfile) {
      return activeStudentProfile.prefs;
    }
    const saved = localStorage.getItem('neurolearn_prefs');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return {
      activeCondition: 'dyslexia',
      dyslexicFont: false,
      bionicHighlight: true,
      fontSize: 'normal',
      letterSpacing: 'wide',
      lineHeight: 'relaxed',
      theme: 'light',
      speechSpeed: 1.0,
      speechVoice: '',
      soundEffectVolume: 0.15,
      mathVisualizerEnabled: true,
      voiceTypingAssistant: true,
      audioClosedCaptions: true,
      largeTouchTargets: false,
      explicitTextLabels: false,
      screenReaderOptimization: false
    };
  });

  const [viewport, setViewport] = useState<DeviceViewport>('responsive');
  const [activeTab, setActiveTab] = useState<
    | 'teacher_admin'
    | 'robo_teacher'
    | 'condition_hub'
    | 'dyscalculia'
    | 'dysgraphia'
    | 'apd'
    | 'transformer'
    | 'stress_relief'
    | 'plan'
    | 'chat'
    | 'focustimer'
    | 'analytics'
    | 'milestones'
    | 'saved_decks'
  >(activeProfileId === DEFAULT_TEACHER_PROFILE.id ? 'teacher_admin' : 'robo_teacher');
  const [isMindCheckOpen, setIsMindCheckOpen] = useState(false);
  const [activeNoise, setActiveNoise] = useState<'brown' | 'binaural' | 'rain' | 'off'>('off');
  const [savedFlashcards, setSavedFlashcards] = useState<Flashcard[]>(() => {
    if (activeStudentProfile) {
      return activeStudentProfile.savedFlashcards;
    }
    const saved = localStorage.getItem('neurolearn_cards');
    return saved ? JSON.parse(saved) : [];
  });
  const [activeDiagnosis, setActiveDiagnosis] = useState<MindsetDiagnosis | null>(null);
  const [sessionRecap, setSessionRecap] = useState<SessionRecapData | null>(null);
  const [isBuddyOverlayVisible, setIsBuddyOverlayVisible] = useState(true);
  const [isDeepFocusMode, setIsDeepFocusMode] = useState(false);

  // Sync Profiles & Active Profile Data to localStorage
  useEffect(() => {
    localStorage.setItem('neurolearn_students_v2', JSON.stringify(studentsList));
  }, [studentsList]);

  useEffect(() => {
    localStorage.setItem('neurolearn_active_profile_id_v2', activeProfileId);
  }, [activeProfileId]);

  useEffect(() => {
    localStorage.setItem('neurolearn_prefs', JSON.stringify(prefs));
    if (activeStudentProfile) {
      setStudentsList(prev => prev.map(s => s.id === activeStudentProfile.id ? { ...s, prefs } : s));
    }
  }, [prefs]);

  useEffect(() => {
    localStorage.setItem('neurolearn_cards', JSON.stringify(savedFlashcards));
    if (activeStudentProfile) {
      setStudentsList(prev => prev.map(s => s.id === activeStudentProfile.id ? { ...s, savedFlashcards } : s));
    }
  }, [savedFlashcards]);

  // Profile Switching Handler
  const handleSelectProfile = (profileId: string) => {
    setActiveProfileId(profileId);
    if (profileId === teacherProfile.id) {
      setActiveTab('teacher_admin');
    } else {
      const selectedStudent = studentsList.find(s => s.id === profileId);
      if (selectedStudent) {
        setPrefs(selectedStudent.prefs);
        setSavedFlashcards(selectedStudent.savedFlashcards);
        setActiveTab('robo_teacher');
      }
    }
    soundSynth.playTone(520, 'sine', 0.2);
  };

  // Admin Actions for Teacher
  const handleAddStudent = (newStudentData: Omit<StudentProfileData, 'id' | 'createdAt'>) => {
    const newStudent: StudentProfileData = {
      ...newStudentData,
      id: `student-${Date.now()}`,
      createdAt: new Date().toLocaleDateString()
    };
    setStudentsList(prev => [...prev, newStudent]);
    soundSynth.playTone(700, 'sine', 0.2);
  };

  const handleDeleteStudent = (studentId: string) => {
    setStudentsList(prev => prev.filter(s => s.id !== studentId));
    if (activeProfileId === studentId) {
      setActiveProfileId(teacherProfile.id);
      setActiveTab('teacher_admin');
    }
    soundSynth.playTone(350, 'sine', 0.2);
  };

  // Quick Brain Condition Switching Handler
  const handleSwitchCondition = (newCondition: LearningCondition) => {
    const updates: Partial<UserPreferences> = {
      activeCondition: newCondition
    };
    if (newCondition === 'dyspraxia') {
      updates.largeTouchTargets = true;
    }
    if (newCondition === 'dyscalculia') {
      updates.mathVisualizerEnabled = true;
      if (activeTab === 'robo_teacher' || activeTab === 'condition_hub') {
        setActiveTab('dyscalculia');
      }
    }
    if (newCondition === 'dysgraphia') {
      updates.voiceTypingAssistant = true;
      if (activeTab === 'robo_teacher' || activeTab === 'condition_hub') {
        setActiveTab('dysgraphia');
      }
    }
    if (newCondition === 'apd') {
      updates.audioClosedCaptions = true;
      updates.speechSpeed = 0.75;
      if (activeTab === 'robo_teacher' || activeTab === 'condition_hub') {
        setActiveTab('apd');
      }
    }
    if (newCondition === 'nvld') {
      updates.explicitTextLabels = true;
    }
    if (newCondition === 'dyslexia') {
      updates.bionicHighlight = true;
      if (activeTab === 'robo_teacher' || activeTab === 'condition_hub') {
        setActiveTab('transformer');
      }
    }

    handleUpdatePrefs(updates);
    soundSynth.playTone(650, 'sine', 0.15);
  };

  const handleUpdatePrefs = (updated: Partial<UserPreferences>) => {
    setPrefs(prev => ({ ...prev, ...updated }));
  };


  const handleNoiseChange = (type: 'brown' | 'binaural' | 'rain' | 'off') => {
    setActiveNoise(type);
    soundSynth.playAmbient(type, prefs.soundEffectVolume);
  };

  const handleSaveFlashcards = (cards: Flashcard[]) => {
    const newCards = cards.map(c => ({ ...c, id: Date.now() + Math.random().toString() }));
    setSavedFlashcards(prev => [...prev, ...newCards]);
    alert(`${cards.length} flashcards saved to your study deck!`);
  };

  const handleApplyDiagnosis = (diagnosis: MindsetDiagnosis) => {
    setActiveDiagnosis(diagnosis);
    if (diagnosis.recommendedFontMode === 'dyslexic') {
      handleUpdatePrefs({ dyslexicFont: true, theme: 'dyslexia-warm' });
    }
  };

  // Theme wrapper class calculation
  let themeClass = 'bg-slate-50 text-slate-900';
  if (prefs.theme === 'dark-slate') {
    themeClass = 'dark bg-slate-950 text-slate-100';
  } else if (prefs.theme === 'dyslexia-warm') {
    themeClass = 'bg-[#fbf7ee] text-slate-900';
  } else if (prefs.theme === 'high-contrast') {
    themeClass = 'bg-black text-amber-300';
  }

  const currentConditionProfile = CONDITION_PROFILES.find(p => p.id === prefs.activeCondition) || CONDITION_PROFILES[0];

  return (
    <div className={`min-h-screen font-sans antialiased transition-colors duration-300 ${themeClass} ${prefs.dyslexicFont ? 'font-dyslexic' : ''} ${prefs.largeTouchTargets ? 'dyspraxia-touch-mode' : ''}`}>
      {/* Skip to Main Content Link for Screen Readers */}
      <a 
        href="#main-content" 
        className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:px-4 focus:py-2 focus:bg-emerald-600 focus:text-white focus:font-bold focus:rounded-lg focus:shadow-lg focus:outline-hidden"
      >
        Skip to main content
      </a>

      <PlatformFrame viewport={viewport} onChangeViewport={setViewport}>
        <DynamicStudyBackground condition={prefs.activeCondition} theme={prefs.theme} />
        <Header
          prefs={prefs}
          onUpdatePrefs={handleUpdatePrefs}
          viewport={viewport}
          onChangeViewport={setViewport}
          onOpenMindCheck={() => setIsMindCheckOpen(true)}
          activeNoise={activeNoise}
          onChangeNoise={handleNoiseChange}
          isDeepFocusMode={isDeepFocusMode}
          onToggleDeepFocus={() => setIsDeepFocusMode(!isDeepFocusMode)}
          currentProfile={currentProfile}
          onOpenProfileModal={() => setIsProfileModalOpen(true)}
          onQuickSwitchCondition={handleSwitchCondition}
        />

        {/* Screen Reader Optimization Announcement & Direct Navigation Toolbar */}
        {prefs.screenReaderOptimization && (
          <div 
            role="status" 
            aria-live="polite" 
            className="bg-emerald-950 text-emerald-100 border-b border-emerald-800 px-4 py-3 shadow-md"
          >
            <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center space-x-2">
                <Accessibility className="w-5 h-5 text-emerald-400 shrink-0" aria-hidden="true" />
                <div>
                  <p className="text-xs font-extrabold uppercase tracking-wider text-emerald-300">
                    Screen Reader & Motor Assist Mode Active
                  </p>
                  <p className="text-xs text-emerald-200">
                    Descriptive ARIA landmarks enabled. Use the shortcut jumpers below or Press Tab to navigate linearly.
                  </p>
                </div>
              </div>

              {/* Direct Landmark Jumpers */}
              <div className="flex flex-wrap items-center gap-1.5" role="navigation" aria-label="Screen Reader Fast Jump Navigation">
                <button
                  onClick={() => setActiveTab('robo_teacher')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold border transition-colors ${
                    activeTab === 'robo_teacher' 
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-extrabold' 
                      : 'bg-emerald-900/60 text-emerald-200 border-emerald-700 hover:bg-emerald-800'
                  }`}
                  aria-label="Jump to Robo-Teacher Interactive Classroom"
                >
                  1. Robo-Teacher
                </button>
                <button
                  onClick={() => setActiveTab('condition_hub')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold border transition-colors ${
                    activeTab === 'condition_hub' 
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-extrabold' 
                      : 'bg-emerald-900/60 text-emerald-200 border-emerald-700 hover:bg-emerald-800'
                  }`}
                  aria-label="Jump to Neurodiverse Condition Profiles Hub"
                >
                  2. Conditions Hub
                </button>
                <button
                  onClick={() => setActiveTab('dyscalculia')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold border transition-colors ${
                    activeTab === 'dyscalculia' 
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-extrabold' 
                      : 'bg-emerald-900/60 text-emerald-200 border-emerald-700 hover:bg-emerald-800'
                  }`}
                  aria-label="Jump to Dyscalculia Step-by-Step Math Visualizer"
                >
                  3. Dyscalculia Math
                </button>
                <button
                  onClick={() => setActiveTab('dysgraphia')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold border transition-colors ${
                    activeTab === 'dysgraphia' 
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-extrabold' 
                      : 'bg-emerald-900/60 text-emerald-200 border-emerald-700 hover:bg-emerald-800'
                  }`}
                  aria-label="Jump to Dysgraphia Voice Dictation Scribe"
                >
                  4. Dysgraphia Scribe
                </button>
                <button
                  onClick={() => setActiveTab('apd')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold border transition-colors ${
                    activeTab === 'apd' 
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-extrabold' 
                      : 'bg-emerald-900/60 text-emerald-200 border-emerald-700 hover:bg-emerald-800'
                  }`}
                  aria-label="Jump to Auditory Processing Disorder Closed Captions"
                >
                  5. APD Captions
                </button>
                <button
                  onClick={() => setActiveTab('stress_relief')}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-bold border transition-colors ${
                    activeTab === 'stress_relief' 
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-extrabold' 
                      : 'bg-emerald-900/60 text-emerald-200 border-emerald-700 hover:bg-emerald-800'
                  }`}
                  aria-label="Jump to Stress Relief & Breathing Exercise Hub"
                >
                  6. Stress Relief
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Main Content Dashboard - Vibrant Palette Grid */}
        <main id="main-content" tabIndex={-1} role="main" aria-label="NeuroLearn AI Learning Application Content" className="max-w-7xl mx-auto px-4 py-6">
          
          {/* Active Brain Condition Quick Banner or Deep Focus Banner */}
          {isDeepFocusMode ? (
            <div className="mb-6 p-4 rounded-2xl bg-indigo-950 text-white border-2 border-amber-400/80 shadow-2xl flex flex-wrap items-center justify-between gap-3 animate-fade-in">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 flex items-center justify-center text-slate-950 font-black text-lg shadow-md">
                  <Zap className="w-5 h-5 text-slate-950 fill-current" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h2 className="text-sm font-black text-white uppercase tracking-wider">
                      Minimalist Deep Focus Mode
                    </h2>
                    <span className="text-[10px] font-bold bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full uppercase">
                      Distraction-Free
                    </span>
                  </div>
                  <p className="text-xs text-indigo-200">
                    Sidebars and secondary UI hidden. Pure concentration workspace for {currentConditionProfile.title}.
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setIsDeepFocusMode(false)}
                  className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs rounded-xl shadow-md flex items-center space-x-1.5 transition-all"
                >
                  <Minimize2 className="w-4 h-4" />
                  <span>Exit Deep Focus</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="mb-6 p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800">
                  {currentConditionProfile.icon}
                </div>
                <div>
                  <span className="text-xs font-black uppercase tracking-wider text-slate-900 dark:text-white flex items-center gap-1.5">
                    Active Accommodations: <span className="text-indigo-600 dark:text-indigo-400">{currentConditionProfile.title}</span>
                  </span>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {currentConditionProfile.shortDesc}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setActiveTab('condition_hub')}
                  aria-label="Switch Brain Condition Profile"
                  className="text-xs font-bold px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs flex items-center space-x-1"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Switch Brain Condition</span>
                </button>
              </div>
            </div>
          )}

          {/* Vibrant Palette 12-Column Responsive Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* LEFT COLUMN: Cognitive Profile, Focus Streak & Cross-Platform Sync */}
            {!isDeepFocusMode && (
              <aside aria-label="Cognitive Profile Sidebar" className="lg:col-span-3 flex flex-col gap-4">
                {/* Focus Streak Counter Card */}
                <FocusStreakCounter />

                {/* Cognitive Profile Card */}
                <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse" aria-hidden="true"></span>
                    Inclusive Brain Profile
                  </h3>
                  <div className="space-y-3">
                    <div className="p-3 bg-indigo-50 dark:bg-indigo-950/60 rounded-xl border border-indigo-100 dark:border-indigo-900">
                      <p className="text-[10px] text-indigo-700 dark:text-indigo-300 font-bold uppercase tracking-wider mb-0.5">Primary Accommodation</p>
                      <p className="text-xs font-bold text-indigo-900 dark:text-indigo-200 flex items-center gap-1.5">
                        {currentConditionProfile.icon}
                        <span>{currentConditionProfile.title}</span>
                      </p>
                    </div>
                    
                    <div className="p-3 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-100 dark:border-rose-900/60">
                      <p className="text-[10px] text-rose-700 dark:text-rose-300 font-bold uppercase tracking-wider mb-0.5">Specialized Features</p>
                      <p className="text-xs font-semibold text-rose-900 dark:text-rose-200">
                        {prefs.activeCondition === 'dyslexia' && 'Bionic Reader & Audio Engine'}
                        {prefs.activeCondition === 'dyscalculia' && 'Dot Counter & Formula Translator'}
                        {prefs.activeCondition === 'dysgraphia' && 'Voice Scribe & Thought Polisher'}
                        {prefs.activeCondition === 'apd' && 'Synchronized Visual Captions (0.75x)'}
                        {prefs.activeCondition === 'dyspraxia' && 'Large Touch Targets & Key Shortcuts'}
                        {prefs.activeCondition === 'nvld' && 'Spatial & Context Explanations'}
                      </p>
                    </div>

                    <div className="pt-2">
                      <div className="flex justify-between text-xs mb-1 font-semibold">
                        <span className="text-slate-600 dark:text-slate-400">Mental Battery</span>
                        <span className="text-indigo-600 dark:text-indigo-400 font-bold">88% Focus</span>
                      </div>
                      <div className="w-full bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden" role="progressbar" aria-valuenow={88} aria-valuemin={0} aria-valuemax={100} aria-label="Mental Battery Focus Level: 88%">
                        <div className="bg-emerald-500 h-full w-[88%] rounded-full"></div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Cross-Platform Sync Banner */}
                <div className="bg-indigo-950 dark:bg-indigo-950 rounded-2xl p-5 text-white shadow-md relative overflow-hidden border border-indigo-900">
                  <div className="relative z-10">
                    <h3 className="text-sm font-bold mb-1 flex items-center gap-1.5">
                      <Smartphone className="w-4 h-4 text-indigo-300" aria-hidden="true" />
                      <span>Cross-Platform Sync</span>
                    </h3>
                    <p className="text-xs text-indigo-200 leading-relaxed mb-4">
                      Your brain study profiles & streak counters sync live across Web, Android & iOS.
                    </p>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 bg-white/10 p-2 rounded-lg text-[11px] font-medium">
                        <div className="w-2 h-2 rounded-full bg-emerald-400"></div> Web Simulator (Active)
                      </div>
                      <div className="flex items-center gap-2 bg-white/10 p-2 rounded-lg text-[11px] font-medium opacity-75">
                        <div className="w-2 h-2 rounded-full bg-amber-400"></div> Pixel 7 Pro (Standby)
                      </div>
                    </div>
                  </div>
                  <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-indigo-500 rounded-full blur-3xl opacity-30 pointer-events-none"></div>
                </div>
              </aside>
            )}

            {/* CENTER COLUMN: Main Navigation Tabs & Active Tools */}
            <section aria-label="Interactive Learning Workspace" className={`${isDeepFocusMode ? 'lg:col-span-12' : 'lg:col-span-6'} flex flex-col gap-6`}>
              {/* Tab Navigation Pill Bar */}
              <div role="tablist" aria-label="Interactive Learning Modules" className="bg-white dark:bg-slate-900 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-wrap items-center gap-1">
                {currentProfile.role === 'teacher' && (
                  <button
                    role="tab"
                    aria-selected={activeTab === 'teacher_admin'}
                    aria-controls="active-tab-panel"
                    aria-label="Teacher / Admin Class Roster Dashboard"
                    onClick={() => setActiveTab('teacher_admin')}
                    className={`flex-1 min-w-[130px] px-3 py-2 rounded-xl text-xs font-black flex items-center justify-center space-x-1.5 transition-all ${
                      activeTab === 'teacher_admin'
                        ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-200 dark:shadow-none font-black'
                        : 'text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/60'
                    }`}
                  >
                    <span>🎓 Teacher Admin</span>
                  </button>
                )}

                <button
                  role="tab"
                  aria-selected={activeTab === 'robo_teacher'}
                  aria-controls="active-tab-panel"
                  aria-label="Robo-Teacher Animated Presentation"
                  onClick={() => setActiveTab('robo_teacher')}
                  className={`flex-1 min-w-[120px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'robo_teacher'
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" aria-hidden="true" />
                  <span>Robo-Teacher</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'condition_hub'}
                  aria-controls="active-tab-panel"
                  aria-label="Neurodiverse Condition Profiles Hub"
                  onClick={() => setActiveTab('condition_hub')}
                  className={`flex-1 min-w-[120px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'condition_hub'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Brain className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Conditions Hub</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'dyscalculia'}
                  aria-controls="active-tab-panel"
                  aria-label="Dyscalculia Step-by-Step Math Visualizer"
                  onClick={() => setActiveTab('dyscalculia')}
                  className={`flex-1 min-w-[110px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'dyscalculia'
                      ? 'bg-amber-500 text-white shadow-md shadow-amber-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Calculator className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Dyscalculia</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'dysgraphia'}
                  aria-controls="active-tab-panel"
                  aria-label="Dysgraphia Voice Scribe & Thought Dictation"
                  onClick={() => setActiveTab('dysgraphia')}
                  className={`flex-1 min-w-[110px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'dysgraphia'
                      ? 'bg-purple-600 text-white shadow-md shadow-purple-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <PenTool className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Dysgraphia</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'apd'}
                  aria-controls="active-tab-panel"
                  aria-label="Auditory Processing Disorder Synchronized Captions"
                  onClick={() => setActiveTab('apd')}
                  className={`flex-1 min-w-[100px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'apd'
                      ? 'bg-sky-500 text-white shadow-md shadow-sky-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Captions className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>APD Captions</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'transformer'}
                  aria-controls="active-tab-panel"
                  aria-label="Dyslexia Bionic Text Transformer"
                  onClick={() => setActiveTab('transformer')}
                  className={`flex-1 min-w-[100px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'transformer'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Dyslexia Text</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'stress_relief'}
                  aria-controls="active-tab-panel"
                  aria-label="Stress Relief & Breathing Exercises Hub"
                  onClick={() => setActiveTab('stress_relief')}
                  className={`flex-1 min-w-[100px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'stress_relief'
                      ? 'bg-rose-500 text-white shadow-md shadow-rose-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <HeartHandshake className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Stress Relief</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'plan'}
                  aria-controls="active-tab-panel"
                  aria-label="Study Path Generator"
                  onClick={() => setActiveTab('plan')}
                  className={`flex-1 min-w-[100px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'plan'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Calendar className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Study Path</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'chat'}
                  aria-controls="active-tab-panel"
                  aria-label="Psychological AI Tutors Chat"
                  onClick={() => setActiveTab('chat')}
                  className={`flex-1 min-w-[90px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'chat'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Brain className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>AI Tutors</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'focustimer'}
                  aria-controls="active-tab-panel"
                  aria-label="Focus Wave Pomodoro Timer"
                  onClick={() => setActiveTab('focustimer')}
                  className={`flex-1 min-w-[90px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'focustimer'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Focus Wave</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'analytics'}
                  aria-controls="active-tab-panel"
                  aria-label="Cognitive Performance & D3 Analytics Dashboard"
                  onClick={() => setActiveTab('analytics')}
                  className={`flex-1 min-w-[95px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'analytics'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <TrendingUp className="w-3.5 h-3.5 text-emerald-400" aria-hidden="true" />
                  <span>Analytics</span>
                </button>

                <button
                  role="tab"
                  aria-selected={activeTab === 'milestones'}
                  aria-controls="active-tab-panel"
                  aria-label="Learning Milestones & Achievement Badges"
                  onClick={() => setActiveTab('milestones')}
                  className={`flex-1 min-w-[95px] px-3 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 transition-all ${
                    activeTab === 'milestones'
                      ? 'bg-amber-500 text-white shadow-md shadow-amber-200 dark:shadow-none'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Trophy className="w-3.5 h-3.5 text-amber-300" aria-hidden="true" />
                  <span>Milestones</span>
                </button>

                {savedFlashcards.length > 0 && (
                  <button
                    role="tab"
                    aria-selected={activeTab === 'saved_decks'}
                    aria-controls="active-tab-panel"
                    aria-label={`Saved Flashcards Bank with ${savedFlashcards.length} cards`}
                    onClick={() => setActiveTab('saved_decks')}
                    className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all ${
                      activeTab === 'saved_decks'
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200 dark:shadow-none'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Saved ({savedFlashcards.length})</span>
                  </button>
                )}
              </div>

              {/* Voice Command Hands-Free Navigation Assistant */}
              <div className="mb-4">
                <VoiceCommandNavigator
                  onNavigate={(tab) => setActiveTab(tab as any)}
                  activeTab={activeTab}
                />
              </div>

              {/* Main Active Module Container */}
              <div id="active-tab-panel" role="tabpanel" aria-label="Active Learning Module Workspace" className="w-full">
                {activeTab === 'teacher_admin' && (
                  <TeacherAdminDashboard
                    teacher={teacherProfile}
                    students={studentsList}
                    onAddStudent={handleAddStudent}
                    onDeleteStudent={handleDeleteStudent}
                    onSelectStudentProfile={handleSelectProfile}
                  />
                )}

                {activeTab === 'robo_teacher' && (
                  <RobotTeacherPresentation prefs={prefs} />
                )}

                {activeTab === 'condition_hub' && (
                  <NeuroConditionSelector prefs={prefs} onChangePrefs={handleUpdatePrefs} />
                )}

                {activeTab === 'dyscalculia' && (
                  <DyscalculiaVisualizer />
                )}

                {activeTab === 'dysgraphia' && (
                  <DysgraphiaScribe />
                )}

                {activeTab === 'apd' && (
                  <ApdCaptionsReader />
                )}

                {activeTab === 'stress_relief' && (
                  <StressAnxietyHub />
                )}

                {activeTab === 'plan' && (
                  <StudyPlanGenerator />
                )}

                {activeTab === 'transformer' && (
                  <DyslexiaTransformer prefs={prefs} onSaveFlashcards={handleSaveFlashcards} />
                )}

                {activeTab === 'chat' && (
                  <SpecialistChat prefs={prefs} />
                )}

                {activeTab === 'focustimer' && (
                  <FocusTimer 
                    activeNoise={activeNoise} 
                    onChangeNoise={handleNoiseChange} 
                    onSessionComplete={(recap) => setSessionRecap(recap)}
                  />
                )}

                {activeTab === 'analytics' && (
                  <CognitivePerformanceDashboard />
                )}

                {activeTab === 'milestones' && (
                  <MilestonesSystem />
                )}


                {activeTab === 'saved_decks' && (
                  <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                        Saved Flashcard Study Bank ({savedFlashcards.length} Cards)
                      </h2>
                      <button
                        onClick={() => setSavedFlashcards([])}
                        className="text-xs text-rose-500 hover:underline font-semibold"
                      >
                        Clear Deck
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {savedFlashcards.map((card, idx) => (
                        <div key={idx} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80">
                          <span className="text-[10px] uppercase font-bold text-indigo-600 dark:text-indigo-400 block mb-1">
                            {card.memoryTag || 'Saved Concept'}
                          </span>
                          <p className="text-xs font-semibold text-slate-900 dark:text-white mb-2">
                            Q: {card.question}
                          </p>
                          <p className="text-xs text-emerald-700 dark:text-emerald-300 font-medium">
                            A: {card.answer}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* AI Reflection Insight Banner */}
              <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 flex flex-col sm:flex-row items-center gap-4">
                <div className="flex-1">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-1">AI Cognitive Reflection</p>
                  <p className="text-xs text-slate-700 dark:text-slate-300 italic leading-relaxed">
                    "Every neurodiverse brain processes information uniquely. Whether you need physical dot counters for Dyscalculia or voice dictation for Dysgraphia, structured multi-sensory learning unlocks retention."
                  </p>
                </div>
                <div className="sm:w-24 flex flex-col items-center justify-center border-t sm:border-t-0 sm:border-l border-slate-100 dark:border-slate-800 pt-3 sm:pt-0 sm:pl-4 shrink-0">
                  <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-950 rounded-full flex items-center justify-center mb-1">
                    <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-400">Inclusive Score</span>
                  <span className="text-lg font-black text-emerald-600 dark:text-emerald-400">100%</span>
                </div>
              </div>
            </section>

            {/* RIGHT COLUMN: Study Timeline & Psychological Focus Zone */}
            {!isDeepFocusMode && (
              <aside className="lg:col-span-3 flex flex-col gap-6">
                {/* Study Timeline */}
                <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-4">Study Timeline</h3>
                  <div className="space-y-5 relative before:absolute before:left-2 before:top-2 before:bottom-2 before:w-[2px] before:bg-slate-100 dark:before:bg-slate-800">
                    <div className="relative pl-7">
                      <div className="absolute left-0 top-1 w-4 h-4 bg-indigo-600 rounded-full border-4 border-white dark:border-slate-900 ring-1 ring-indigo-600"></div>
                      <p className="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase">Current Session</p>
                      <p className="text-xs font-bold text-slate-900 dark:text-white">{currentConditionProfile.title}</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">Multi-Sensory Accommodations</p>
                    </div>
                    <div className="relative pl-7 opacity-75">
                      <div className="absolute left-0 top-1 w-4 h-4 bg-slate-300 dark:bg-slate-700 rounded-full border-4 border-white dark:border-slate-900"></div>
                      <p className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase">Up Next</p>
                      <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Robo-Teacher Live Stage</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">Estimated 10 mins</p>
                    </div>
                    <div className="relative pl-7 opacity-50">
                      <div className="absolute left-0 top-1 w-4 h-4 bg-slate-200 dark:bg-slate-800 rounded-full border-4 border-white dark:border-slate-900"></div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase">Scheduled</p>
                      <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">Binaural Focus Sound Wave</p>
                      <p className="text-[11px] text-slate-400">Alpha Frequency</p>
                    </div>
                  </div>
                </div>

                {/* Psychological Focus Zone Card */}
                <div className="bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl p-5 border border-emerald-100 dark:border-emerald-900/60 flex flex-col items-center text-center">
                  <h3 className="text-xs font-extrabold text-emerald-900 dark:text-emerald-300 uppercase tracking-wider mb-3">Psychological State</h3>
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-16 h-16 bg-white dark:bg-slate-900 rounded-full border-4 border-emerald-200 dark:border-emerald-800 flex items-center justify-center relative shadow-xs">
                      <div className="absolute inset-0 border-4 border-emerald-500 rounded-full border-t-transparent animate-spin"></div>
                      <span className="text-2xl">🧠</span>
                    </div>
                    <p className="text-xs font-bold text-emerald-800 dark:text-emerald-300 uppercase tracking-widest">Inclusive Study Zone</p>
                    <p className="text-[11px] text-emerald-700 dark:text-emerald-400 leading-relaxed">
                      Accommodations aligned with your brain's processing style. Low anxiety, high retention.
                    </p>
                  </div>
                </div>
              </aside>
            )}

          </div>
        </main>

        {/* Mind Check-In Modal */}
        <MindsetCheckModal
          isOpen={isMindCheckOpen}
          onClose={() => setIsMindCheckOpen(false)}
          onApplyDiagnosis={handleApplyDiagnosis}
        />

        {/* Session Recap Modal */}
        <SessionRecapModal
          recap={sessionRecap}
          onClose={() => setSessionRecap(null)}
          onStartNextTopic={(topic) => {
            setActiveTab('robo_teacher');
            setSessionRecap(null);
          }}
        />

        {/* Posture & Dyspraxia Comfort Reminder Floating Component */}
        <PostureAwarenessReminder
          enabled={prefs.postureReminderEnabled ?? true}
          intervalMinutes={prefs.postureIntervalMinutes ?? 20}
        />

        {/* AI Study Buddy Floating Overlay */}
        <AIStudyBuddyOverlay
          isVisible={isBuddyOverlayVisible}
          onToggleVisible={() => setIsBuddyOverlayVisible(!isBuddyOverlayVisible)}
        />

        {/* Profile Login & Admin Switcher Portal Modal */}
        <ProfileLoginModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          teacher={teacherProfile}
          students={studentsList}
          currentProfile={currentProfile}
          onSelectProfile={handleSelectProfile}
        />
      </PlatformFrame>

    </div>
  );
}

