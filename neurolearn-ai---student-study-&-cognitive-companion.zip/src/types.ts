export type LearningCondition = 
  | 'general_standard'
  | 'dyslexia' 
  | 'dyscalculia' 
  | 'dysgraphia' 
  | 'apd' 
  | 'dyspraxia' 
  | 'nvld';

export type LearningStyle = 'dyslexia' | 'dyscalculia' | 'dysgraphia' | 'apd' | 'dyspraxia' | 'nvld' | 'adhd' | 'visual' | 'socratic' | 'standard';

export type DisplayTheme = 'light' | 'dyslexia-warm' | 'dark-slate' | 'high-contrast';

export type DeviceViewport = 'responsive' | 'mobile' | 'tablet' | 'desktop';

export type Persona = 'dr_mind' | 'socratic' | 'dyslexia_coach' | 'adhd_coach' | 'mind_psychologist' | 'dyscalculia_tutor' | 'dysgraphia_scribe' | 'apd_listener';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  timestamp: string;
  persona?: Persona;
}

export interface MindMapNode {
  id: string;
  label: string;
  description: string;
  parentId: string | null;
}

export interface Flashcard {
  id: string;
  question: string;
  answer: string;
  hint?: string;
  memoryTag?: string;
  mastered?: boolean;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  userAnswer?: number;
}

export interface DyscalculiaMathStep {
  stepNumber: number;
  expression: string;
  explanation: string;
  visualRepresentation: string; // e.g., "🔵🔵🔵 + 🔴🔴 = 5"
}

export interface DysgraphiaSentenceHelp {
  originalThought: string;
  structuredSentence: string;
  spellingTips: string[];
  grammarStructure: string;
}

export interface TransformedContent {
  dyslexiaFriendlyText: string;
  simplifiedSummary: string[];
  visualMindMap: MindMapNode[];
  mnemonics: string[];
  flashcards: Flashcard[];
  quiz: QuizQuestion[];
  studyTip: string;
  // Specific accommodations
  mathSteps?: DyscalculiaMathStep[];
  sentenceStructuring?: DysgraphiaSentenceHelp[];
  apdCaptions?: string[];
  nvldSpatialExplanation?: string;
}

export interface MindsetDiagnosis {
  learningArchetype: string;
  psychologicalInsight: string;
  topStrategies: string[];
  recommendedFontMode: string;
  encouragementQuote: string;
  primaryCondition?: LearningCondition;
}

export interface StudyModule {
  day: number;
  focusGoal: string;
  microTasks: string[];
  breakActivity: string;
  brainTip: string;
}

export interface StudyPlan {
  planTitle: string;
  learningStyle?: string;
  learningStyleAdvice?: string;
  totalDays: number;
  retentionTechniques?: string[];
  dailyModules: StudyModule[];
}

export interface PresentationSlide {
  slideNumber: number;
  title: string;
  robotTeacherDialogue: string;
  bulletPoints: string[];
  visualDiagramHint?: string;
  keyTakeaway: string;
  emotion?: 'excitement' | 'confusion' | 'empathy' | 'pointing' | 'explaining' | 'thinking';
}

export interface ClassroomQuiz {
  question: string;
  options: string[];
  correctIndex: number;
  teacherFeedback: string;
}

export interface TeacherPresentation {
  topic: string;
  subtitle: string;
  estimatedTimeMins?: number;
  slides: PresentationSlide[];
  classroomQuiz: ClassroomQuiz;
  stressReliefTip: string;
}

export type AIEmotionTone = 
  | 'encouragement' 
  | 'empathy' 
  | 'curiosity' 
  | 'socratic' 
  | 'calm_zen' 
  | 'energetic_hype' 
  | 'analytical_direct' 
  | 'constructive_challenge';

export interface UserPreferences {
  activeCondition: LearningCondition;
  dyslexicFont: boolean;
  bionicHighlight: boolean;
  fontSize: 'normal' | 'large' | 'xlarge';
  letterSpacing: 'normal' | 'wide' | 'extra-wide';
  lineHeight: 'normal' | 'relaxed' | 'spacious';
  theme: DisplayTheme;
  speechSpeed: number;
  speechVoice: string;
  soundEffectVolume: number;
  aiEmotionTone?: AIEmotionTone;
  // Specialized Accessibility Toggles for Brain Study Conditions
  mathVisualizerEnabled: boolean;    // Dyscalculia
  voiceTypingAssistant: boolean;     // Dysgraphia
  audioClosedCaptions: boolean;      // Auditory Processing Disorder
  largeTouchTargets: boolean;        // Dyspraxia
  explicitTextLabels: boolean;       // Nonverbal Learning Disorder
  screenReaderOptimization: boolean; // Screen Reader & Motor Coordination Mode
  postureReminderEnabled?: boolean;  // Dyspraxia & Ergonomic Posture Awareness
  postureIntervalMinutes?: number;   // Stretch interval (e.g. 15, 20, 30)
  deepFocusMode?: boolean;           // Minimalist Distraction-Free View
}

export interface PostureStretch {
  id: string;
  title: string;
  targetArea: 'shoulders' | 'neck' | 'wrists' | 'spine' | 'spatial';
  durationSeconds: number;
  instructions: string;
  dyspraxiaBenefit: string;
  iconName: string;
}

export interface DailyJournalEntry {
  id: string;
  timestamp: string;
  date: string;
  text: string;
  moodScore: number; // 0 to 100
  detectedEmotion: 'anxious' | 'overwhelmed' | 'calm' | 'focused' | 'frustrated' | 'optimistic';
  primaryTrigger?: string;
  suggestedGrounding: string;
  cognitiveReframing: string;
}

export interface WeeklyPerformanceData {
  dayLabel: string;
  date: string;
  focusMinutes: number;
  mentalBatteryPct: number;
  tasksCompleted: number;
  cognitiveLoad: 'Low' | 'Optimal' | 'High';
}

export interface AchievementBadge {
  id: string;
  title: string;
  description: string;
  icon: string;
  category: 'streak' | 'focus' | 'subject' | 'mindset';
  unlocked: boolean;
  unlockedAt?: string;
  progress: number;
  maxProgress: number;
}

export interface SessionRecapData {
  sessionTimeMinutes: number;
  mentalBatteryRemaining: number;
  conceptsMastered: string[];
  suggestedNextTopic: string;
  xpEarned: number;
}

export type StudyBuddyMode = 'body_doubling' | 'affirmations' | 'zen_observer';

export interface StudyBuddyPartner {
  id: string;
  name: string;
  subject: string;
  avatarBg: string;
  avatarIcon: string;
  statusMessages: string[];
}

export interface AIReactionLog {
  id: string;
  timestamp: string;
  topic: string;
  persona: string;
  userPromptOrQuestion: string;
  aiResponseSnippet: string;
  detectedEmotion: string;
}

export interface StudentQuizScore {
  id: string;
  topic: string;
  scorePct: number;
  date: string;
}

export interface StudentProfileData {
  id: string;
  name: string;
  role: 'student';
  gradeLevel: string;
  primaryCondition: LearningCondition;
  avatarIcon: string;
  avatarBg: string;
  notes?: string;
  createdAt: string;
  prefs: UserPreferences;
  savedFlashcards: Flashcard[];
  aiReactions: AIReactionLog[];
  quizScores: StudentQuizScore[];
  mentalBatteryPct: number;
}

export interface TeacherProfileData {
  id: string;
  name: string;
  role: 'teacher';
  email: string;
  schoolName: string;
  avatarBg: string;
}

export type ActiveUserProfile = StudentProfileData | TeacherProfileData;

