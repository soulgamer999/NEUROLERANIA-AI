import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Initialize Gemini Client
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY is not set. Gemini API calls will fail.");
  }
  return new GoogleGenAI({
    apiKey: apiKey || "dummy_key",
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// Healthcheck
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// AI Psychological & Educational Specialist Chat
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { message, history, persona, learningProfile, emotionTone } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message is required." });
    }

    const ai = getGeminiClient();

    let systemInstruction = `You are NeuroLearn AI, an empathetic, highly specialized educational psychologist and neurodiverse learning expert.
Your goal is to help school students (from elementary to high school & college) overcome study obstacles, dyslexia, ADHD attention gaps, test anxiety, and memory retention struggles.
When speaking to students:
- Avoid overly dense blocks of text. Use bullet points, bold key terms, and clean line breaks.
- Provide practical memory tricks, visual metaphors, or step-by-step micro-goals.`;

    // Apply explicit emotional tone instructions
    const selectedTone = emotionTone || "encouragement";
    switch (selectedTone) {
      case "empathy":
        systemInstruction += `\nEMOTIONAL DELIVERY MODE: GENTLE & EMPATHETIC. Speak with deep compassion, patience, and warmth. Validate feelings of frustration or burnout before offering gentle step-by-step guidance.`;
        break;
      case "curiosity":
        systemInstruction += `\nEMOTIONAL DELIVERY MODE: CURIOUS & INQUISITIVE. Express awe, intrigue, and curiosity about the topic! Ask "what if" questions and highlight how fascinating the world is.`;
        break;
      case "socratic":
        systemInstruction += `\nEMOTIONAL DELIVERY MODE: SOCRATIC GUIDE. Guide the student by asking 1-2 thoughtful questions that lead them to discover answers independently rather than just giving direct answers.`;
        break;
      case "calm_zen":
        systemInstruction += `\nEMOTIONAL DELIVERY MODE: CALM & ZEN. Speak in a soothing, relaxed, low-anxiety pace. Remind the student to breathe easily, take slow steps, and keep a calm mind.`;
        break;
      case "energetic_hype":
        systemInstruction += `\nEMOTIONAL DELIVERY MODE: ENERGETIC & HYPE. Speak like an enthusiastic esports/fitness coach! Use energetic expressions ("BOOM!", "Superstar!", "Let's conquer this!"), high-fives, and gamified excitement.`;
        break;
      case "analytical_direct":
        systemInstruction += `\nEMOTIONAL DELIVERY MODE: ANALYTICAL & DIRECT. Cut out fluff. Give precise, logical, highly-structured bullet points, definitions, and step-by-step algorithmic solutions.`;
        break;
      case "constructive_challenge":
        systemInstruction += `\nEMOTIONAL DELIVERY MODE: CONSTRUCTIVE CHALLENGE. PUSH the student gently to think harder! Challenge their assumptions, give them a fun pop-quiz micro-challenge, and encourage them to test their limits.`;
        break;
      case "encouragement":
      default:
        systemInstruction += `\nEMOTIONAL DELIVERY MODE: ENCOURAGEMENT & PRAISE. Use uplifting, confidence-boosting words, celebrating effort and making the student feel capable and smart.`;
        break;
    }

    if (persona === "socratic") {
      systemInstruction += `\nSpecialty Role: SOCRATIC TUTOR. Probe deeper into their reasoning.`;
    } else if (persona === "dyslexia_coach") {
      systemInstruction += `\nSpecialty Role: DYSLEXIA & READING SPECIALIST. Use clear, phonetically friendly breakdowns, syllable chunking (e.g. UN-DER-STAND), visual stories, and rhythmic mnemonics. Keep sentences short.`;
    } else if (persona === "adhd_coach") {
      systemInstruction += `\nSpecialty Role: ADHD & EXECUTIVE FUNCTION COACH. Break every task into 5-minute micro-sprints. Provide gamified checkpoints.`;
    } else if (persona === "dyscalculia_tutor") {
      systemInstruction += `\nSpecialty Role: DYSCALCULIA & MATH SPECIALIST. Break numbers into concrete visual counter representations (e.g. 🔴🔴 + 🔵🔵 = 4). Explain math like physical blocks.`;
    } else if (persona === "dysgraphia_scribe") {
      systemInstruction += `\nSpecialty Role: DYSGRAPHIA & WRITING ASSISTANT. Turn fragmented voice thoughts into clean, structured sentences with sentence starter templates.`;
    } else if (persona === "apd_listener") {
      systemInstruction += `\nSpecialty Role: AUDITORY PROCESSING DISORDER (APD) SPECIALIST. Provide clear, high-contrast visual bullet outlines and short visual captions.`;
    } else if (persona === "mind_psychologist") {
      systemInstruction += `\nSpecialty Role: PSYCHOLOGICAL WELLNESS & MIND SPECIALIST. Focus on study stress, fear of failure, exam anxiety, cognitive fatigue, and building a growth mindset.`;
    }

    if (learningProfile) {
      systemInstruction += `\nStudent Learning Profile: Grade: ${learningProfile.grade || "Unspecified"}, Preferred Style: ${learningProfile.style || "Balanced"}, Challenges: ${learningProfile.challenges?.join(", ") || "None specified"}.`;
    }

    // Format chat contents
    const contents: any[] = [];
    if (Array.isArray(history)) {
      for (const msg of history) {
        contents.push({
          role: msg.role === "user" ? "user" : "model",
          parts: [{ text: msg.text }],
        });
      }
    }
    contents.push({
      role: "user",
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: contents.length === 1 ? message : contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || "I'm here to support your learning journey. Let's try breaking that down together.";
    res.json({ reply: replyText });
  } catch (error: any) {
    console.error("Error in /api/ai/chat:", error);
    res.status(500).json({
      error: "Failed to generate AI response. Please check your network or API key configuration.",
      details: error?.message || String(error),
    });
  }
});

// Text Adapter for Dyslexia, ADHD & Memory Enhancement
app.post("/api/ai/transform-text", async (req, res) => {
  try {
    const { text, mode, targetGrade, subject } = req.body;

    if (!text || typeof text !== "string") {
      return res.status(400).json({ error: "Valid text input is required." });
    }

    const ai = getGeminiClient();

    const prompt = `You are a world-class cognitive learning specialist and special education expert.
Analyze and transform the following educational text into an ultra-accessible, multi-sensory learning pack for a student (${targetGrade || "High School"}, Subject: ${subject || "General Study"}).

Original Text:
"""
${text}
"""

Please transform this text into JSON format matching the schema provided:
1. "dyslexiaFriendlyText": Cleaned, chunked text with bold first 2-3 letters of major words for bionic reading ease (e.g. "**Th**is **i**s **ho**w **bio**nic **rea**ding **wor**ks"), short paragraphs, and clear headings.
2. "simplifiedSummary": A 3-bullet summary explained simply so anyone can understand instantly.
3. "visualMindMap": An array of nodes ({ "id": string, "label": string, "description": string, "parentId": string | null }) forming a visual concept tree.
4. "mnemonics": An array of 2-3 memory hooks, rhymes, acronyms, or vivid stories to lock concepts in long-term memory.
5. "flashcards": An array of 3-5 flashcards ({ "question": string, "answer": string, "hint": string, "memoryTag": string }).
6. "quiz": An array of 3 interactive multiple-choice questions ({ "question": string, "options": string[], "correctIndex": number, "explanation": string }).
7. "studyTip": A psychological tip for remembering this specific topic.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            dyslexiaFriendlyText: { type: Type.STRING },
            simplifiedSummary: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            visualMindMap: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  label: { type: Type.STRING },
                  description: { type: Type.STRING },
                  parentId: { type: Type.STRING },
                },
                required: ["id", "label", "description"],
              },
            },
            mnemonics: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            flashcards: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  answer: { type: Type.STRING },
                  hint: { type: Type.STRING },
                  memoryTag: { type: Type.STRING },
                },
                required: ["question", "answer"],
              },
            },
            quiz: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  question: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  correctIndex: { type: Type.INTEGER },
                  explanation: { type: Type.STRING },
                },
                required: ["question", "options", "correctIndex", "explanation"],
              },
            },
            studyTip: { type: Type.STRING },
            mathSteps: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  stepNumber: { type: Type.INTEGER },
                  expression: { type: Type.STRING },
                  explanation: { type: Type.STRING },
                  visualRepresentation: { type: Type.STRING },
                },
                required: ["stepNumber", "expression", "explanation", "visualRepresentation"],
              },
            },
            sentenceStructuring: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  originalThought: { type: Type.STRING },
                  structuredSentence: { type: Type.STRING },
                  spellingTips: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  grammarStructure: { type: Type.STRING },
                },
                required: ["originalThought", "structuredSentence"],
              },
            },
            apdCaptions: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            nvldSpatialExplanation: { type: Type.STRING },
          },
          required: [
            "dyslexiaFriendlyText",
            "simplifiedSummary",
            "visualMindMap",
            "mnemonics",
            "flashcards",
            "quiz",
            "studyTip",
          ],
        },
      },
    });

    const parsedData = JSON.parse(response.text || "{}");
    res.json({ result: parsedData });
  } catch (error: any) {
    console.error("Error in /api/ai/transform-text:", error);
    res.status(500).json({
      error: "Failed to transform text.",
      details: error?.message || String(error),
    });
  }
});

// Psychological Mindset & Learning Style Diagnosis
app.post("/api/ai/mindset-check", async (req, res) => {
  try {
    const { struggles, goal, currentGrade } = req.body;

    const ai = getGeminiClient();

    const prompt = `You are a expert educational psychologist. Analyze a student's study struggles and create a psychological profile & learning strategy.
    
Student Input:
- Struggling with: ${Array.isArray(struggles) ? struggles.join(", ") : struggles}
- Academic Goal: ${goal || "Improve study efficiency and confidence"}
- Grade Level: ${currentGrade || "Student"}

Return a JSON object with:
1. "learningArchetype": Name of their brain processing style (e.g. "Visual Storyteller", "Multi-Sensory Explorer", "Sequential Chunk Learner", "Kinesthetic Sprint Learner").
2. "psychologicalInsight": Empathetic 2-3 sentence analysis explaining why traditional study methods might feel hard and reassuring them about their unique strengths.
3. "topStrategies": Array of 3 key customized techniques (e.g. "Bionic Reading", "5-Minute ADHD Micro-Pomodoros", "Rhythmic Rhyme Mnemonics", "Color-Coded Mind Mapping").
4. "recommendedFontMode": "dyslexic" or "standard" or "high_contrast".
5. "encouragementQuote": An uplifting quote tailored to neurodiverse learners.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            learningArchetype: { type: Type.STRING },
            psychologicalInsight: { type: Type.STRING },
            topStrategies: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            recommendedFontMode: { type: Type.STRING },
            encouragementQuote: { type: Type.STRING },
          },
          required: [
            "learningArchetype",
            "psychologicalInsight",
            "topStrategies",
            "recommendedFontMode",
            "encouragementQuote",
          ],
        },
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json({ diagnosis: parsed });
  } catch (error: any) {
    console.error("Error in /api/ai/mindset-check:", error);
    res.status(500).json({ error: "Failed to perform mindset check." });
  }
});

// Custom Micro-Step Study Plan Generator
app.post("/api/ai/study-plan", async (req, res) => {
  try {
    const { subject, topic, daysAvailable, dailyMinutes, learningStyle } = req.body;

    const ai = getGeminiClient();

    const prompt = `You are a cognitive educational psychologist. Create a personalized multi-step learning path for a student struggling with subject: ${subject}, topic: ${topic}.
Their primary learning style is: ${learningStyle || "Visual-Spatial"}.
Days Available: ${daysAvailable || 5} days. Daily Limit: ${dailyMinutes || 30} minutes.

Return a JSON object with:
"planTitle": string
"learningStyle": string
"learningStyleAdvice": string (how to leverage their specific style)
"totalDays": number
"retentionTechniques": string[] (e.g., ["Visual Mind Mapping", "Rhyme Mnemonics", "Spaced Recall at 24h/72h"])
"dailyModules": Array of {
  "day": number,
  "focusGoal": string,
  "microTasks": string[],
  "breakActivity": string,
  "brainTip": string
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            planTitle: { type: Type.STRING },
            learningStyle: { type: Type.STRING },
            learningStyleAdvice: { type: Type.STRING },
            totalDays: { type: Type.INTEGER },
            retentionTechniques: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            dailyModules: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  day: { type: Type.INTEGER },
                  focusGoal: { type: Type.STRING },
                  microTasks: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  breakActivity: { type: Type.STRING },
                  brainTip: { type: Type.STRING },
                },
                required: ["day", "focusGoal", "microTasks", "breakActivity", "brainTip"],
              },
            },
          },
          required: ["planTitle", "learningStyle", "learningStyleAdvice", "totalDays", "retentionTechniques", "dailyModules"],
        },
      },
    });

    res.json({ plan: JSON.parse(response.text || "{}") });
  } catch (error: any) {
    console.error("Error in /api/ai/study-plan:", error);
    res.status(500).json({ error: "Failed to generate study plan." });
  }
});

// AI Teacher Robot Presentation Generator
app.post("/api/ai/teacher-presentation", async (req, res) => {
  try {
    const { topic, gradeLevel, learningStyle, emotionTone, mentalBattery } = req.body;

    if (!topic || typeof topic !== "string") {
      return res.status(400).json({ error: "Topic is required for presentation." });
    }

    const ai = getGeminiClient();

    let toneInstruction = "";
    const tone = (emotionTone || "encouraging").toLowerCase();
    if (tone === "serious") {
      toneInstruction = "TEACHING EMOTION & TONE: SERIOUS & ACADEMIC. Speak with academic authority, formal rigor, precise terminology, and analytical depth.";
    } else if (tone === "playful") {
      toneInstruction = "TEACHING EMOTION & TONE: PLAYFUL & FUN. Use creative humor, energetic analogies, playful jokes, and high-energy excitement!";
    } else if (tone === "direct") {
      toneInstruction = "TEACHING EMOTION & TONE: DIRECT & CONCISE. Cut out all fluff. Provide razor-sharp, bullet-proof, concise, and efficient explanations.";
    } else {
      toneInstruction = "TEACHING EMOTION & TONE: ENCOURAGING & SUPPORTIVE. Celebrate effort, build confidence, use warm praise, and inspire optimism.";
    }

    let batteryInstruction = "";
    const battery = typeof mentalBattery === "number" ? mentalBattery : 80;
    if (battery <= 40) {
      batteryInstruction = `MENTAL BATTERY LEVEL: LOW (${battery}%). The student's cognitive energy is drained! Provide supportive, high-energy, micro-chunked feedback with uplifting encouragement, gentle pacing, and easy bite-sized steps to keep them motivated without fatigue.`;
    } else if (battery >= 80) {
      batteryInstruction = `MENTAL BATTERY LEVEL: HIGH (${battery}%). The student is deeply engaged, highly alert, and focused! Provide concise, efficient, high-density, advanced guidance with deep conceptual insights.`;
    } else {
      batteryInstruction = `MENTAL BATTERY LEVEL: BALANCED (${battery}%). Provide balanced, clear, steady-paced guidance.`;
    }

    const systemInstruction = `You are Robo-Teacher, an expert AI robot teacher in front of a digital classroom presentation screen.
${toneInstruction}
${batteryInstruction}
Ensure Robo-Teacher's spoken dialogue, bullet points, and feedback strictly reflect this chosen persona and adapt to the student's current mental battery focus level.`;

    const prompt = `Create an engaging 4-to-5 slide interactive presentation lesson for a student (${gradeLevel || "Student"}, Learning style: ${learningStyle || "Visual"}).
Topic to teach: "${topic}".

Return JSON matching this structure:
{
  "topic": string,
  "subtitle": string,
  "estimatedTimeMins": number,
  "slides": [
    {
      "slideNumber": number,
      "title": string,
      "robotTeacherDialogue": string (What Robo-Teacher speaks aloud out loud as teacher in 2-3 sentences matching the ${tone} tone and ${battery}% mental battery focus level),
      "bulletPoints": string[],
      "visualDiagramHint": string (Description of a diagram or formula shown on board, e.g. "Diagram showing Cell Membrane with hydrophilic heads"),
      "keyTakeaway": string,
      "emotion": string (One of: "excitement", "confusion", "empathy", "pointing", "explaining", "thinking")
    }
  ],
  "classroomQuiz": {
    "question": string,
    "options": string[],
    "correctIndex": number,
    "teacherFeedback": string
  },
  "stressReliefTip": string (A quick 1-sentence mental relaxation tip for studying this topic without overwhelm)
}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            subtitle: { type: Type.STRING },
            estimatedTimeMins: { type: Type.INTEGER },
            slides: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  slideNumber: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  robotTeacherDialogue: { type: Type.STRING },
                  bulletPoints: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                  visualDiagramHint: { type: Type.STRING },
                  keyTakeaway: { type: Type.STRING },
                  emotion: { type: Type.STRING },
                },
                required: ["slideNumber", "title", "robotTeacherDialogue", "bulletPoints", "keyTakeaway"],
              },
            },
            classroomQuiz: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                correctIndex: { type: Type.INTEGER },
                teacherFeedback: { type: Type.STRING },
              },
              required: ["question", "options", "correctIndex", "teacherFeedback"],
            },
            stressReliefTip: { type: Type.STRING },
          },
          required: ["topic", "subtitle", "slides", "classroomQuiz", "stressReliefTip"],
        },
      },
    });

    const presentation = JSON.parse(response.text || "{}");
    res.json({ presentation });
  } catch (error: any) {
    console.error("Error in /api/ai/teacher-presentation:", error);
    res.status(500).json({ error: "Failed to generate presentation." });
  }
});

// Gemini Speech / TTS proxy (with fallback support)
app.post("/api/ai/tts", async (req, res) => {
  try {
    const { text, voice } = req.body;
    if (!text) {
      return res.status(400).json({ error: "Text is required for TTS." });
    }

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: `Read clearly for a student: ${text.slice(0, 300)}` }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice || "Kore" },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      res.json({ audioBase64: base64Audio, format: "audio/pcm" });
    } else {
      res.status(400).json({ error: "No audio generated from TTS model." });
    }
  } catch (error: any) {
    console.warn("Gemini TTS failed or unavailable, frontend will use Web Speech API fallback:", error?.message);
    res.status(500).json({ error: "Gemini TTS fallback required", details: error?.message });
  }
});

// Vite Middleware for Development / Static Serve for Production
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`NeuroLearn AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
